# S5 Stage 2 — pair-local teacher specification and reproducibility report

Date: 2026-08-09.
Status: **SPECIFICATION ONLY.** Every reproducibility check below is
`BLOCKED_NO_COMPUTE`. No teacher was instantiated, evaluated or hashed in this
session. This document fixes definitions so that, when a shell exists, the
checks are mechanical rather than discretionary.

These are **structural mechanism pseudo-labels**. They are not physical binding
energies, not free-energy components, and not thermodynamic observables. Waters,
metals, complete protonation, solvation and entropy are unobserved by
construction.

## 1. Design rule adopted

Dense deterministic continuous targets, not sparse event labels. Rationale:
event labels (PLIP-style typed interactions) are (a) not authorised at this
stage, (b) sparse enough that atom–residue rows would be dominated by
prevalence, and (c) angular — hence `NOT_REPRESENTABLE` under Finding M-7.

## 2. Channel admissibility, driven by Stage 1

Stage 1 §5 partitions the candidate set. Only channels whose defining
information survives `Λ₁…Λ₅` may enter the feasibility criterion.

| ID | Channel | Class | Role |
|---|---|---|---|
| `K1` | pocket burial coverage | pair-local → complex aggregate | **CORE** |
| `K2` | apolar-contact burial | pair-local → complex aggregate | **CORE** |
| `K3` | close-range packing (sub-4 Å occupancy) | pair-local | diagnostic, degraded |
| `K4` | signed charge compatibility | pair-local | oracle-only diagnostic |
| `K5` | directional hydrogen bond | pair-local | **oracle-only, `NOT_EVALUABLE` at A5** |
| `K6` | aromatic orientation | pair-local | **oracle-only, `NOT_EVALUABLE` at A5** |

Only `K1` and `K2` may be used to decide
`PAIR_LOCAL_STRUCTURAL_MECHANISM_OBSERVED`. `K3`–`K6` are reported for failure
localisation and must be printed with their `NOT_EVALUABLE` flag attached.

## 3. Channel definitions

Notation: ligand heavy atom `a` at `x_a`; protein residue `r`; slot `s`;
`d(a,r) = min_{y ∈ heavy(r)} ‖x_a − y‖₂`. Note `heavy(·)` — see §5, defect D-2.

Common smooth gate, chosen bounded and Lipschitz so that quantisation error
propagates linearly rather than through a step:

```text
σ(d; d₀, w) = 1 / (1 + exp((d − d₀)/w))          σ ∈ (0,1), monotone decreasing
```

with `w = 0.5 Å` frozen. All channels below are defined at **exact residue**
resolution first; the slot-level target is the deterministic sum over the slot,
which is what makes the Stage 1 ceiling measurable as a difference.

### K1 — pocket burial coverage
```text
k1(a, r) = σ(d(a,r); 6.0, 0.5)
K1(a, s) = Σ_{r ∈ s} k1(a, r)            K1(P,L) = Σ_a Σ_s K1(a,s) / N_atoms
```
Units: dimensionless residue-count. Bounded by `|s|`; complex-level bounded by
`L`. Normalised for reporting by `N_atoms`.

### K2 — apolar-contact burial
```text
π(r) ∈ {0,1}   apolar side-chain indicator, frozen table:
               {ALA, VAL, LEU, ILE, MET, PHE, TRP, PRO, CYS} → 1, else 0
α(a) ∈ {0,1}   ligand apolar-atom indicator: carbon with no bonded N/O/S/P,
               taken from the CCD bond graph
k2(a, r) = α(a) · π(r) · σ(d(a,r); 4.5, 0.5)
```

### K3 — close-range packing
```text
k3(a, r) = σ(d(a,r); 3.6, 0.5)
```

### K4 — signed charge compatibility (oracle-only)
```text
q(r) ∈ {−1,0,+1}  {ASP,GLU}→−1, {LYS,ARG}→+1, HIS→0 (protonation unobserved)
q(a) = CCD formal charge
k4(a, r) = − q(a) · q(r) · σ(d(a,r); 5.0, 0.5)
```

### K5, K6 — oracle-only, angular
`K5` requires the D–H···A angle; `K6` requires ring-plane normals. Both are
defined from exact coordinates only and are `NOT_EVALUABLE` at any deployable
arm. Definitions are deferred to the run in which the oracle arm is executed;
writing them here would imply an A5 evaluability that Finding M-7 forbids.

## 4. Required property checks — all `[BLOCKED]`

| # | Property | Test | Tolerance | Status |
|---|---|---|---|---|
| P1 | precise definition | §3 | — | SPECIFIED |
| P2 | units / normalisation | §3 | — | SPECIFIED |
| P3 | boundedness | `0 ≤ k ≤ 1` per pair; slot sum ≤ `|s|` | exact | BLOCKED |
| P4 | ligand-atom permutation invariance | permute CCD atom order, recompute | `1e-9` | BLOCKED |
| P5 | residue permutation invariance | permute within-slot residue order | `1e-9` | BLOCKED |
| P6 | rotation invariance | random SO(3) on the complex | `1e-9` | BLOCKED |
| P7 | translation invariance | random `R³` shift | `1e-9` | BLOCKED |
| P8 | determinism / repeatability | recompute, compare bitwise | exact | BLOCKED |
| P9 | non-degeneracy | per-channel variance over complexes > 0; not constant within complex | declare before scoring | BLOCKED |
| P10 | locality class declared | `K1–K4` pair-local; aggregates complex-level | — | SPECIFIED |
| P11 | deployment observability | see §6 | — | SPECIFIED |

P6/P7 hold analytically for every channel in §3 because each depends on
coordinates only through Euclidean distances. They must still be executed: the
frozen pipeline reads `Cartn_*` as `float32`, so the empirical tolerance is a
numerical-precision claim, not a mathematical one.

## 5. Teacher-fidelity defects inherited from the frozen path

**D-1 — ligand/protein hydrogen asymmetry (Stage 1, M-3).**
`_ligand_coordinates` excludes `type_symbol == "H"`; `_protein_residue_atoms`
does not. The frozen `distance_bin` supervision therefore uses protein hydrogens
when deposited. The `d(a,r)` in §3 is specified over **heavy atoms only**,
deliberately diverging from the frozen supervision. This divergence must be
measured, not assumed small: it is one of the candidate explanations for any
oracle-versus-slot gap and must be reported as its own term.

**D-2 — `"X"` residues (Stage 1, M-2).**
Residues without a tabulated one-letter code align against BLOSUM62's `X` row
rather than failing closed. `π(r)` and `q(r)` are undefined for them. Rule:
residues mapping to `"X"` contribute `0` to `K2`/`K4` and are counted in a
dedicated `unresolved_chemistry_residues` census. They still contribute to `K1`,
which needs only geometry.

**D-3 — cofactor and non-drug-like ligands.**
The governed corpus contains cofactors (the first record of
`pilot20k_holo_governed_v1/complexes.jsonl` is `101m` with `HEM`, a
metalloporphyrin). Metal-coordination geometry is not modelled by any channel in
§3 and `K4` will misassign it. A frozen pre-scoring exclusion rule for
metal-containing and non-drug-like CCD components is required, registered before
outcomes are inspected.

## 6. Deployment-observability statement

| Channel | Needs at deployment | Observable pose-free? |
|---|---|---|
| `K1`, `K2`, `K3` | ligand graph + protein sequence + frozen P1B geometry | **yes** — all three are P1B outputs, no holo coordinates required |
| `K4` | as above + per-residue charge | yes for `q(r)` (sequence-derived); `q(a)` from CCD |
| `K5`, `K6` | angles | **no** — not observable at deployment; oracle-only |

Teacher labels themselves are built from holo coordinates and are training-time
only. The *predictors* in arms A1–A5 use only deployment-observable inputs. This
separation is what makes a PASS meaningful and must be re-verified in code.

## 7. What a PASS here would and would not authorise

A reproducibility PASS on `K1`/`K2` authorises **only** running the Stage 3
observability ladder. It is not evidence of mechanism, and structural
reconstruction PASS at Stage 5 authorises only a separately registered
source-affinity experiment. No channel defined here may enter production `z`.

## 8. Stage 2 verdict

```text
STAGE_2_SPECIFIED_NOT_EXECUTED
  core channel set narrowed to {K1, K2} by Stage 1 Finding M-7/M-8
  K5 (directional H-bond) demoted to oracle-only NOT_EVALUABLE
  three teacher-fidelity defects registered (D-1 hydrogens, D-2 "X", D-3 cofactors)
  all eleven property checks BLOCKED_NO_COMPUTE
```

`STRUCTURAL_TEACHER_NOT_REPRODUCIBLE` is **not** declared. Non-reproducibility
requires a failed check; no check was run.
