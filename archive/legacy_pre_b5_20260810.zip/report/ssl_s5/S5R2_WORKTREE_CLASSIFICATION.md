# Working-tree classification — after the S5R-2 correction bundle

Date: 2026-08-09, revised after Phase 1–4. **Nothing has been staged, unstaged,
deleted, committed or pushed.** Inventory and recommendation only.

## A. Production surfaces — verified unmodified

`git status --porcelain` over `theory/`, `model/`, `contracts/`, `scripts/`,
`weights/`, `config/` returns **empty**. `git diff --check` clean. Regression
**75 passed** after the corrections.

## B. Modified tracked files (6) — now carry the corrected verdict

| File | State after correction | Commit-ready? |
|---|---|---|
| `history.md` | F-96 retained unedited; **F-97 appended** withdrawing its specific claims. +452 lines, nothing removed. | **Yes** |
| `project_state.json` | rewritten to the corrected verdict, layer state, closure topology, panel plan, forbidden claims | **Yes** |
| `report/CURRENT_RESEARCH_STATUS.md` | withdrawal notice prepended; original retained below a `SUPERSEDED` heading | **Yes** |
| `report/EXPERIMENTAL_EVIDENCE_LEDGER.md` | withdrawal block with the four-unit table prepended; original retained | **Yes** |
| `task.md` | active stage = S7 registered/not authorized | **Yes** |
| `experiment.md` | previous confirmation-block wording explicitly corrected | **Yes** |

## C. Staged additions (16) — restored provenance, unchanged from the audit

Required and unchanged: the 12 `report/ssl_b2_structural_observability/` S4
artifacts (the 1,118-complex exposure registry), the 6 restored
`research/ssl_b2_structural_observability/*.py`, `TEACHER_CONTRACT.md`,
`LICENSE_AND_PROVENANCE_AUDIT.md`, and
`research/crossed_panel_deployability/xp2_core.py` (a genuine import dependency).

**One exception unchanged:** `research/ssl_b2_structural_observability/7ioj.npz`
(3.7 MB) has **zero** code or documentation references. It is an S2-era fixture
swept in by the directory-level checkout. Recommend leaving unstaged or
documenting it in `DATA_AVAILABILITY.md`.

## D. Untracked code (14) — research only, none in a production path

The 12 S5R-2 scripts, plus two added by this correction bundle:

| File | Role |
|---|---|
| `s5r2_supersede.py` | builds the superseded-artifact registry |
| `PREREG_S7_EXACT_RESIDUE_LOCAL_MECHANISM.md` | **the new registration**, SHA-256 `497ffda5…` |

**`s5r2_ladder.py` is deliberately left unedited** despite carrying defect D-4
(missing `lig_valid` intersection). Editing it would break the correspondence
between its recorded hash and the artifact it produced. The corrected value is
published in the audit; the fix is mandatory in the S7 implementation.

**Commit-order requirement:** the two preregistrations
(`PREREG_S5R2_…`, `PREREG_S7_…`) must be committed **first and separately**, with
their hashes recorded, before any S7 score exists. That is the specific failure
this bundle is correcting.

## E. Untracked outputs — `report/ssl_s5/` (33 files)

| Group | Status |
|---|---|
| `S5R2_LADDER/CENSUS/CONTROL_MAP/LIGAND_CONTROL_MAP/BUILD_MANIFEST/SECTION_PROBE.json` | required evidence, retained |
| `S5R2_HEAD_SYNTHETIC.json`, `S5R2_HEAD_REAL.json` | **authoritative**, retained |
| `S5R2_HEAD_SYNTHETIC_NORM.json`, `S5R2_HEAD_REAL_NORM.json` | **superseded diagnostics**, retained with hashes |
| `S5R2_RESULT.json` | **superseded**, retained; replaced by `S5R2_RESULT_CORRECTED.json` |
| `S5R2_EXACT_RESIDUE_EVAL.json` | retained, **labelled post hoc and not reproducible from retained artifacts** |
| `S5R2_FINAL_REPORT.md`, `S5R2_FAILURE_LOCALIZATION.md` | retained with **correction notices prepended**; original text preserved |
| `S5_*` (9 files, F-95 session) | historical, marked superseded in the registry |
| `S5R2_INDEPENDENT_EVIDENCE_AUDIT.{md,json}`, `S5R2_ARTIFACT_CONSISTENCY_AUDIT.json`, `S5R2_SUPERSEDED_ARTIFACTS.json`, `S5R2_RESULT_CORRECTED.json`, `U0_U3_AND_LSMF_REPRODUCIBILITY_AUDIT.json`, `BOUNDARY_ADJUDICATION_AND_EVIDENCE_COMPARISON.md`, `S5R2_WORKTREE_CLASSIFICATION.md` | **the correction bundle** |

## F. Generated data — correctly excluded

`dataset/processed/ssl_s5/` is **84 MB**, covered by `.gitignore:30`
(`dataset/**`), confirmed with `git check-ignore -v`. Leave excluded; it is
regenerable from the frozen banks.

Standing gap: because per-arm predictions were never persisted separately, these
ignored files are the only backing for the zero-parameter arms. **S7 §5.2 makes
prediction persistence a precondition of reporting any metric.**

## G. Unrelated / not required by this work

- `research/ssl_b2_structural_observability/7ioj.npz` — see §C.
- `dataset/raw/crossed_panels/bindingdb/*.zip` — raw XP3/XP4 acquisition,
  untouched, **not opened** during any phase. Present but unrelated to S5R-2,
  S7, or the unverifiable U0–U3 claims.

## H. Recommended commit bundle

1. Commit `PREREG_S5R2_…` and `PREREG_S7_…` **first**, hashes recorded.
2. Commit the `report/ssl_s5/` correction bundle plus the retained originals.
3. Commit the 6 modified status documents.
4. Commit the restored provenance (§C) **excluding `7ioj.npz`**.
5. Do **not** push until reviewed.
