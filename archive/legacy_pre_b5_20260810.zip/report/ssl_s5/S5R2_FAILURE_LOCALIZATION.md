# S5R-2 — failure localization

> ## ⚠ CORRECTION NOTICE — 2026-08-09, post independent audit
>
> Two rows of the §2 taxonomy table are corrected; the rest stands.
>
> * **"objective / optimization defect — REJECTED … one real defect found and
>   repaired"** — the "defect" was an artefact of a 32-complex smoke test. The
>   registered synthetic run already passed module participation. The row should
>   read simply **REJECTED**, with no repair narrative.
> * **"insufficient data — REJECTED"** — must be **RE-OPENED**. Under the
>   registered closure-component unit the test split contains only **54**
>   independent components, the largest holding **89.1 %** of it. Effective
>   replication is far lower than the 359/198 figures quoted below, and no
>   registered condition retains a positive lower bound under that unit.
>
> The chain in §1 is corrected to end at:
> `SLOT_PROXY_POCKET_CHEMISTRY_SIGNAL_OBSERVED_AS_DEVELOPMENT_EVIDENCE`, with
> `EXACT_RESIDUE_PAIR_MECHANISM_NOT_IDENTIFIED`.
>
> Authority: `S5R2_INDEPENDENT_EVIDENCE_AUDIT.md`, `S5R2_RESULT_CORRECTED.json`.

Date: 2026-08-09. Registered by
`research/ssl_b2_structural_observability/PREREG_S5R2_POCKET_CHEMISTRY_ENRICHMENT.md`.
All numbers are on the P1B **test** split, which the checkpoint never trained
on, with **protein homology groups** and **Bemis-Murcko scaffolds** as bootstrap
units and the wider of the two intervals reported.

## 1. Where the chain now stands

```text
sequence + 2D ligand graph
  -> correct-protein contact/distance geometry             PASS   (P1B gate, prior)
  -> partner-sensitive structural compatibility            PASS   (prior)
  -> aggregate mechanism readout                           LIGAND-DOMINATED (S4, prior)
  -> pair-local pocket-chemistry enrichment `e`            PASS on the registered
                                                            slot-level target
  -> the same channel de-proxied to exact residues         LIGAND MARGIN NOT
                                                            SEPARABLE FROM ZERO
  -> correct-protein affinity increment                    NOT TESTED (frozen)
  -> k<=5 identifiable support section                     NOT IDENTIFIED on the
                                                            structural channel
  -> biological z admission                                NOT AUTHORISED
```

## 2. Diagnosis against the registered failure taxonomy

| Candidate | Verdict | Evidence |
|---|---|---|
| **insufficient data** | **REJECTED** | 14,895 usable complexes, 3,606 homology groups, 1,449 test complexes in 359 groups / 198 scaffolds. Destructive controls separate cleanly (`AG` R² = −0.0006, `AS` R² = +0.0004, `AR` R² = −0.0023). Intervals are narrow enough to resolve 0.02. |
| **underdetermined estimand** | **CONFIRMED, and it is the load-bearing one** | The registered target `e` is computed on the frozen 128-slot map. That target is a *proxy*. Re-derived at exact residue resolution from raw coordinates, the slot target itself explains only R² = 0.516 [0.397, 0.616] (APOLAR) of the biological quantity. Conclusions therefore depend on which target is meant, and the two disagree at exactly one place — condition 2. |
| **representation failure** | **CONFIRMED, quantified** | 94.0 % of complexes have `L > 128`, so LEMMA-NONIDENT applies almost everywhere. Occupied slots hold 2.46 residues on average (p95 = 5, max 8) and **69.1 % of occupied slots are chemically mixed** (1,303,872 / 1,886,412). This is the mechanism of the ceiling above; it is a property of the frozen slot map, not of any model. |
| **objective / optimization defect** | **REJECTED for the registered claim; one real defect found and repaired in the auxiliary head** | Stage 4: the 1.73 M-parameter head recovers a known function of the frozen pair state (loss 0.0760 -> 0.0383), so fitting is not broken. However the un-normalised run left the protein and geometry branches `NOT_CAUSALLY_USED` on the synthetic target, traced to a feature-scale imbalance (activation variance ligand 0.339 vs protein 0.018) — precisely the *normalisation* defect base prereg §7 says this control exists to catch. Repaired with frozen per-branch standardisation (constants, no added capacity). **None of this touches the registered claim, which is zero-parameter and involves no training at all.** |
| **ligand shortcut** | **CONFIRMED — the dominant defect at the CORE channel** | Ligand-only (`A1`) alone reaches R² = +0.409 [0.313, 0.495] against the exact-residue apolar enrichment. The deployable arm reaches +0.486 [0.382, 0.584]. The increment is **+0.078 [−0.003, +0.152]** — the lower bound crosses zero. On the registered slot target the same gap is +0.107 [+0.024], i.e. it passes. The entire disagreement between "PASS" and "not separable" sits here. |
| **missing partner specificity** | **REJECTED** | Wrong protein (`AD`, matched on residue-slot count and nearest length, different homology group, coverage 0.995) collapses: exact-residue gap `A5 − AD` = **+0.356 [+0.279, +0.431]**. The correct protein is unambiguously required. |
| **missing pair specificity** | **PARTIAL** | Wrong ligand with the correct protein (`AL`, different CCD hash, exact heavy-atom count, coverage 0.992) still reaches R² = +0.372. The pair-specific increment is `A5 − AL` = **+0.114 [+0.064, +0.165]** — real but small, and for `AROMATIC` it is +0.042 [−0.045, +0.128], not separable. Roughly three quarters of the deployable signal is a protein-only pocket property that does not depend on which ligand is bound. |
| **missing affinity direction** | **NOT TESTED** | No affinity value was read. Frozen by design; requires separate authorisation and preregistration. |
| **unidentifiable support section** | **CONFIRMED on the structural channel** | The numerical rank of the k-shot support design saturates at **2.84 of a possible 5** at `k = 5` (median condition number 6.51). Adaptation gain is small and changes sign with `k` (+0.064, +0.002, −0.045, +0.035). The global meta coefficient is the safe estimator. This is a structural-channel dry run and carries no affinity implication. |
| **innovation module not causally used** | See `S5R2_HEAD_REAL.json` | Full gradient-norm, parameter-movement, activation-variance, branch-ablation, input-shuffle and gradient-blocking audit reported there. |

## 3. Two registered hypotheses, both resolved

**H-DILUTION — REFUTED.** `PREREG_S5R_PAIR_LOCAL_AMENDMENT.md` registered that if
the ESM slot mean (Λ₅) rather than slot geometry (Λ₂/Λ₃) were the binding
constraint, replacing the mean-ESM slot state with explicit 20-dim slot
composition would recover part of the correct-minus-ligand gap at zero
parameters. Measured: explicit composition (`A5`, zero parameters) minus
pocket-weighted ESM (`A5e`, fitted 640-dim readout) = **−0.008
[−0.045, +0.041]**. They are indistinguishable. The frozen ESM slot states
already carry the slot-resolved composition; ESM pooling is **not** the binding
constraint. The registered consequence of refutation is that a larger ESM, ESM
fine-tuning, a deeper GNN, cross-attention, a knowledge graph and fusion all
remain unauthorised — and this measurement is now a positive reason, not just a
policy.

**T-RULE — applied and load-bearing.** `K1` pocket-burial coverage reaches
R² = +0.390, but `contact = 1[d ≤ 6]` **is** the tensor P1B minimised its loss
against. It is reported as `TAUTOLOGICAL_REFERENCE` and excluded from the
criterion. Without T-RULE this run would have reported a large "mechanism
observability" number that was training fit.

## 4. Precondition checks that passed

* **M-6 confirmed empirically at scale.** `contact == (distance_bin <= 1)` was
  verified on **55,162,405** masked pairs across all 117 v2 shards: **0
  violations**. `A4`/`A5` are non-nested on the label side, as amended.
* **Gauge exact.** `max_t |Σ_t e[t]| = 1.77e-16` over the test split — `e` lies
  in the tangent space of the 20-simplex to machine precision.
* **Bounded.** `max |e| = 0.566 ≤ 1`, with no clipping and no learned scale.
* **Non-degenerate.** Test-split sd = 0.125 (APOLAR); effective rank 19 of the
  19 available under the gauge.
* **Chemically sensible.** Mean enrichment is positive for G, H, Y, F, C, W and
  negative for E, A, L, P, V, K — the textbook binding-site signature, recovered
  without any binding-site label.
* **Oracle sanity.** `AO` returns R² = 1.0000 exactly, so the metric, the
  splits and the bootstrap plumbing are not silently broken.

## 5. What would move the boundary, and what would not

**Would not** (explicitly unauthorised, and now with measured reasons):
enlarging ESM or fine-tuning it (refuted by `A5 ≈ A5e`); a deeper GNN or
cross-attention (the ceiling is the slot map, not the encoder); more structural
data (the destructive controls already separate cleanly, so this is not a power
problem); lowering any Gate.

**Would**, in order of expected effect on the *measured* defect:

1. **A finer protein index than 128 sequence-linear slots.** 69.1 % of occupied
   slots are chemically mixed and the slot target caps at R² ≈ 0.52 of the
   biological quantity. This is a change to a frozen contract and requires its
   own preregistration; it is *not* a capacity increase.
2. **A ligand-stratified estimand.** The dominant defect is that ligand identity
   predicts pocket class. Any next-stage design must report the increment over
   ligand-only as the primary quantity, on the de-proxied target, not on the
   slot proxy.
3. **Channels with a robust ligand-only margin.** On the exact-residue target,
   `DONOR` (+0.153 [+0.044, +0.259]) and `NEG` (+0.211 [+0.085, +0.324]) retain
   a separable protein-specific increment where `APOLAR` does not. This is a
   **hypothesis generated by this run, not a result**: `APOLAR` was the
   registered CORE channel and cannot be replaced post hoc. It may be
   registered as the core channel of a future experiment.
