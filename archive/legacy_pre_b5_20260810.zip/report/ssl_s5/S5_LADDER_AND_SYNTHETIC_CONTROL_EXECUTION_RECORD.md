# S5 Stages 3–5 — observability ladder and synthetic control: execution record

Date: 2026-08-09.
Status: **NOT RUN.** Blocked upstream at the Stage 0 environment gate.

This file exists so that the absence of ladder and synthetic-control numbers is
recorded as a *blocked stage*, not as a null result. A blocked stage is not
evidence about biology and must never be cited as one.

## 1. Why not run

| Precondition (from the required sequence) | Status |
|---|---|
| Execution environment available | **FAIL** — sandboxed Linux workspace would not start (7 attempts) |
| Registered artifacts recoverable | **FAIL** — S2 teacher source and S4 exposure registry absent (Stage 0 §4) |
| Mapping coverage passes | BLOCKED — not measurable |
| Teacher reproducible and non-degenerate | BLOCKED — not measurable |
| Slot information ceiling adequate | BLOCKED — only the static lemma is available |
| Ladder shows non-ligand correct-protein signal | NOT RUN |
| Synthetic trainability control passes | NOT RUN |

GPU training is therefore **not authorised**. No checkpoint, no gradient trace,
no prediction file and no metric JSON was produced, because none should have
been.

## 2. Ladder design, frozen for the next session

Identical rows, split, teacher labels, task weights and metrics across all arms.
Inference and bootstrap units are **protein-homology / scaffold closure
components**; atom–residue pairs are never treated as IID.

| Arm | Inputs | Purpose |
|---|---|---|
| `A0` | train mean / prevalence | null |
| `A1` | ligand-only local chemistry | ligand shortcut |
| `A2` | protein-only residue-local state | protein-only baseline |
| `A3` | `A1` + `A2`, no P1B geometry | pair chemistry without geometry |
| `A4` | `A3` + frozen P1B contact probability | contact retention |
| `A5` | `A4` + frozen P1B 5-bin distance distribution | full deployable P1B state |
| `A6` | `A5` with score-blind deranged protein (< 40 % identity, different closure component) | nuisance derangement |
| `A7` | `A5` with within-complex pair/geometry shuffle | geometry necessity |
| `A8` | capacity-matched random features | realisation control |
| `AO` | exact holo coordinates + teacher chemistry | oracle ceiling, not deployable |

**Carry-forward from Stage 1, Finding M-6.** `contact ≡ 1[distance_bin ≤ 1]` up
to a null set. `A4` and `A5` are therefore not information-nested on the label
side; any `A5 − A4` gap measures the two frozen heads, not extra structural
information, and must be labelled that way in the report.

**Carry-forward from Stage 1, §4.** Add one arm:

| `A5c` | `A5` with the mean-ESM slot state replaced by an explicit 20-dim slot residue-type composition vector | tests hypothesis H-DILUTION at zero extra capacity |

`A5c` is the discriminator between "the slot geometry is the ceiling" and "the
ESM slot mean is the ceiling". It adds ~20 input dimensions and no parameters to
any encoder, so it does not violate the no-module-stacking constraint.

Required per-channel reporting: correct-minus-{ligand-only, protein-only,
deranged, pair-shuffle, random}; per-complex performance; protein-cluster macro
performance; scaffold-overlap sensitivity; component bootstrap intervals;
target support by complex; train/validation/test generalisation gaps.

## 3. Synthetic trainability control, frozen for the next session

Construct a teacher **exactly representable** from the frozen A5 inputs — i.e. a
function of (atom-local state, slot-local state, contact probability, distance
distribution) with a known closed form. Establish, in order: analytic teacher
attainability; correct-protein partner sensitivity; an exact or near-exact
linear witness; objective consistency at the teacher solution; solver
convergence; train and held-out reconstruction; and failure under `A6`/`A7`.

Use objective-aligned regression or residual-difference regression. **Do not**
use a logistic ranking objective whose finite teacher solution is not
stationary — this was the identified defect in E0S/E0R (`history.md` F-71…F-78),
and repeating it would re-diagnose a solved problem.

A synthetic failure is `SYNTHETIC_TRAINABILITY_DEFECT` — a mapping, objective,
conditioning or optimisation fault. It is never evidence that biology is absent.

## 4. Anti-shortcut criteria, restated

A PASS requires **all ten**: beats ligand-only; beats protein-only; beats
deranged; beats pair/geometry shuffle; beats capacity-matched random; replicates
over independent protein components; is not explained by ligand scaffold
overlap; remains pair-local and permutation invariant; requires no complete
protein-by-ligand panel; reads no affinity or recipient labels.

Thresholds stay as preregistered: `R²(correct vs mean) ≥ 0.02`,
`R²(correct) − R²(ligand-only) ≥ 0.02`, `− R²(deranged) ≥ 0.02`,
`− R²(pair-shuffle) ≥ 0.02`, each with 95 % LCB above zero, on `K1` or `K2`
only. **No threshold may be relaxed to compensate for a failed control, and no
control failure may be answered by increasing model size.**

## 5. Verdict

```text
STAGE_3_NOT_RUN_BLOCKED_UPSTREAM
STAGE_4_NOT_RUN_BLOCKED_UPSTREAM
STAGE_5_NOT_AUTHORISED
```

None of `LIGAND_SHORTCUT_ONLY`, `FROZEN_P1B_LOCAL_STATE_INSUFFICIENT`,
`SYNTHETIC_TRAINABILITY_DEFECT` or
`PAIR_LOCAL_STRUCTURAL_MECHANISM_OBSERVED` is available from this session.
