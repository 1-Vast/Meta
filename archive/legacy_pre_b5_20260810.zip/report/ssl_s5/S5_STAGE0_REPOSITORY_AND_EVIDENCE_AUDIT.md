# S5 Stage 0 — repository and evidence audit

Date: 2026-08-09.
Method: read-only inspection of the working tree. No process was executed.
Verdict: `S5_EXECUTION_ENVIRONMENT_UNAVAILABLE` + `S5_ARTIFACT_RECOVERY_REQUIRED`.

## 0. Execution environment — hard blocker

The sandboxed Linux workspace failed to start on every attempt in this session:

```text
Workspace unavailable. The isolated Linux environment failed to start
(failed to set session disk path: session disk not found: ...\claudevm.bundle\sessiondata.vhdx)
```

Seven attempts, spread across the session, all failed identically. Consequences:

| Capability | Status |
|---|---|
| SHA-256 verification of any manifest or checkpoint | UNAVAILABLE |
| `gemmi` / `parasail` mmCIF and alignment re-derivation | UNAVAILABLE |
| Reading `.npz` supervision or ESM shards | UNAVAILABLE |
| `git` branch / worktree / commit recovery | UNAVAILABLE |
| Observability ladder, synthetic control, GPU head | UNAVAILABLE |
| `conda run -n drug python -m pytest -q` regression | UNAVAILABLE |

Every numeric quantity required by Stages 1–5 is therefore `BLOCKED_NO_COMPUTE`.
No numeric claim in this audit set was estimated, imputed or carried over from
prose. Statements below are either (a) direct file content, or (b) exact
consequences of frozen source code, which are verifiable by reading.

## 1. Branch and working tree

| Item | Finding | Evidence |
|---|---|---|
| Active branch | `main` | `.git/HEAD` = `ref: refs/heads/main` |
| Working-tree cleanliness | NOT VERIFIED | requires `git status`; no shell |
| Remote sync state vs `git@github.com:1-Vast/Meta.git` | NOT VERIFIED | requires `git ls-remote`; no shell |

Synchronization was not attempted. The task authorises it only if explicitly
required; it is not required to complete a read-only audit, and it cannot be
performed without a shell.

## 2. Required-reading inventory

| # | Requested path | Status |
|---|---|---|
| 1 | `AGENTS.md` | **ABSENT.** No `AGENTS.md` exists anywhere in the tree. The functional equivalent is `AGENT_HANDOFF.md` (read). |
| 2 | `report/EXPERIMENTAL_EVIDENCE_LEDGER.md` | present, read |
| 3 | `report/CURRENT_RESEARCH_STATUS.md` | present, read |
| 4 | `EVIDENCE_CONSOLIDATION_AND_FAILURE_TRIAGE.md` | present, read |
| 5 | `task.md` | present, read |
| 6 | `experiment.md` | present, read |
| 7 | `history.md` | present; 94 failure entries F-01…F-94 indexed, tail read |
| 8 | `project_state.json` | present, read |
| 9 | `theory/FINAL_FROZEN_THEORY/` | present (14 files incl. `THEORY_HASHES.json`); not modified |
| 10 | `research/ssl_b2_structural_observability/` | present but **source-empty** — see §4 |
| 11 | `report/SSL_DETAILED_REPORT_EVIDENCE_AUDIT.md` | present, read |
| 12 | `report/SSL_TEST_PLAN_REVIEW_AND_EXECUTION_BOUNDARY.md` | present, read |

## 3. Frozen P1B input contract — RECONSTRUCTABLE

The literal P1B contract does **not** need to be replaced by mean-ESM or ECFP
proxies. Every registered input is physically present:

| Artifact | Path | Declared contract |
|---|---|---|
| P1B checkpoint | `report/mechanism_refactor/p1b_pilot20k_seed17_v1/best.pt` | `checkpoint_sha256 = 90b0010b81fa2758a2dbdd1a8dbe06adae2e05acbbc267ccb62ceee6ff6c4f37` |
| P1B run manifest | same dir `manifest.json` | rank 32, hidden 128, GINE 3 layers, seed 17, `affinity_labels_used=false`, `csmo_used=false`, 11926/1490/1490 |
| P1B geometry schema | same dir `mechanism_schema.json` | 128 slots, contact ≤ 6.0 Å, bins (0,4,6,8,10,999) |
| Retained P1B Gate | `report/mechanism_refactor/p1b_gate_pilot20k_seed17_v4/` | `gate_report.json`, `per_complex_metrics.jsonl`, `control_mapping.jsonl`, `control_exclusions.jsonl` |
| Geometry supervision | `dataset/processed/open_structures/pilot20k_structure_supervision_v1/` | 14,906 pairs, 117 shards, per-shard SHA-256, `slot_policy = compact_resolved_label_seq_id_linear_bins` |
| Frozen ESM residue-slot bank | `dataset/processed/open_structures/pilot20k_esm2_t30_slots128_v1/` | 14,906 records, `esm2_t30_150M_UR50D` rev `a695f6045e2e32885fa60af20c13cb35398ce30c`, hidden 640, 128 slots, fp16 |
| Ligand bank | `dataset/processed/open_structures/pilot20k_mechanism_ligands_v1.pt` (+ `.manifest.json`) | atom feat 32, bond feat 12, `MAX_ATOMS = 128` |
| Homology split | `dataset/processed/open_structures/pilot20k_homology_split_v1/` | MMseqs2 `easy-cluster`, 40 % id, 80 % cov, 3,606 groups, `gate_status = PASS` |
| Governed complexes | `dataset/processed/open_structures/pilot20k_holo_governed_v1/complexes.jsonl` | 14,906 records, `records_sha256 = 4839a52d…` |
| Raw coordinates | `dataset/raw/open_structures/**/mmcif/*.cif.gz` | 20,295 files; CCD components alongside |
| Independent RCSB block (raw) | `dataset/raw/ssl_b2_independent/` | 1,887 mmCIF, `acquisition_manifest.json`, `candidate_ids.json`; RCSB query seed 20260808, single-protein-entity, X-ray ≤ 2.5 Å, released > 2024-01-01 |

Hash *values* are recorded; hash *verification* is `BLOCKED_NO_COMPUTE`.
Nothing in this audit binds the checkpoint to these inputs — that binding is a
declared field, not a verified fact, in this session.

## 4. Missing artifacts — `S5_ARTIFACT_RECOVERY_REQUIRED`

### 4.1 Pseudo-teacher and observability source code is deleted

`research/` contains **zero `.py` files**. It contains:

```text
research/README.md
research/ssl_b2_structural_observability/PREREG_S5_LOCAL_MECHANISM_OBSERVABILITY.md
research/ssl_gauge_fixed/PREREG_G0_DATA_FEASIBILITY.md
research/ssl_b2_structural_observability/__pycache__/s2_teacher.cpython-311.pyc
research/ssl_b2_structural_observability/__pycache__/s3s4_observability.cpython-311.pyc
research/crossed_panel_identification/__pycache__/{panels,xp1b_transfer,lowrank}.cpython-311.pyc
research/crossed_panel_deployability/__pycache__/{xp2_panel,xp2_core,xp2cd_section}.cpython-311.pyc
research/multipanel_interaction/__pycache__/{xp4_build,xp4_run}.cpython-311.pyc
```

Only compiled bytecode of the S2 deterministic six-channel pseudo-teacher and
the S3/S4 observability driver survives. `history.md` F-94 records the deletion
of 325 tracked files (86,869,561 bytes) under the former `research/` tree, with
recovery from Git commit `8b7789e`; `CURRENT_RESEARCH_STATUS.md` and the ledger
cite `3281780`, `12a2765`, `608decf` for the S0–S4 lineage.

Stage 0 requires verification of the **existing pseudo-teacher implementation**.
That artifact is not verifiable from the working tree. Recovering it from
bytecode by decompilation is explicitly rejected: it would produce a look-alike,
not the registered implementation.

### 4.2 The S4 exposure registry is not in the working tree

`project_state.json` asserts `development_exposed_structural_complexes: 1118`.
No file in the working tree enumerates those 1,118 PDB IDs, protein clusters or
Bemis–Murcko scaffolds. There is no `report/ssl_*` directory and no processed
`ssl_b2_independent` output; only the raw acquisition survives.

The active preregistration §3.3 requires the new S5 confirmation block to be
selected score-blind from RCSB entries **absent from both exposure registries**.
One of those two registries does not currently exist as data. The score-blind
sealing requirement is therefore not satisfiable today.

### 4.3 The exact residue→slot mapping is hashed but not persisted

In `scripts/build_structure_supervision.py::_geometry`, the mapping dictionary

```python
mapping = {"ligand_atom_names": ligand_names,
           "protein_label_seq_ids": label_seq_ids,
           "sequence_length": sequence_length,
           "residue_slots": MECHANISM_RESIDUE_SLOTS,
           "slot_policy": "compact_resolved_label_seq_id_linear_bins"}
```

is reduced to `residue_mapping_hash` in `pairs.jsonl`; the mapping itself is
never written. `pairs.jsonl` also carries only
`source_split = "unassigned_homology_group"`. Reconstructing the exact residue
mapping therefore requires re-parsing every mmCIF with `gemmi` + `parasail`.
That is reproducible in principle and `BLOCKED_NO_COMPUTE` in practice.

## 5. Label-access counters

| Counter | Declared value | Action this session |
|---|---|---|
| `recipient_label_reads` | 0 | unchanged; no recipient file opened |
| `davis_label_reads` | 0 | unchanged; no DAVIS artifact opened |
| ChEMBL37 / BindingDB affinity values | frozen | unchanged; `chembl_37.db` never opened |

Files under `dataset/sealed/`, `dataset/processed/sealed/`,
`dataset/processed/canonical/DAVIS*` and
`dataset/raw/source_affinity/` were not read. The only `source_affinity` path
touched was a directory listing that returned `task_manifest.json` as a name in
a glob result; the file was not opened.

## 6. Frozen surfaces — untouched

`theory/FINAL_FROZEN_THEORY/`, `model/` (8 modules including
`mechanism.py`, `bands.py`, `mathematical.py`, `meta_operator.py`), production
`scripts/`, CSMO, Band, positive ridge, the simplex, the fixed mesh and
production `z` were read only. No write occurred outside `report/ssl_s5/`,
`research/ssl_b2_structural_observability/`, `history.md` and
`project_state.json`.

## 7. Stage 0 verdict

```text
S5_EXECUTION_ENVIRONMENT_UNAVAILABLE      (primary, blocking)
S5_ARTIFACT_RECOVERY_REQUIRED             (secondary, blocking §4.1, §4.2)
P1B_INPUT_CONTRACT_PRESENT_UNVERIFIED     (data present; hashes unverified)
```

Stage 0 does **not** pass. Stages 1–5 are not authorised to execute. The
partial, code-derived representation-contract findings that *were* obtainable
without compute are recorded separately in
`S5_MAPPING_AND_SLOT_RETENTION_AUDIT.md`; they are explicitly not a substitute
for the preregistered numeric ceiling.
