# S5 Stage 1 — mapping and information-ceiling audit

Date: 2026-08-09.
Status: **PARTIAL — STATIC ONLY.** The preregistered four-level numeric oracle
ceiling is `BLOCKED_NO_COMPUTE` (see Stage 0 §0). What follows is a static
analysis derived entirely from frozen source code and versioned contracts. Every
statement is labelled `[EXACT]` (a provable consequence of the cited code) or
`[BLOCKED]` (requires execution).

This document does **not** issue a `MAPPING_OR_SLOT_CONTRACT_FAIL_CLOSED`
verdict. Fail-closed requires measured retention against the preregistered
threshold. It records a representation-contract *finding* that reshapes what
Stage 2 may legitimately preregister.

## 1. The frozen contract, stated exactly

Sources: `contracts/mechanism.py`, `contracts/ligand_graph.py`,
`scripts/build_structure_supervision.py`, `scripts/cache_structure_proteins.py`,
`scripts/build_holo_complex_index.py`, `model/mechanism.py`.

```text
MECHANISM_RESIDUE_SLOTS   = 128
MAX_ATOMS                 = 128
ATOM_FEAT_DIM             = 32     BOND_FEAT_DIM = 12
DISTANCE_BINS_ANGSTROM    = (0.0, 4.0, 6.0, 8.0, 10.0, 999.0)
CONTACT_THRESHOLD_ANGSTROM= 6.0
```

### 1.1 Ligand atom mapping `[EXACT]`

`_ligand_coordinates` selects `HETATM` rows matching
(`label_asym_id`, `label_comp_id`, `label_seq_id`) with `type_symbol != "H"`,
canonicalises altlocs, and requires a **bijection** onto the CCD
`heavy_atom_names` list — otherwise `ValueError`. The canonical ligand atom
order is the CCD `_chem_comp_atom.atom_id` order. Mapping is therefore exact,
deterministic, and complete-or-fail. `atom_mapping_hash = sha256(atom names)`.

**Finding M-1 `[EXACT]`.** Ligand mapping is not a source of silent loss. It is
strictly all-or-nothing per complex. The registered ≥ 95 % coverage rule in the
prereg is redundant with the code, which already demands 100 % or raises.

### 1.2 Protein residue mapping `[EXACT]`

`_protein_sequence_mapping` builds a one-letter string over resolved
`label_seq_id`s (via `gemmi.find_tabulated_residue(...).one_letter_code`,
falling back to `"X"`), then Needleman–Wunsch aligns it to the canonical
sequence with `parasail.nw_trace_striped_16`, BLOSUM62, gap open 10, extend 1.
Only columns where both sides are non-gap are mapped.
`coverage = |mapped| / max(|resolved|, |sequence|)`; `_protein_residue_atoms`
raises below 0.9.

**Finding M-2 `[EXACT]`.** Modified residues without a tabulated one-letter code
become `"X"` and are scored against BLOSUM62's `X` row. They are not excluded;
they are *aligned weakly*. A run of modified residues can therefore shift the
local alignment frame rather than fail closed. The prereg's stated exclusion of
"modified residues without a declared parent" is **not implemented** in the
frozen path.

**Finding M-3 `[EXACT]`.** `_protein_residue_atoms` filters on
`group_PDB == "ATOM"` with **no `type_symbol` filter**, in explicit contrast to
the ligand path which excludes `"H"`. Deposited protein hydrogens therefore
enter the min-distance computation. The teacher's distance bins are consequently
a function of the depositor's protonation/refinement choice, not of heavy-atom
geometry alone. This is a determinism defect with respect to the *biological
object*, even though the pipeline is bit-reproducible given a fixed mmCIF.

### 1.3 Slot assignment `[EXACT]`

Geometry side (`build_structure_supervision.py`):

```python
slot = min(MECHANISM_RESIDUE_SLOTS - 1,
           sequence_index * MECHANISM_RESIDUE_SLOTS // sequence_length)
```

ESM side (`cache_structure_proteins.py::_slot_pool`):

```python
slots = (arange(sequence_length) * MECHANISM_RESIDUE_SLOTS) // sequence_length
```

**Finding M-4 `[EXACT]`.** These are the same function. For any
`i ∈ [0, L-1]`, `i·128 // L ≤ (L-1)·128 // L ≤ 127`, so the `min(...)` clamp is
never active. **The geometry slot index and the ESM slot index agree exactly.**
No re-indexing is needed to join the two frozen banks. (The two manifests name
the policy differently — `compact_resolved_label_seq_id_linear_bins` versus
`compact_resolved_sequence_index_linear_bins` — but the implemented maps are
identical. The naming discrepancy is cosmetic and should be recorded, not
"repaired" in a frozen manifest.)

**Finding M-5 `[EXACT]`.** Binning is over **sequence index**, not space, and is
linear in the *full canonical* sequence length `L`, not in the resolved-residue
count. Slot `s` receives sequence indices
`i ∈ [⌈sL/128⌉, ⌈(s+1)L/128⌉)`, so its occupancy is `⌊L/128⌋` or `⌈L/128⌉`.

| `L` | residues per occupied slot | collision regime |
|---:|---|---|
| ≤ 128 | 1 | injective; `128 − L` slots empty |
| 256 | 2 | 2-fold |
| 384 | 3 | 3-fold |
| 512 | 4 | 4-fold |
| 768 | 6 | 6-fold |
| 1024 | 8 | 8-fold |

`[BLOCKED]` The empirical distribution of `L` over the 14,906 governed complexes
— hence the realised slot-multiplicity histogram, the mixed-residue-class slot
count, and the fraction of complexes in the injective `L ≤ 128` regime — cannot
be computed in this session. It is a pure read of the `sequence` field in
`pilot20k_holo_governed_v1/complexes.jsonl` and should be the first thing run
when a shell is available.

### 1.4 The pair-local observable `[EXACT]`

```python
distances[a, s] = min over residues r in slot s,
                  min over atoms x of r,  ||pos(a) − x||₂
contact[a, s]      = 1[d ≤ 6.0] · pair_mask
distance_bin[a, s] = digitize(d, [4, 6, 8, 10]);  255 where masked
```

**Finding M-6 `[EXACT]`.** `contact` is a deterministic function of
`distance_bin`. With `np.digitize(·, [4,6,8,10])` and `right=False`,
`bin ≤ 1 ⟺ d < 6`, while `contact ⟺ d ≤ 6`; the two differ only on the
Lebesgue-null set `{d = 6.0}`. The two supervision targets are therefore
redundant up to a null set. Ladder arms that add contact and then distance are
**not** information-nested on the label side; they differ only through the two
separately parameterised frozen heads. Any observed A4→A5 gap measures head
behaviour, not extra structural information, and must be reported as such.

## 2. The loss-operator chain

Exact holo coordinates reach the deployable pair-local state through five
composed lossy maps. Naming them separately is what makes failure localisable.

```text
exact holo coordinates
  │
  ├─ Λ₁  residue-atom min   : collapse each residue's atom set to one scalar
  │        loses: which atom (backbone O vs Lys NZ), all bond vectors, all angles
  │
  ├─ Λ₂  slot min           : collapse ⌈L/128⌉ residues to one scalar
  │        loses: multiplicity, identity of the argmin residue, every non-minimal distance
  │
  ├─ Λ₃  5-level quantisation (4/6/8/10 Å)
  │        loses: all within-bin variation; bin 0 spans the entire 0–4 Å regime
  │
  ├─ Λ₄  rank-32 bilinear head (model/mechanism.py)
  │        deployable A4/A5 inputs are NOT the tensors above but
  │        sigmoid(⟨Aa_n, Br_l⟩/√32) and softmax over 5 rank-32 bilinear forms
  │
  └─ Λ₅  ESM slot mean      : residue-local state = arithmetic mean of ⌈L/128⌉ ESM vectors
           loses: per-residue identity, in proportion to L
```

`Λ₄` is easy to overlook and is a hard ceiling in its own right: **any** pair
function built on frozen P1B predictions factors through a rank-32 bottleneck in
the (atom-state, slot-state) product, before the elementwise nonlinearity.

## 3. Non-identifiability lemma `[EXACT]`

**Lemma.** Let slot `s` contain residues `r₁, r₂` at distances `d₁ ≤ d₂` from
ligand atom `a`. Let the exact-residue teacher be additive and distance-decaying,

```text
T(a, s) = Σ_k φ(chem_a, chem_r_k) · ψ(d_k),      ψ strictly decreasing, φ > 0.
```

The frozen pair-local state retains `Λ₃(Λ₂(·)) = digitize(d₁)` and the slot mean
ESM vector, both of which are constant as `d₂` ranges over `[d₁, ∞)`, while
`T(a,s)` strictly decreases over an interval of positive length.

**Therefore `T` is not a measurable function of the frozen pair-local state**,
and `Var[T | frozen state] > 0` whenever the corpus contains any slot holding
≥ 2 residues at distinct distances — i.e. whenever `L > 128`.

The lemma establishes that the ceiling is strictly below 1 for every additive
pair-local teacher. It says nothing about magnitude. **The magnitude is the
preregistered quantity and it remains `[BLOCKED]`.** Do not read this lemma as
`FROZEN_P1B_LOCAL_STATE_INSUFFICIENT`; that verdict requires the measured
oracle-versus-actual gap.

## 4. Sequence binning has two opposite consequences — separate them

Slots bin sequence, but binding pockets are assembled from sequence-distant
residues. Two effects follow, and they must not be conflated:

**(a) `Λ₂` damages min-distance less than a spatial pooling would `[EXACT, qualitative]`.**
The residues sharing a pocket residue's slot are generically far from the
ligand, so the slot min is generically attained by the pocket residue itself.
The *geometry* channel survives `Λ₂` better than naive multiplicity arithmetic
suggests. This is consistent with P1B's identified contact/distance geometry.

**(b) `Λ₅` dilutes residue identity linearly in `L` `[EXACT, quantitative]`.**
The pocket residue contributes weight exactly `1/⌈L/128⌉` to its slot's mean ESM
vector: `1/4` at `L = 512`, `1/8` at `L = 1024`. Chemistry-bearing residue
identity is attenuated in direct proportion to protein length, while the
geometry channel is not.

**Hypothesis H-DILUTION (falsifiable, cheap, no capacity increase).**
If `Λ₅` rather than `Λ₂`/`Λ₃` is the binding constraint, then:

1. per-complex reconstruction quality decays monotonically with `L`; and
2. replacing the mean-ESM slot state with an **explicit slot residue-type
   composition vector** — a 20-dimensional count vector, exactly recoverable
   from the canonical sequence under the same binning, adding ~20 input
   dimensions and *no* parameters to the encoder — recovers a measurable part of
   the correct-minus-ligand-only gap.

If (2) fails, the constraint is `Λ₂`/`Λ₃` slot geometry and no protein encoder
of any size repairs it. If (2) succeeds, the correct minimal repair is to carry
composition, **not** to enlarge ESM, fine-tune it, or add a GNN. This is the
decisive discriminator between `FROZEN_P1B_LOCAL_STATE_INSUFFICIENT` and a
recoverable representation defect, and it is exactly one cheap experiment.

## 5. Channel representability under the frozen contract `[EXACT]`

This is the finding that most changes Stage 2. Each candidate channel is scored
by whether the information it *definitionally requires* survives `Λ₁…Λ₅`.

| Candidate channel | Requires | Survives? | Verdict at arm A5 |
|---|---|---|---|
| Pocket coverage / burial fraction | `Σ_s 1[bin ≤ k]` | yes — a function of retained bins | **REPRESENTABLE** |
| Hydrophobic burial | residue apolarity + distance-gated count | identity diluted by `Λ₅` (or explicit via composition); count destroyed by `Λ₂` min | **PARTIALLY REPRESENTABLE** |
| Steric overlap / clash | sub-4 Å resolution | bin 0 = `[0,4)` is a single bit | **SEVERELY DEGRADED** |
| Signed electrostatic compatibility | charged-group identity + signed distance | `Λ₂` merges an Arg and an Asp in one slot into a single min | **SEVERELY DEGRADED** |
| Directional hydrogen bond | donor/acceptor **atom** identity + D–H···A **angle** | `Λ₁` removes atom identity; no stage carries any angle | **NOT REPRESENTABLE** |
| Aromatic orientation | ring-plane normals | no orientation at any stage | **NOT REPRESENTABLE** |

**Finding M-7 `[EXACT]`.** The frozen contract carries **no angular
information whatsoever**. Directional hydrogen bonding and aromatic orientation
cannot be evaluated at arm A5 under any model. They are `NOT_EVALUABLE`, not
failures.

**Finding M-8 — the S4 continuity problem `[EXACT]`.** The two channels S4
recovered best were *directional H-bond totals* and *hydrophobic burial totals*
(ledger: `R² = +0.268` and `+0.299` versus mean). Directional H-bond is exactly
the channel the frozen contract cannot carry to A5. So the strongest historical
aggregate signal is **not** the right core channel to preregister for S5. Any
S5 design that keeps directional H-bond as a core channel is measuring the
oracle arm and the ligand arm against each other with the protein arm
structurally excluded — which would reproduce the S4 ligand-dominance result for
purely representational reasons and could be misread as biology.

**Consequence for Stage 2.** The preregistered *core* channel set must be drawn
from `{pocket coverage/burial, hydrophobic burial}`. Directional H-bond,
aromatic orientation, steric clash and signed electrostatics may be registered
only as **oracle-arm diagnostics** (`CO`), explicitly flagged `NOT_EVALUABLE`
at A5, and must never enter the feasibility criterion.

## 6. Preregistered numeric ceiling — `[BLOCKED]`

The four required levels remain unmeasured:

| Level | Quantity | Status |
|---|---|---|
| 1 | teacher from exact holo coordinates | BLOCKED_NO_COMPUTE |
| 2 | teacher after exact-residue → slot aggregation | BLOCKED_NO_COMPUTE |
| 3 | teacher after the P1B pair mask | BLOCKED_NO_COMPUTE |
| 4 | teacher after SSL-target normalisation | BLOCKED_NO_COMPUTE |

Also blocked: slot-multiplicity histogram, mixed-residue-class slot counts,
single-chain vs oligomer strata, modified-residue incidence, per-complex
mapping-coverage distribution, discard-reason census, and all hash verification.

## 7. Stage 1 verdict

```text
STAGE_1_PARTIAL_STATIC_ONLY
  M-4  geometry and ESM slot indices provably agree                    [EXACT]
  M-6  contact is redundant with distance_bin up to a null set         [EXACT]
  M-7  no angular information exists at any stage                      [EXACT]
  M-8  the S4-best channel is not A5-evaluable                         [EXACT]
  Lemma §3: additive pair-local teachers are non-identifiable from the
            frozen state whenever L > 128                              [EXACT]
  Numeric retention ceiling                                            [BLOCKED]
```

No terminal decision-tree verdict is issued. `MAPPING_OR_SLOT_CONTRACT_FAIL_CLOSED`
is **not** declared, because it requires a measured comparison against the
preregistered requirement.
