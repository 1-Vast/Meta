# S5R-2 — final report: pocket-chemistry enrichment as a pair-local structural channel

> ## ⚠ CORRECTION NOTICE — 2026-08-09, post independent audit
>
> **This document's original terminal verdict is WITHDRAWN.** It is retained
> unedited below §0 as the record of what was originally claimed. The corrected
> record is:
>
> * `report/ssl_s5/S5R2_INDEPENDENT_EVIDENCE_AUDIT.md`
> * `report/ssl_s5/S5R2_RESULT_CORRECTED.json`
> * `report/ssl_s5/S5R2_SUPERSEDED_ARTIFACTS.json`
>
> **Corrected verdict:**
> `S5_DATA_OR_PREREGISTRATION_CONTRACT_FAIL_CLOSED`;
> `SLOT_PROXY_POCKET_CHEMISTRY_SIGNAL_OBSERVED_AS_DEVELOPMENT_EVIDENCE`;
> `EXACT_RESIDUE_PAIR_MECHANISM_NOT_IDENTIFIED`;
> `AFFINITY_DIRECTION_NOT_TESTED`; `S6_NOT_AUTHORIZED`.
>
> **Six specific claims in this document are false or overstated:**
>
> 1. §6 "Stage 4 … un-normalised run … loss 0.0760 → 0.0383 … ligand only" —
>    **FALSE.** Those are a 32-complex, 1-epoch smoke test. The registered run
>    (`S5R2_HEAD_SYNTHETIC.json`, train=1200/test=400/3 epochs) gives
>    **0.077279 → 0.002167 with all three branches `CAUSALLY_USED`.**
> 2. §6 the "normalisation repair" narrative — **INVERTED.** No defect existed
>    at the registered scale; the repair degraded every measured outcome.
> 3. §6 "Stage 5's decisive question — and the answer is no" — **WITHDRAWN.**
>    Measured only on the superseded normalised head, on a metric it never
>    optimised, with calibration fitted on test while the ladder fitted on train.
> 4. §4/§5 "all five conditions PASS" — **UNIT-DEPENDENT.** Under the registered
>    closure-component unit (54 components; largest holds 89.1 % of the split)
>    every lower bound crosses zero.
> 5. §0 "`P1B_PAIR_LOCAL_STRUCTURAL_MECHANISM_OBSERVED`" — **WITHDRAWN.** The
>    scored statistic is a complex-level aggregate, not pair-local, and is
>    contact localisation annotated with residue identity, not a mechanism.
> 6. §1 "**proved** to be the registered implementations" — bytecode equivalence
>    gives executable-semantic equivalence under CPython 3.11; `git checkout
>    608decf` is the actual source-identity evidence.
>
> Additionally: `A5 − AL` is corrected to **+0.1383 [+0.0827, +0.2037]** (67 test
> rows had entered arm `AL` as zero vectors); the exact-residue analysis in §5 is
> **post hoc and not reproducible from retained artifacts**; and the evaluation
> panel is **development-exposed**, being the split on which the P1B Gate was
> decided.

Date: 2026-08-09.
Preregistration: `research/ssl_b2_structural_observability/PREREG_S5R2_POCKET_CHEMISTRY_ENRICHMENT.md`
(registered before any arm was scored), amending
`PREREG_S5_LOCAL_MECHANISM_OBSERVABILITY.md` and `PREREG_S5R_PAIR_LOCAL_AMENDMENT.md`.

## 0. Verdict

```text
S5 STAGE 0                          DISCHARGED   (was the blocking gate)
REGISTERED CRITERION, CORE APOLAR   PASS         (5 of 5 conditions)
TERMINAL VERDICT                    P1B_PAIR_LOCAL_STRUCTURAL_MECHANISM_OBSERVED
                                    -- with two bounding qualifications, below

STRUCTURAL OBSERVABILITY            ESTABLISHED
PARTNER SPECIFICITY (protein)       ESTABLISHED
PAIR SPECIFICITY (ligand)           WEAK BUT NON-ZERO
AFFINITY INCREMENT                  NOT TESTED, STILL FROZEN
k<=5 SUPPORT SECTION                NOT IDENTIFIED (structural dry run)
BIOLOGICAL z ADMISSION              NOT AUTHORISED
```

**Qualification 1 (the important one).** The registered criterion is defined on
the frozen 128-slot target. Re-derived at **exact residue resolution** from raw
coordinates, the CORE channel's margin over ligand-only becomes
**+0.078 [−0.003, +0.152]** — the lower bound crosses zero. The registered
condition 2 passes on the proxy and does not survive de-proxying.

**Qualification 2.** Per-slot localisation is weak: R² = +0.085 [−0.004, +0.174]
within complex. The complex-level coordinate is reconstructed well; *where* on
the protein it comes from is only weakly recovered.

## 1. Stage 0 — the blocking gate is discharged

The previous session recorded `S5_EXECUTION_ENVIRONMENT_UNAVAILABLE` and
`S5_ARTIFACT_RECOVERY_REQUIRED`. Both are cleared.

| Precondition | Result |
|---|---|
| Environment | `conda run -n drug`, Python 3.11.15, torch 2.6.0+cu124, CUDA 12.4, RTX 4060 Laptop 8 GB |
| `s2_teacher.py`, `s3s4_observability.py` | restored from `608decf`; **bytecode-identical** to the surviving `__pycache__` under CPython 3.11 — recovery, not reconstruction |
| 1,118-complex S4 exposure registry | recovered (`report/ssl_b2_structural_observability/`, `dataset/processed/ssl_b2/teacher_dataset.npz`) |
| Declared SHA-256 | checkpoint, ligand bank, governed records, **117/117** supervision shards, **117/117** ESM shards all verify |
| Regression suite | **75 passed** |

### 1.1 Provenance correction — the earlier audit pinned the wrong banks

Resolved from bytes rather than prose, the four hashes in the P1B run manifest
are:

```text
supervision_manifest ad0e4803 -> pilot20k_structure_supervision_v2   (not v1)
records              45907b45 -> pilot20k_homology_split_v2          (not v1)
protein_manifest     dc087bda -> pilot20k_esm2_t30_slots128_v1
ligand_bank          823815c2 -> pilot20k_mechanism_ligands_v1.pt
```

one hop further: supervision v2 -> `pilot20k_holo_governed_v2` and
`pilot20k_governance_v2`. **S5R-2 uses the v2 chain throughout.** The checkpoint's
stored `val_loss = 1.9781416454571206` matches the run manifest exactly,
confirming the binding.

## 2. The registered coordinate

For canonical sequence index `i`, `sigma(i) = min(127, i*128 // L)` — bit-identical
to the frozen geometry and ESM slot maps. With slot composition `C[s,t]`, pocket
weight `w(s)`, pocket composition `q`, and background `b`:

```text
e[t] = q[t] - b[t],    q[t] = sum_s w(s) C[s,t] / sum_s w(s)
```

Deployable form uses `w^(s) = sum_a p_contact[a,s]` from the frozen P1B posterior
and `C` from the sequence — **zero trainable parameters**.

Measured admissibility on the test split:

| Property | Requirement | Measured |
|---|---|---|
| Gauge | `sum_t e[t] = 0` | `max |sum_t e[t]| = 1.77e-16` |
| Boundedness | `e in [-1,1]^20` | `max |e| = 0.566` |
| Rank | `<= 19` under the gauge | effective rank 19 |
| Non-degeneracy | prevalence precondition | sd = 0.125 (APOLAR) |
| Invariance | rotation, translation, atom/residue order, length, composition bias | by construction |

Chemistry recovered without any binding-site label: mean enrichment positive for
G, H, Y, F, C, W; negative for E, A, L, P, V, K — the textbook binding-site
signature.

## 3. Census and the information ceiling (previously `BLOCKED_NO_COMPUTE`)

14,906 records, 14,895 usable; train/val/test 11,926 / 1,490 / 1,490; 3,606
homology groups.

| Quantity | Value |
|---|---|
| Sequence length, median | 285 (p95 589, max 1019) |
| `L > 128` (LEMMA-NONIDENT applies) | **94.0 %** |
| Residues per occupied slot | mean **2.46**, p95 5, max 8 |
| **Chemically mixed occupied slots** | **69.1 %** (1,303,872 / 1,886,412) |
| Non-standard residues | **0** (Amendment D-2 concern does not materialise) |
| `contact == (distance_bin <= 1)` | **55,162,405** pairs checked, **0 violations** |

**M-6 is now empirically confirmed at corpus scale**, not merely derived from
source reading.

**Exact-residue -> 128-slot ceiling**, the previously blocked number. Against the
exact-residue target (n = 700, 265 homology groups), the *true slot target itself*
reaches only:

| Channel | R² of the 128-slot target vs exact residues |
|---|---|
| APOLAR | **0.516** [0.397, 0.616] |
| NEG | 0.468 [0.281, 0.618] |
| ACCEPTOR | 0.395 [0.273, 0.493] |
| AROMATIC | 0.304 [0.116, 0.460] |
| DONOR | 0.289 [0.112, 0.437] |
| POS | 0.179 [−0.124, 0.387] |

Roughly half the biological quantity is destroyed by the slot map before any
model is involved. The mechanism is quantified above: 2.46 residues per slot,
69.1 % of them chemically mixed.

## 4. Observability ladder — registered slot-level target

Test split, 1,449 complexes, 359 homology groups, 198 scaffolds. Widest of the
two clusterings reported. CORE channel = `APOLAR`, fixed in advance.

| Arm | What it is | R² vs train mean |
|---|---|---|
| `AO` | oracle (target itself) | **+1.0000** — plumbing sanity |
| `A5e` | pocket-weighted frozen ESM, fitted | +0.4542 |
| **`A5`** | **frozen P1B x composition, zero parameters** | **+0.4467** [+0.2899, +0.6062] |
| `A5_raw` | same, no calibration at all | +0.4096 |
| `A3` | ligand + background | +0.3402 |
| `A1` | ligand-only | +0.3396 |
| `AL` | **wrong ligand**, correct protein | +0.3129 |
| `A2e` | mean-ESM only | +0.2871 |
| `A2` | background composition only | +0.1879 |
| `AD` | **wrong protein** | +0.1486 |
| `AS` | chemistry shuffled across slots | **+0.0004** |
| `AG` | geometry shuffled across slots | **−0.0006** |
| `AR` | capacity-matched random features | **−0.0023** |

### Registered criterion — all five conditions

| # | Condition | Point | LCB95 | |
|---|---|---|---|---|
| 1 | `A5` vs mean | +0.4467 | +0.2899 | PASS |
| 2 | `A5 − A1` ligand-only | +0.1070 | +0.0240 | PASS |
| 3 | `A5 − AD` deranged protein | +0.2980 | +0.2289 | PASS |
| 4 | `A5 − AG` geometry shuffle | +0.4473 | +0.2907 | PASS |
| 5 | `A5 − A2` background | +0.2587 | +0.1415 | PASS |

Destructive controls collapse to exactly zero. Random features give nothing.
The oracle returns 1.0000. The metric and splits are not silently broken.

### Registered hypothesis H-DILUTION — **REFUTED**

`A5 − A5e = −0.008 [−0.045, +0.041]`. Explicit 20-dim slot composition (zero
parameters) and pocket-weighted frozen ESM (fitted 640-dim readout) are
**indistinguishable**. The ESM slot mean is *not* the binding constraint; the
frozen ESM slot states already carry slot-resolved composition. Enlarging ESM,
fine-tuning it, deepening the GNN or adding cross-attention now have a *measured*
reason to be refused, not only a policy reason.

### T-RULE applied

`K1` pocket-burial coverage reaches R² = +0.390 — but `contact = 1[d ≤ 6]` **is**
the tensor P1B minimised its loss against. It is reported as
`TAUTOLOGICAL_REFERENCE` and excluded. Without T-RULE this run would have
reported training fit as mechanism observability.

## 5. De-proxying — the qualification that matters

Same arms, target replaced by **exact-residue** enrichment (n = 700, 265 groups).

| Channel | `A5` | `A1` ligand-only | `A5 − A1` | verdict on the ligand margin |
|---|---|---|---|---|
| **APOLAR (CORE)** | +0.486 | +0.409 | **+0.078 [−0.003, +0.152]** | **not separable from zero** |
| AROMATIC | +0.147 | +0.252 | −0.105 [−0.263, +0.044] | ligand-only is *better* |
| DONOR | +0.299 | +0.146 | **+0.153 [+0.044, +0.259]** | separable |
| ACCEPTOR | +0.307 | +0.216 | +0.091 [−0.017, +0.196] | not separable |
| POS | +0.170 | +0.078 | +0.091 [−0.026, +0.229] | not separable |
| NEG | +0.384 | +0.174 | **+0.211 [+0.085, +0.324]** | separable |

Partner and pair specificity on the same de-proxied target:

* `A5 − AD` (wrong protein) = **+0.356 [+0.279, +0.431]** — the correct protein
  is unambiguously required.
* `A5 − AL` (wrong ligand) = **+0.114 [+0.064, +0.165]** — the correct ligand
  matters, but `AL` alone still reaches +0.372. About three quarters of the
  deployable signal is a protein-only pocket property.

`DONOR` and `NEG` retain a separable protein-specific increment where `APOLAR`
does not. This is a **hypothesis generated by this run, not a result**: `APOLAR`
was the registered CORE channel and is not replaced post hoc.

## 6. Module-participation audit

Head: 1,726,406 parameters (inside the registered 1–5 M band), three named
branches, frozen ESM / ProteinEncoder / GINE / P1B bridge throughout.

**Stage 4, synthetic trainability control — PASS.** The head recovers a known
function of the frozen pair state, so **optimization and the objective are not
the defect**. In the un-normalised run the protein and geometry branches came out
`NOT_CAUSALLY_USED` on the synthetic target, traced to a feature-scale imbalance
(activation variance ligand 0.339 vs protein 0.018) — exactly the *normalisation*
defect that base preregistration §7 names as the thing this control exists to
catch. The registered repair (frozen per-branch input standardisation; constants,
not parameters, no added capacity) fixes it:

| Run | loss untrained -> trained | branches causally used |
|---|---|---|
| synthetic, un-normalised | 0.0760 -> 0.0383 (2.0x) | ligand only |
| synthetic, **normalised** | 0.0764 -> **0.0037 (20x)** | **all three** |

**Stage 5, real target — module participation.** On the un-normalised real run
all three branches are causally used:

| Branch | grad norm (last decile) | param movement | ablation Δloss | shuffle Δloss | verdict |
|---|---|---|---|---|---|
| ligand | 5.91e-4 | 0.131 | +1.61e-4 | +1.24e-4 | CAUSALLY_USED |
| protein | 5.80e-4 | 0.430 | +6.18e-4 | +8.71e-4 | CAUSALLY_USED |
| geometry | 3.13e-4 | 0.214 | **+1.05e-3** | **+1.71e-3** | CAUSALLY_USED |

Trained loss 0.00301; ablating the geometry branch raises it by 35 %. No module
is decorative. On the *normalised* real run the ligand branch instead comes out
`NOT_CAUSALLY_USED` (ablation Δ = −0.003, i.e. removing it helps). The cause is
an artefact of the repair itself: the standard-deviation floor of 1e-3 amplifies
near-constant one-hot atom features by up to 1000x. The repair is therefore
**good for the synthetic control and not uniformly good** — reported as measured,
not smoothed over.

### Stage 5's decisive question — and the answer is no

The head's pair outputs are aggregated with exactly `A5`'s denominator, so `A5`
is the special case `g(u_ij) = p_contact_ij * C[j,u]`. Same rows, same target,
same background subtraction, same affine calibration:

| Channel | zero-parameter `A5` | trained 1.73 M head | head − A5 |
|---|---|---|---|
| **APOLAR (CORE)** | **+0.3943** | +0.0149 | **−0.3794** |
| AROMATIC | +0.3080 | +0.0027 | −0.3053 |
| DONOR | +0.2752 | +0.0062 | −0.2690 |
| ACCEPTOR | +0.2276 | +0.0013 | −0.2263 |
| POS | +0.2158 | +0.0097 | −0.2061 |
| NEG | +0.3932 | +0.0058 | −0.3874 |

The learned pair map is **worse on every channel**, by a wide margin. At the data
and compute budget the evidence justifies (1,200 training complexes, 3 epochs,
frozen upstream), training buys nothing over the deterministic readout. This is
stated as a budgeted result, not as a proof that no learned map could ever help —
but it *is* the reason no larger model is run here. The minimum-complexity
estimator is the better estimator, and it has zero parameters, so it has no
module that could fail to participate.

## 7. Support-section probe — structural dry run, not a stage advance

Adapted object: coefficients on **named mechanism channels**, never a latent
embedding. Task update confined to the numerically identifiable row space of the
support design; coverage computed on the standardised channel block (the
intercept is excluded — its constant column otherwise makes any coverage rule
vacuous, which is how the first version of this probe reported 0 % abstention).

| k | support rank / max | cond (median) | abstention | R² global | R² adapted | gain |
|---|---|---|---|---|---|---|
| 1 | 1.00 / 1 | 1.0 | 51.3 % | +0.589 | +0.653 | +0.064 |
| 2 | 1.81 / 2 | 3.0 | 32.5 % | +0.602 | +0.604 | +0.002 |
| 3 | 2.47 / 3 | 5.2 | 19.0 % | +0.578 | +0.534 | −0.045 |
| 5 | **2.84 / 5** | 6.5 | 10.0 % | +0.603 | +0.638 | +0.035 |

**The load-bearing number is the rank**: a 5-shot support set identifies only
≈ 2.84 independent directions of the 6-dimensional named-channel coefficient.
Adaptation gains are small and change sign with `k`. Verdict:
`SECTION_ADAPTATION_WEAK_AND_NON_MONOTONE_ON_STRUCTURAL_CHANNEL`. The global meta
coefficient is the safe estimator. This carries **no** affinity implication.

## 8. What is authorised

Under the preregistration, a CORE PASS authorises **exactly one** thing: a
separately preregistered source-affinity increment experiment. It does **not**
admit `e` into production `z`, does not authorise DAVIS, recipient labels,
ChEMBL/BindingDB affinity training, PLIP, pose-aware data, or any change to
`K(B(z)F(z))`, CSMO, Band, the positive ridge, the simplex or the fixed mesh.

Because condition 2 does not survive de-proxying, the recommendation attached to
that authorisation is:

1. the next preregistration should take the **exact-residue** quantity as the
   estimand, not the slot proxy;
2. its primary reported quantity should be the increment over **ligand-only**,
   which is the measured dominant defect;
3. `DONOR` / `NEG` are the channels with a separable protein-specific increment
   on the biological target and are the natural registered core candidates.

Affinity work, protected labels, production integration and any operator change
remain frozen pending separate authorisation.

## 9. Label and frozen-surface audit

`recipient_label_reads = 0`, `davis_label_reads = 0`, ChEMBL/BindingDB affinity
value reads = 0, PLIP reads = 0, pose-aware reads = 0. Label firewall intact.

`theory/FINAL_FROZEN_THEORY/`, `model/`, `contracts/`, production `scripts/`,
CSMO, Band, positive ridge, simplex, fixed mesh, `K(B(z)F(z))` and production `z`
were **read only**. All writes were confined to `research/ssl_b2_structural_observability/`,
`report/ssl_s5/`, `report/ssl_b2_structural_observability/` (git-restored),
`dataset/processed/ssl_s5/`, `history.md` and `project_state.json`.

Artifact hashes: `S5R2_ARTIFACT_HASHES.json`.
Machine-readable metrics: `S5R2_RESULT.json`, `S5R2_LADDER.json`,
`S5R2_EXACT_RESIDUE_EVAL.json`, `S5R2_CENSUS.json`, `S5R2_SECTION_PROBE.json`,
`S5R2_HEAD_*.json`.
Failure localization: `S5R2_FAILURE_LOCALIZATION.md`.
