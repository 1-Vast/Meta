# S5 label-access audit

Date: 2026-08-09. Session type: read-only, no process execution.

## 1. Counters

| Counter | Before | After | Delta |
|---|---:|---:|---:|
| `recipient_label_reads` | 0 | 0 | 0 |
| `davis_label_reads` | 0 | 0 | 0 |
| ChEMBL37 affinity value reads | 0 | 0 | 0 |
| BindingDB affinity value reads | 0 | 0 | 0 |
| PLIP / typed-interaction label reads | 0 | 0 | 0 |
| Pose-aware data reads | 0 | 0 | 0 |

## 2. Protected paths — not opened

```text
dataset/sealed/DAVIS_v1/**
dataset/sealed/DAVIS_homology_v1/**
dataset/processed/sealed/DAVIS/**
dataset/processed/canonical/DAVIS_v1/**
dataset/processed/canonical/DAVIS_homology_v1/**
dataset/processed/canonical/DAVIS_mechanism_v2/**
dataset/processed/cache/protein_DAVIS.pt
dataset/raw/source_affinity/chembl37_sqlite_v1/**        (incl. chembl_37.db)
dataset/raw/dta/kiba.tab
dataset/processed/source_affinity/**
dataset/processed/davis_mechanism_p1c_v1/**
```

Three paths under `dataset/processed/source_affinity/` and
`dataset/sealed/` appeared as **names** in directory-glob results. No such file
was opened and no value was read. Name appearance in a filesystem listing is not
a label read.

## 3. Files actually opened this session

Governance, contract and report artifacts only:

```text
AGENT_HANDOFF.md
task.md   experiment.md   project_state.json
EVIDENCE_CONSOLIDATION_AND_FAILURE_TRIAGE.md
history.md                                    (index + tail only)
report/CURRENT_RESEARCH_STATUS.md
report/EXPERIMENTAL_EVIDENCE_LEDGER.md
report/SSL_DETAILED_REPORT_EVIDENCE_AUDIT.md
report/SSL_TEST_PLAN_REVIEW_AND_EXECUTION_BOUNDARY.md
report/mechanism_refactor/p1b_pilot20k_seed17_v1/{manifest,mechanism_schema}.json
research/ssl_b2_structural_observability/PREREG_S5_LOCAL_MECHANISM_OBSERVABILITY.md
contracts/mechanism.py   contracts/ligand_graph.py
model/mechanism.py
scripts/build_structure_supervision.py
scripts/cache_structure_proteins.py
scripts/build_holo_complex_index.py           (mapping functions only)
dataset/processed/open_structures/pilot20k_structure_supervision_v1/manifest.json
dataset/processed/open_structures/pilot20k_structure_supervision_v1/pairs.jsonl   (2 lines)
dataset/processed/open_structures/pilot20k_holo_governed_v1/complexes.jsonl       (2 lines)
dataset/processed/open_structures/pilot20k_esm2_t30_slots128_v1/manifest.json     (head)
dataset/processed/open_structures/pilot20k_homology_split_v1/manifest.json        (head)
dataset/raw/ssl_b2_independent/acquisition_manifest.json                          (head)
```

The two `complexes.jsonl` lines read contain structural and chemical fields
(`sequence`, `canonical_smiles`, `murcko_scaffold`, resolution, hashes). They
contain **no affinity field**. The `HoloComplex.v1` schema has no affinity
column.

## 4. Score-blindness status of the S5 confirmation block

`NOT ESTABLISHED.` The block cannot be sealed because the S4 exposure registry
enumerating the 1,118 development-exposed complexes is absent from the working
tree (Stage 0 §4.2). Sealing requires disjointness from *both* exposure
registries; one is unavailable. No candidate selection was performed, so no
score-blindness was consumed.

## 5. Verdict

```text
LABEL_FIREWALL_INTACT
NO_AFFINITY_VALUE_READ
NO_PROTECTED_LABEL_READ
S5_CONFIRMATION_BLOCK_NOT_SEALED
```
