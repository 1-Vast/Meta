# S5 literature evidence table

Date: 2026-08-09. Sources are primary papers and official dataset documentation.

**Standing rule: no entry below is evidence that a method will work in
MetaSieve.** Literature can only (a) name a mechanism, (b) supply a falsifier,
or (c) warn about a shortcut. Each row is therefore scored on six axes, and the
last column is the experiment that would kill it *here*.

## 1. Method assessment

### Row legend
- **Adds** — what information the method injects that MetaSieve lacks.
- **At deployment?** — does that information exist pose-free at inference time?
- **Earliest boundary?** — does it address *pair-local P1B observability*, the
  earliest unresolved question, or something downstream?
- **Shortcut risk** — ligand or target-family memorisation exposure.
- **Frozen-theory compatible?** — can its output be a bounded, named, compact
  observable admissible to a `k ≤ 5` support row space without touching
  `K(B(z)F(z))`, CSMO, Band, ridge, simplex or mesh?

---

**1. Fine-grained interaction SSL — atomic pairwise distance-map prediction + masked ligand reconstruction**
([ICLR 2024 proceedings](https://proceedings.iclr.cc/paper_files/paper/2024/file/2c28efa5a86dca4b603a36c08f49f240-Paper-Conference.pdf), [OpenReview](https://openreview.net/forum?id=AXbN2qMNiW), [arXiv 2311.16160](https://arxiv.org/pdf/2311.16160))

| | |
|---|---|
| Adds | pair-distance supervision at **atom×atom** resolution |
| At deployment? | the *supervision* is holo-only; the *student* is pose-free — same shape as S5 |
| Earliest boundary? | **yes** — closest published analogue of the S5 question |
| Shortcut risk | high: masked-ligand reconstruction is solvable from ligand alone |
| Frozen-theory compatible? | only if the head stays pair-local and the output is a named bounded channel |
| **Falsifier here** | run it at MetaSieve's resolution: atom×**slot**, not atom×atom. If the gain vanishes under `Λ₂` slot-min, the published result depends on resolution MetaSieve does not have. |

**Note.** This is the strongest external precedent, and it is also the sharpest
warning: its distance-map target is at a resolution the frozen 128-slot contract
provably destroys (Stage 1 Lemma §3).

---

**2. ProFSA — fragment-surroundings alignment pocket pretraining** ([arXiv 2310.07229](https://arxiv.org/pdf/2310.07229))

| | |
|---|---|
| Adds | contrastive alignment of pocket encoder to pseudo-ligand fragments |
| At deployment? | requires a **3D pocket**; MetaSieve is pose-free |
| Earliest boundary? | no — presupposes the pocket that S5 is testing for |
| Shortcut risk | moderate: fragment/pocket co-occurrence is a chemotype prior |
| Frozen-theory compatible? | no — contrastive latent, unnamed, uncalibrated dimension |
| **Falsifier here** | not runnable pose-free; would require the pose-aware S7 stage, which is not authorised |

---

**3. PLiSAGE — multimodal surface + geometry encoding, contrastive + reconstruction SSL** ([Bioinformatics 2025](https://academic.oup.com/bioinformatics/article/41/12/btaf608/8317435))

| | |
|---|---|
| Adds | molecular-surface geometry |
| At deployment? | no — surface requires a structure |
| Earliest boundary? | no |
| Shortcut risk | moderate |
| Frozen-theory compatible? | no — multimodal fusion is explicitly on the forbidden list |
| **Falsifier here** | out of scope; recorded to document that it was considered and rejected |

---

**4. Knowledge-based statistical pair potentials — PMF, DrugScore, DLIGAND2** ([J Mol Biol 1999](https://www.sciencedirect.com/science/article/abs/pii/S0022283699933715), [DLIGAND2, J Cheminform 2019](https://jcheminf.biomedcentral.com/articles/10.1186/s13321-019-0373-4))

| | |
|---|---|
| Adds | a **deterministic, named, distance-dependent atom-pair prior** — no training |
| At deployment? | yes if distances are available; MetaSieve has 5-bin slot-min distances |
| Earliest boundary? | **yes, as the correct null.** A tabulated pair potential evaluated on the frozen bins is the honest zero-parameter baseline for arm `A3`/`A4` |
| Shortcut risk | low — no fitted ligand parameters |
| Frozen-theory compatible? | yes — bounded, named, permutation-invariant, no latent |
| **Falsifier here** | if a trained pair-local head does not beat a tabulated pair potential evaluated on the same 5 bins, the head has learned nothing beyond known chemistry |

**This is the most useful row in the table.** The reference-state literature also
supplies the exact caution MetaSieve already applies to affinity: a pair
potential is defined only relative to a declared non-interaction reference
state, so it is a *structural statistic*, not an energy.

---

**5. Structure-teacher → sequence-student distillation** ([ACS Omega 2025, privileged KD for peptide–protein docking](https://pubs.acs.org/doi/10.1021/acsomega.5c00967); [multi-teacher protein embedding distillation, PMC11441318](https://pmc.ncbi.nlm.nih.gov/articles/PMC11441318/))

| | |
|---|---|
| Adds | training-time privileged structural information, inference-time sequence only |
| At deployment? | yes — that is the point of the paradigm |
| Earliest boundary? | **yes** — this is precisely S5's architecture |
| Shortcut risk | high: the student can match the teacher's *marginal* while ignoring the protein — exactly the S4 failure mode |
| Frozen-theory compatible? | yes if the student is a small pair-local head over frozen encoders |
| **Falsifier here** | the deranged-protein arm `A6`. Published KD work rarely runs it; MetaSieve requires it |

---

**6. Pose-free binding-site prediction from PLM residue embeddings — LaMPSite, Seq2Bind, SpatConv** ([arXiv 2312.03016](https://arxiv.org/abs/2312.03016), [Seq2Bind, PMC12639246](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC12639246/), [SpatConv, PMC12237623](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC12237623/))

| | |
|---|---|
| Adds | evidence that ESM-2 **per-residue** embeddings carry binding-site signal (Seq2Bind reports 67.4 % interface-residue recovery) |
| At deployment? | yes |
| Earliest boundary? | **yes, and it is the key contrast**: these methods use *per-residue* states; MetaSieve uses a mean over `⌈L/128⌉` residues |
| Shortcut risk | moderate |
| Frozen-theory compatible? | per-residue states are not in the frozen contract; only the 128-slot mean is |
| **Falsifier here** | arm `A5c` (explicit slot residue composition). If composition recovers signal that mean-ESM loses, the constraint is pooling dilution, not biology |

**Direct support for hypothesis H-DILUTION.** The pooling literature
([Pool PaRTI, PMC11956911](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC11956911/))
states plainly that parameter-free pooling causes significant information loss.
MetaSieve's `Λ₅` is parameter-free mean pooling with a length-dependent
compression ratio — the worst case that literature describes.

---

**7. Ligand-only / protein-only shortcuts and benchmark leakage** ([Nature Mach Intell 2025, "Resolving data bias"](https://www.nature.com/articles/s42256-025-01124-5) + [addendum](https://www.nature.com/articles/s42256-025-01174-9); [Leak-Proof PDBBind, arXiv 2308.09639](https://arxiv.org/abs/2308.09639))

| | |
|---|---|
| Adds | nothing — this is the shortcut warning |
| Key result | ~600 similarities between PDBbind training and CASF, touching **49 % of CASF complexes**; models trained on ligand **or** protein features alone, with no interaction modelling, are competitive on CASF-2016 |
| Earliest boundary? | yes — it validates MetaSieve's insistence on `A1`/`A2` baselines |
| **Consequence here** | MetaSieve's ladder already dominates published practice. The external S5–S9 report's numbers, lacking these controls, remain `EXTERNAL_CLAIM_NOT_REPRODUCED` and must not be treated as a starting point |

---

**8. MISATO / PLINDER as ensemble or gauge sources** ([MISATO, Nat Comput Sci 2024](https://www.nature.com/articles/s43588-024-00627-2); [PLINDER dataset docs](https://plinder-org.github.io/plinder/dataset.html))

Assessed in `report/SSL_TEST_PLAN_REVIEW_AND_EXECUTION_BOUNDARY.md`. Unchanged:
MISATO supports U3 bound-trajectory ensemble observability, not an unbound
reference or absolute free energy; PLINDER's BindingDB affinity annotation is
disabled upstream by a parsing bug and must not be used as a label source.
Neither addresses the earliest boundary. Not authorised.

## 2. What the literature does and does not license

**Licenses:** (i) the teacher–student pose-free architecture is standard and
does not by itself require new modules; (ii) a tabulated statistical pair
potential is a legitimate zero-parameter null; (iii) parameter-free mean pooling
is a documented, quantified source of information loss, which makes H-DILUTION a
mainstream hypothesis rather than a speculation.

**Does not license:** any claim that pair-local SSL will produce affinity value
in MetaSieve. Every published gain cited above is measured at atom×atom or
per-residue resolution. MetaSieve's frozen contract is atom×slot with `⌈L/128⌉`
residues collapsed by a `min` and 5-level quantisation. **No cited result
transfers across that gap, and Stage 1's lemma shows the gap is real, not
incidental.**

**Also does not license** adding a larger ESM, ESM fine-tuning, a deeper GNN,
generic cross-attention, a knowledge graph or multimodal fusion. Rows 2, 3 and 5
would each motivate one of those. Each is on the forbidden list, and none is
required by any evidence recorded here.
