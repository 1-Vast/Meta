# Boundary adjudication — exact-residue local SSL versus LSMF

Date: 2026-08-09. Inputs: the corrected S5R-2 record
(`S5R2_RESULT_CORRECTED.json`), the independent audit
(`S5R2_INDEPENDENT_EVIDENCE_AUDIT.md`), and the U0-U3/LSMF reproducibility audit
(`U0_U3_AND_LSMF_REPRODUCIBILITY_AUDIT.json`).

## 1. Evidence comparison

| | Exact-residue local structural SSL | LSMF (external proposal) |
|---|---|---|
| Preregistration in repo | none yet (this document proposes one) | **none** |
| Implementation in repo | none | **none** |
| Immutable manifests / predictions | none | **none** |
| Motivating evidence *inside* this repo | S5R-2 census: the 128-slot map destroys ~half the biological quantity (APOLAR retention R² = 0.516; DONOR 0.289; POS 0.179), with a measured mechanism (2.46 residues/slot, 69.1 % chemically mixed) | the claimed negative U0-U3 result, which is **NOT_REPRODUCED** |
| Motivating evidence *outside* this repo | prior art that sequence+ligand → binding residues is tractable (LiBRe 2026) | the external summary only |
| Named channels anchored? | to be required by preregistration | **not demonstrated**; four channels appear chosen to fit `k≤5`, which the audit flags as a known failure mode |
| Attacks the measured defect? | **yes** — the measured defect is the slot-map information ceiling and the ligand shortcut | partially, but via a new architecture rather than a new estimand |
| Complexity | zero- or low-parameter statistic first | a four-channel bilinear-plus-residual field with sparse aggregation |

**Reading.** The two proposals are not symmetric. The exact-residue direction is
motivated by a quantity **this repository measured**; LSMF is motivated by a
result this repository **cannot find**. Under the project's own evidence
precedence rule, the first is a justified hypothesis and the second is not yet
admissible as a motivated response to anything.

This is not a judgement on LSMF's merit as an architecture. It is a statement
about what the evidence currently licenses.

## 2. Required layer separation

| Layer | State | Basis |
|---|---|---|
| **Data power** | **INSUFFICIENT AS CURRENTLY CLOSED** | 54 closure components in the S5R-2 test split, largest holding 89.1 %. XP3/XP4 previously found low-noise panels have too few independent protein groups and broad panels have assay noise exceeding the interaction. |
| **Structural observability** | DEVELOPMENT EVIDENCE, slot proxy only | P1B gate (prior) plus S5R-2 on a development-exposed split under a non-registered unit |
| **Protein specificity** | DEVELOPMENT EVIDENCE, strong point estimate | `A5 − AD` = +0.298 (slot), +0.356 (exact, post hoc); collapses to LCB<0 under closure components |
| **Ligand specificity** | PARTIAL | `A5 − AL` = +0.1383 [+0.0827, +0.2037] corrected; control is scaffold-permissive in 15.6 % of pairs |
| **Pair specificity** | PARTIAL, MINORITY OF SIGNAL | wrong-ligand arm alone still reaches R² ≈ 0.31–0.37; roughly three quarters of the signal is protein-only |
| **Affinity direction** | **NOT TESTED** | no affinity value read anywhere |
| **Few-shot section identifiability** | NOT IDENTIFIED | numerical support rank 2.84 of a possible 5; gains change sign with k |
| **Production-law sufficiency** | NOT TESTED | no coordinate has entered `z`; `K(B(z)F(z))` unchanged |

## 3. Adjudication

**Supported: A and B jointly, with A dominant.**

> **A.** The available data *as currently closed* cannot identify a population
> protein-ligand interaction — 54 independent components with an 89.1 % giant
> component is not a panel that can resolve a 0.02 effect at 95 % confidence,
> and XP3/XP4 already recorded the public-panel noise floor.
>
> **B.** Global aggregation fails, but a localised **exact-residue** mechanism
> remains a justified hypothesis — because this repository *measured* that the
> 128-slot representation destroys about half of the biological quantity before
> any model runs, and that ceiling is a property of the representation, not of
> the biology.

**Rejected: C.** "A localised mechanism is already structurally observable and
only affinity calibration is missing" is exactly the claim the corrected record
withdraws. What is observable is contact localisation annotated with residue
composition, on a development-exposed panel, at slot resolution. That is not a
localised *mechanism*.

**Rejected: D.** "The public sequence-plus-2D interface lacks sufficient
protein-specific information" is contradicted by the P1B gate's own
correct-minus-deranged-protein contact AUPRC gap of +0.353 [+0.341, +0.365],
which is large, independently verified, and not in dispute. Protein-specific
information demonstrably reaches the interface; what has never been shown is
that it carries a *pair* mechanism or an affinity direction.

**Important asymmetry.** A is a statement about the *panels used so far*, not a
universal claim. It is remediable by a larger, properly closed, score-blind
panel — and §5 shows one exists. B is therefore testable rather than blocked.

## 4. Why the next stage must be structural, not affinity

Three independent reasons, all from repository evidence:

1. The measured ceiling is representational (slot map), so the first repair must
   change the *estimand*, not the loss.
2. The dominant defect is a **ligand shortcut** (ligand-only reaches R² = 0.409
   against the exact-residue apolar target). An affinity stage entered now would
   inherit that shortcut with a noisier label.
3. The registered promotion rule requires a structural basis to be frozen before
   any source-affinity Gate, and the structural basis is currently withdrawn.

## 5. Panel feasibility — the decisive practical finding

The S1b acquisition registered **15,003** RCSB candidates released ≥ 2024-01-01,
all disjoint from the 10,468 pilot20k-exposed PDB IDs. Of these:

| Set | Count | Exposure |
|---|---|---|
| S1b candidate pool | 15,003 | disjoint from pilot20k by construction |
| S4-scored (development-exposed) | 1,118 | **exposed** |
| Downloaded but never scored | 358 | quarantine — parse/quality rejects, biased remainder |
| **Never downloaded, never scored** | **13,885** | **score-blind** |

A genuinely untouched confirmation panel is therefore **available without any new
governance question** — same source, same licence (CC0-1.0), same release-date
rule, same acquisition script (`s1b_acquire_independent.py`), and already
disjoint from both exposure registries.

This removes the usual excuse for reusing a development split. It is the single
strongest argument that the next stage is worth running.

## 6. Recommendation

Register **one** structural stage (S7) on a new score-blind panel drawn from the
13,885 untouched IDs, with the **exact-residue** quantity as the target and the
128-slot readout demoted to a *control arm* rather than the target.

Do not run it yet. Do not train LSMF. Do not open affinity.
