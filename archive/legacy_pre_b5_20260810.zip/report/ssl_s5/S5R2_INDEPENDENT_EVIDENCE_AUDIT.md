# S5R-2 — independent evidence audit

Date: 2026-08-09. Mode: **audit only**. No training, no affinity read, no commit,
no repair, no S6. No file outside `report/ssl_s5/` was created or modified.

`AGENTS.md` does not exist in the tree (confirmed again); the functional
equivalent read was `AGENT_HANDOFF.md`.

## 0. Headline

The S5R-2 terminal verdict **`P1B_PAIR_LOCAL_STRUCTURAL_MECHANISM_OBSERVED`
is not supported and must be renamed.** Three of its four load-bearing words are
overstated: the scored statistic is not pair-local, it is not a mechanism, and
the PASS is unit-dependent in a way that reverses under the project's own
registered inference unit.

Separately, one reported result is **factually wrong**: the module-participation
narrative was taken from a 32-complex smoke test, not from the registered run.

The underlying signal is real and re-runnable. This is a **contract and scope
failure, not an evidence fabrication.**

## 1. What reproduced cleanly

| Check | Result |
|---|---|
| P1B input hash chain | **PASS** — checkpoint, ligand bank, 117/117 supervision shards, 117/117 ESM shards, all manifests |
| Provenance correction v1 → v2 | **VERIFIED** and material; the earlier audit was wrong, this one is right |
| `contact == (distance_bin <= 1)` | **VERIFIED** — 55,162,405 pairs, 0 violations |
| Gauge / boundedness of `e` | **VERIFIED** — `max|Σₜe| = 1.77e-16`, `max|e| = 0.566` |
| Census (94.0 % L>128, 2.46 res/slot, 69.1 % mixed) | **VERIFIED** from retained arrays |
| Slot-level zero-parameter arms (A5, AD, AL, AG, AS, AO) | **RECOMPUTED INDEPENDENTLY**, point estimates reproduce to 1e-15 |
| Destructive controls | **VERIFIED** — AG −0.0006, AS +0.0004, AR −0.0023; not artifacts |
| Regression suite | **75 passed** |
| Frozen surfaces `theory/ model/ contracts/ scripts/ weights/ config/` | **UNTOUCHED** (empty porcelain) |
| Label firewall | **INTACT** — no S5R2 script opens any protected path; matches are docstrings only |
| `git diff --check` | clean (CRLF warnings only) |
| JSON parse, 23 artifacts | 0 failures |

## 2. Material defects

### D-1 (DECISION-CHANGING) The bootstrap unit is not the registered unit

The base preregistration and `experiment.md` both state the inference units are
**closure components**. The implementation instead bootstrapped protein homology
groups and Bemis-Murcko scaffolds **separately** and took the wider interval.
Those are not the same object, and the two closures interlock heavily: one
scaffold spans **273 of 1,449** test complexes and one homology group spans 74.

Recomputed on the CORE channel, zero-parameter arms only (no fitting):

| Inference unit | n units | cond 1 `A5` vs mean | cond 3 `A5−AD` | `A5−AL` |
|---|---:|---|---|---|
| homology groups only | 359 | +0.447 [+0.304, +0.578] | +0.298 [+0.229, +0.371] | +0.134 [+0.076, +0.203] |
| scaffolds only | 198 | +0.447 [+0.290, +0.597] | +0.298 [+0.237, +0.353] | +0.134 [+0.075, +0.216] |
| homology × scaffold cells | 546 | +0.447 [+0.310, +0.577] | +0.298 [+0.235, +0.362] | +0.134 [+0.081, +0.196] |
| **true closure components** | **54** | **+0.447 [−0.020, +0.497]** | **+0.298 [−0.076, +0.354]** | **+0.134 [−0.161, +0.223]** |

Closure components = connected components of complexes sharing a homology group
**or** a scaffold. There are 54, and the largest holds **1,291 / 1,449 = 89.1 %**
of the test set.

**Under the project's own registered unit, no condition retains a positive lower
bound.** The reported PASS depends entirely on choosing a unit the
preregistration did not name.

This is a genuine adjudication question, not an automatic failure: full
transitive closure over two different similarity relations can chain nearly
everything together even when most pairs are unrelated, and a two-way
cluster-robust reading (the cells row) is a defensible standard. The audit does
not resolve it unilaterally. It records that **the result is unit-dependent and
that the registered wording favours the unit under which it fails.**

### D-2 (FACTUALLY WRONG) The module-participation narrative came from a smoke test

`S5R2_FINAL_REPORT.md`, `history.md` F-96, `CURRENT_RESEARCH_STATUS.md` and the
evidence ledger all state that the un-normalised synthetic run gave
`loss 0.0760 → 0.0383` with the protein and geometry branches
`NOT_CAUSALLY_USED`, and that a normalisation repair was therefore required.

The retained artifacts say otherwise:

| Source | train/test | loss | branches used |
|---|---|---|---|
| console `head_syn.log` (**authoritative full run**) | 1200 / 400, 3 epochs | 0.07728 → **0.00217** | — |
| `S5R2_HEAD_SYNTHETIC.json` (same run, mtime 12:06:58) | 1200 / 400 | 0.077279 → 0.002167 | **all three CAUSALLY_USED** |
| the numbers actually reported | **32 / 16, 1 epoch** | 0.07596 → 0.03833 | ligand only |

The reported figures are the smoke test executed at ~11:52, whose JSON was read
before the full run overwrote the same filename at 12:06:58. Schema evidence
confirms the ordering: `S5R2_HEAD_SYNTHETIC.json` lacks the
`input_standardisation` key, so it predates that edit; `S5R2_HEAD_REAL.json`
carries it.

**Consequences.** The full un-normalised synthetic run *passes* module
participation on its own. The "normalisation defect" never existed at the
registered scale. The repair applied in response to it made results **worse**
everywhere it was measured: synthetic 0.00373 vs 0.00217, real 0.00590 vs
0.00301, and it is what *created* the `NOT_CAUSALLY_USED` ligand branch in the
normalised real run (the 1e-3 standard-deviation floor amplifies near-constant
one-hot atom features by up to 1000×).

Every statement about the normalisation repair in the four downstream documents
is **superseded and must be struck**.

### D-3 The head-versus-A5 comparison exists only for the degraded head

`aggregate_vs_zero_parameter` is present **only** in `S5R2_HEAD_REAL_NORM.json`
— the normalised run, which is simultaneously the worse-fitting run and the one
whose module audit failed. The better un-normalised head (loss 0.00301, all
branches used) was **never** compared against A5.

Three further scope problems in that comparison:

1. **Calibration is fitted on the test rows** (`cal()` least-squares against test
   `y`), whereas the ladder fits calibration on train. The two published A5
   numbers (+0.4467 ladder, +0.3943 head comparison) are therefore not
   methodologically comparable and should never be printed side by side.
2. **Objective/metric mismatch**: the head minimises a pair-local Huber loss but
   is scored on a complex-level aggregate it never optimised.
3. Single seed, single budget, no sweep.

The defensible conclusion is narrow: *this head, this objective, this 1,200-complex
3-epoch budget, in its normalised variant, evaluated on a quantity it did not
optimise, adds no value over A5.* It does **not** support "learning buys
nothing", and the current wording approaches that.

### D-4 Arm `AL` was not masked by its own validity flag

`s5r2_ladder.py` intersects `valid` with `der_valid` only. `lig_valid` was never
applied, so **67 of 1,449 test rows** entered arm `AL` as an exact zero vector.

Recomputed with correct masking (1,382 rows, cells unit):
`A5 − AL = +0.138 [+0.083, +0.204]` versus the published
`+0.134 [+0.075, +0.216]`.

Direction and magnitude are unchanged; the defect **slightly understated** the
gap. It is immaterial to the conclusion but the published number is wrong and
must be corrected.

### D-5 The exact-residue analysis is post hoc and not reproducible from artifacts

* `s5r2_exact_eval.py` mtime **11:53:46**, after `S5R2_LADDER.json` at
  **11:52:37**. The de-proxying was designed **after** the ladder was scored. It
  was not preregistered and must be labelled exploratory.
* Its outputs were never persisted: neither the 700 `e_exact` vectors nor the
  sampled row indices were written. **The headline qualification
  `+0.078 [−0.003, +0.152]` cannot be recomputed from retained artifacts.**
  Re-deriving it requires re-parsing 700 mmCIF files.
* Selection: `rng(20260809).choice(test, 700, replace=False)` — outcome-blind in
  mechanism, and **0 of 700 parse failures**, so there is no outcome-dependent
  missingness in the sample itself. Coverage of the subset is 265 homology
  groups against 359 in the full test split; representativeness was never
  audited.

Mitigating: this post-hoc analysis *weakened* the author's own claim, which is
the benign direction. It is still exploratory evidence.

### D-6 The wrong-ligand control is scaffold-permissive

Registered policy was "different CCD hash, exact heavy-atom count" with **no
scaffold dissimilarity requirement**. Measured: **2,303 of 14,793 (15.6 %)**
wrong-ligand partners share the correct ligand's Bemis-Murcko scaffold.

This makes `AL` too strong a stand-in and therefore **understates** `A5 − AL`.
Direction is favourable, but the control is looser than the project's own
scaffold-closure discipline applies everywhere else.

### D-7 Control reuse induces unmodelled dependence

Protein derangement: coverage 0.9950, 0 same-homology-group violations, 0
self-assignments, but one partner reused up to **18×**. Ligand derangement:
coverage 0.9924, 0 same-CCD violations, 0 self-assignments, one partner reused
up to **58×**. Reuse is not represented in any bootstrap.

Pairwise sequence identity `< 40 %` was **not** verified directly; it is inferred
from MMseqs2 40 %/80 % cluster membership, which is not a pairwise guarantee.

### D-8 Fitted arms are not reproducible from retained artifacts

Only aggregate metrics were written. No per-unit SSE, no per-complex predictions
for `A1, A2, A2e, A3, A5e, AR`, and no head pair predictions. Conditions **2 and
5 of the registered criterion therefore cannot be independently recomputed**
without re-fitting, which this audit is forbidden to do.

### D-9 The evaluation split is development-exposed

`report/mechanism_refactor/p1b_gate_pilot20k_seed17_v4/gate_report.json` records
`split: "test"`, 1,477 of 1,490 records scored, `gate_status: PASS`. **The S5R-2
evaluation split is exactly the split on which the P1B Gate was decided.**

Correct classification: **checkpoint-held-out YES; research-development-exposed
YES; untouched confirmation set NO.**

`experiment.md` currently states a new score-blind RCSB block is "required only
for an external confirmation of these numbers, not for the internal result".
That **overstates**. Base preregistration §3.3 requires the confirmation block to
be drawn score-blind from entries absent from both exposure registries. That
requirement is **unmet**, and no S5R-2 number may be called confirmatory.

### D-10 Preregistration chronology is not independently demonstrable

`PREREG_S5R2_POCKET_CHEMISTRY_ENRICHMENT.md` is **untracked and never
committed** — `git log --all` returns nothing for it or for `report/ssl_s5/`.
The only chronology evidence is a single mutable mtime.

* prereg last edit **11:26:05**, ladder scored **11:52:37** — consistent with
  registration before scoring, but not cryptographic.
* The prereg's last edit is **after** `S5R2_CENSUS.json` (11:24:05), which
  reported per-channel slot→exact retention in which **APOLAR ranks highest**.
  Filesystem evidence cannot exclude that channel-related prereg content was
  informed by it. The stated derivation (Amendment 1 restricted the core set to
  K1/K2, K1 was removed by T-RULE, leaving K2 = apolar) is principled and
  plausible, but it is **prose, not proof**.
* The exact-residue rule was **not** preregistered (D-5).
* The synthetic normalisation repair *was* within scope — base prereg §7 names
  normalisation explicitly — but it was triggered by a false diagnosis (D-2).

Under the audit's own rule ("if chronology cannot be independently demonstrated,
label the result development evidence"), preregistration integrity is
`DEVELOPMENT_EVIDENCE_ONLY`.

### D-11 The source-recovery claim is overstated in wording

The report says the restored sources are "**proved** to be the registered
implementations". Bytecode equivalence under CPython 3.11 establishes
**executable-semantic equivalence, including docstrings and constants** (the
comparator walked `co_consts`). It does **not** establish byte-identical source:
comments, whitespace, and some equivalent constructions compile identically.

Correct wording: *semantically identical as executed under CPython 3.11*. The
recovery itself is sound; only the word "proof of byte-identity" is wrong. Note
the restore came from `git checkout 608decf`, so source identity is in fact
independently guaranteed by Git — the bytecode check is corroboration, not the
primary evidence, and the report inverted that emphasis.

## 3. Issue 1 — required decomposition

| Layer | Status |
|---|---|
| Pocket **localisation** | SUPPORTED — but by the prior P1B Gate, not by S5R-2 |
| Pocket **residue composition** | OBSERVABLE on the 128-slot proxy; unit-dependent |
| **Protein** specificity | SUPPORTED under separate/cell units; NOT under closure components |
| **Ligand** specificity | PARTIAL — `A5−AL` positive but small; not significant for AROMATIC |
| **Protein-ligand pair** specificity | PARTIAL — ~¾ of signal is protein-only |
| **Atom-residue pair-local interaction** | **NOT SUPPORTED** — per-slot R² = +0.085 [−0.004, +0.174] |
| **Structural mechanism** | **NOT SUPPORTED** — see below |
| **Affinity direction** | NOT TESTED |

**Why "mechanism" fails.** `A5 = p_contact(P1B) × C(sequence)`, where `C` is a
deterministic residue-type annotation of the canonical sequence. The statistic is
therefore *P1B's contact localisation, annotated with residue identity, then
aggregated to a complex-level 20-vector*. It recovers **chemistry aligned with
predicted contact geometry**. It does not model, and cannot evidence, a
biochemical interaction mechanism — there is no energetic term, no directionality
(finding M-7), and no interaction between the two factors beyond a product.

**Why "pair-local" fails.** Pair-local contact probabilities are consumed, but
the scored object is a complex-level aggregate, and the one genuinely pair-local
readout tested (per-slot burial) has a lower bound below zero. Issue 1's rule
applies directly.

`K1` was correctly excluded by T-RULE. `APOLAR` is one deterministic annotation
step away from `K1`, but the annotation carries information absent from the
contact tensor, so it is **not** tautological. It is, however, much closer to the
training target than "mechanism" implies.

## 4. Layer verdicts

| Layer | Verdict |
|---|---|
| Provenance | **VERIFIED** |
| Preregistration integrity | **DEVELOPMENT_EVIDENCE_ONLY** |
| Mapping / data contract | **VERIFIED** |
| Slot-proxy observability | **VERIFIED_WITH_SCOPE_CORRECTION** (real and recomputed; unit-dependent; not a mechanism claim) |
| Exact-residue observability | **NOT_REPRODUCIBLE_FROM_RETAINED_ARTIFACTS** (and post hoc) |
| Protein specificity | **VERIFIED_WITH_SCOPE_CORRECTION** (large and robust to arm choice; loses LCB>0 under closure components) |
| Ligand / pair specificity | **VERIFIED_WITH_SCOPE_CORRECTION** (partial; control scaffold-permissive; published number off by the AL mask defect) |
| Learned-head value | **VERIFIED_WITH_SCOPE_CORRECTION** (true only for the normalised head on a non-optimised metric with test-fitted calibration) |
| Module-participation evidence | **INTERNALLY_INCONSISTENT** (reported from a smoke test; authoritative run says the opposite) |
| Support-section identifiability | **VERIFIED_WITH_SCOPE_CORRECTION** — max defensible label is `SECTION_ADAPTATION_WEAK_AND_NON_MONOTONE_ON_STRUCTURAL_CHANNEL`; establishes nothing about affinity meta-learning |
| Affinity identification | **NOT_TESTED** |
| Production-z admission | **NOT_TESTED** — remains unauthorised |

## 5. Overall conclusion

```text
S5_DATA_OR_PREREGISTRATION_CONTRACT_FAIL_CLOSED
```

Chosen because four independent contract breaches co-occur, at least one of
which is decision-changing:

1. the inference unit used is not the registered one, and under the registered
   one the criterion fails (D-1);
2. a reported conclusion is drawn from a smoke test that the authoritative
   artifact contradicts (D-2);
3. the preregistration has no cryptographic chronology — untracked, uncommitted
   (D-10);
4. the confirmation-block requirement of base prereg §3.3 is unmet and the split
   is development-exposed (D-9).

This is a **contract** failure, not `S5_EVIDENCE_NOT_REPRODUCED`: the slot-level
signal was independently recomputed and is real, and the destructive controls sit
at zero.

**Single adjudication that would move this to conclusion 3
(`SLOT_PROXY_OBSERVABILITY_ONLY`)**: a written project ruling that "closure
component" means the two-way cluster / homology×scaffold-cell reading rather than
full transitive closure, *plus* correction of D-2, D-4 and the D-9 wording. Under
that ruling the slot-proxy observability survives with LCB +0.310 and the honest
label becomes `SLOT_PROXY_OBSERVABILITY_ONLY` — still not a biological PASS,
because the de-proxied core ligand increment has no positive lower bound.

`EXACT_RESIDUE_PAIR_MECHANISM_IDENTIFIED` is excluded outright.
`AFFINITY_ENERGETICS_IDENTIFIED` is excluded by construction: no affinity value
was read, and the label firewall was verified intact.

## 6. Must the terminal verdict be renamed?

**Yes.** `P1B_PAIR_LOCAL_STRUCTURAL_MECHANISM_OBSERVED` must be withdrawn and
replaced with the conjunction the evidence supports:

```text
SLOT_PROXY_POCKET_CHEMISTRY_OBSERVABLE            (unit-dependent)
PROTEIN_PARTNER_SPECIFICITY_IDENTIFIED            (unit-dependent)
PAIR_SPECIFICITY_PARTIAL
EXACT_RESIDUE_CORE_LIGAND_INCREMENT_NOT_IDENTIFIED
PAIR_LOCAL_INTERACTION_NOT_ESTABLISHED
STRUCTURAL_MECHANISM_NOT_ESTABLISHED
```

## 7. Is S6 authorized?

**No.** Not on this evidence. The de-proxied primary contrast has no positive
lower bound, the registered inference unit reverses the PASS, the panel is
development-exposed, and the preregistration lacks demonstrable chronology.

## 8. What must be corrected before any commit

1. **Strike** every statement about the un-normalised synthetic run and the
   "normalisation repair" from `S5R2_FINAL_REPORT.md`, `history.md` F-96,
   `report/CURRENT_RESEARCH_STATUS.md` and
   `report/EXPERIMENTAL_EVIDENCE_LEDGER.md`; mark `S5R2_HEAD_SYNTHETIC_NORM.json`
   and `S5R2_HEAD_REAL_NORM.json` as **superseded diagnostics**.
2. **Rename** the terminal verdict (§6) everywhere it appears, including
   `project_state.json`.
3. **Report all four bootstrap units** wherever the criterion is quoted, and
   record the unresolved adjudication rather than the most favourable number.
4. **Correct** the published `A5 − AL` to the masked value and fix the `lig_valid`
   intersection in `s5r2_ladder.py`.
5. **Label** the exact-residue analysis exploratory and post hoc; state plainly
   that it is not reproducible from retained artifacts.
6. **Correct** `experiment.md`'s claim that a score-blind block is needed only
   for external confirmation; classify the split as development-exposed.
7. **Soften** the bytecode claim to executable-semantic equivalence and credit
   `git checkout 608decf` as the primary recovery evidence.
8. **Persist predictions** before any future scoring: per-complex per-arm
   predictions, per-unit SSE, exact-residue vectors and sampled indices.
9. **Commit the preregistration with its hash before the next experiment is
   scored**, so chronology is cryptographic rather than prose.
10. Remove the self-referential entry for `S5R2_ARTIFACT_HASHES.json` from its
    own manifest (1 of 43 entries is a self-hash and always mismatches).

No repair, commit or S6 work was performed. Awaiting the second prompt.
