# S5 final report — pair-local structural observability

Date: 2026-08-09.
Session type: read-only audit. No process was executed.

**Headline.** The primary question — can self-supervised structural learning
repair the earliest unresolved biological boundary without ligand memorization
or model stacking — **was not answered, and could not have been answered in this
session.** Execution stopped at the Stage 0 environment gate. What *was*
obtained is a code-derived representation-contract analysis that materially
changes what S5 should be preregistered to test, and that would have caused a
misleading result had the ladder run unamended.

---

## 1. Established evidence (unchanged by this session)

Carried forward from `report/EXPERIMENTAL_EVIDENCE_LEDGER.md`; nothing here was
re-verified, because verification requires compute.

- The frozen mathematical operator is implemented and contract-tested.
- P1B identifies correct-protein contact and distance geometry
  (`PASS_GEOMETRY_IDENTIFIED`).
- Partner-sensitive structural compatibility exists.
- Historical global MIF, PCA, Ridge, spline, MLP and interaction-residual
  readouts did not establish a stable affinity increment over ligand-only.
- The S4 aggregate ESM + ECFP probe recovered H-bond and hydrophobic totals, but
  the signal was ligand-dominated
  (`AGGREGATE_ESM_ECFP_PROBE_NOT_PROTEIN_SPECIFIC`).
- S4 did not test the actual P1B atom-local, residue-local or atom-by-slot
  tensors.
- Affinity energetics are not identified; no biological statistic is admitted to
  `z`; there is no validated end-to-end DTA model.
- External S5–S9 numerical claims remain `EXTERNAL_CLAIM_NOT_REPRODUCED`.

**One correction to the working assumption.** The literal P1B input contract is
**not** missing. The checkpoint, geometry supervision (14,906 pairs, 117 hashed
shards), frozen ESM 128-slot bank, ligand bank, MMseqs2 homology split, governed
complex index and 20,295 raw mmCIF files are all present. No mean-ESM or ECFP
proxy substitution was needed, and none was made.

## 2. Structural SSL evidence obtained this session

All of it is `[EXACT]` — a provable consequence of frozen source code,
verifiable by reading, requiring no execution. None of it is numerical.

**2.1 The two slot maps provably agree (M-4).** The geometry slot index
`min(127, seq_idx·128 // L)` and the ESM slot index `(i·128) // L` are the same
function; the clamp is never active. The frozen banks join without re-indexing.
This removes a plausible failure mode before it costs a run.

**2.2 Contact is redundant with distance (M-6).** `contact ⟺ d ≤ 6` and
`bin ≤ 1 ⟺ d < 6` differ only on `{d = 6.0}`. Ladder arms A4 and A5 are not
information-nested on the label side; any gap between them measures two frozen
heads, not extra structure.

**2.3 The contract carries no angular information (M-7).** Directional hydrogen
bonding and aromatic orientation are `NOT_EVALUABLE` at the deployable arm under
any model, at any capacity.

**2.4 The S4-best channel is the one that cannot be tested (M-8).** Directional
H-bond was S4's strongest aggregate recovery *and* is `NOT_REPRESENTABLE` at A5.
Preregistering it as a core S5 channel would have produced structurally
guaranteed ligand dominance — a representational artefact indistinguishable, in
the output, from a real biological null. **This is the single most consequential
finding of the session.**

**2.5 Non-identifiability lemma.** For any additive, distance-decaying
pair-local teacher, `Var[T | frozen pair-local state] > 0` whenever a slot holds
≥ 2 residues at distinct distances — i.e. whenever `L > 128`. The direction of
the ceiling is proved. **The magnitude is not, and magnitude is what the
preregistered criterion needs.**

**2.6 Two confounded effects of sequence binning, now separated.** Slots bin
sequence, not space. Consequently the slot `min` is generically attained by the
pocket residue (geometry survives comparatively well), while the ESM slot mean
gives that residue weight exactly `1/⌈L/128⌉` (identity is diluted linearly in
`L`). Registered as hypothesis **H-DILUTION**, with a discriminating arm `A5c`
that swaps the mean-ESM slot state for an explicit 20-dimensional residue-type
composition vector — ~20 input dimensions, **zero new parameters, zero new
modules**. It decides between "slot geometry is the ceiling"
(`FROZEN_P1B_LOCAL_STATE_INSUFFICIENT`) and "mean pooling is the ceiling"
(`REPRESENTATION_DEFECT_RECOVERABLE`, repaired by carrying composition — not by
a larger ESM).

**2.7 Three teacher-fidelity defects registered.** D-1 protein hydrogens enter
the min-distance while ligand hydrogens do not; D-2 modified residues become
`"X"` and align weakly instead of failing closed, so the preregistered
modified-residue exclusion is not implemented in the frozen path; D-3 the
governed corpus contains cofactors and metalloporphyrins that no candidate
channel models.

## 3. Unresolved affinity claims

Unchanged and untouched. No affinity value was read; `recipient_label_reads` and
`davis_label_reads` remain 0; the label firewall is intact.

- Correct-protein affinity increment: **NOT IDENTIFIED.**
- `k ≤ 5` identifiable support section: **NOT IDENTIFIED.**
- Biological `z` admission: **NOT AUTHORISED.**
- Nothing in this session moves any of these.

The standing failure mode is unchanged:
`correct protein changes geometry or compatibility ≠ correct protein adds
transferable affinity-ranking information`.
This session adds a second, representational trap:
`a channel that reconstructs well ≠ a channel whose defining information
survives Λ₁…Λ₅`.

## 4. Blocked stages

| Stage | Status | Cause |
|---|---|---|
| 0 repository/evidence audit | **FAIL, blocking** | environment + missing artifacts |
| 1 mapping and ceiling | PARTIAL, static only | numeric ceiling needs compute |
| 2 teacher design | SPECIFIED, 0/11 checks run | needs compute |
| 3 observability ladder | NOT RUN | blocked upstream |
| 4 synthetic control | NOT RUN | blocked upstream |
| 5 lightweight GPU head | NOT AUTHORISED | preconditions unmet |

**B-1 — execution environment.** The sandboxed Linux workspace failed to start
on all seven attempts (`session disk not found`). No shell, Python, `gemmi`,
`git`, hashing, GPU or `pytest`. Every numeric quantity is `BLOCKED_NO_COMPUTE`.
The regression suite was **not** run; the last known state is the recorded
`75_PASSED_SSL_REPORT_CONTRACT_HARDENING`.

**B-2 — the registered pseudo-teacher source is deleted.** `research/` contains
zero `.py` files. Only `__pycache__/s2_teacher.cpython-311.pyc` and
`s3s4_observability.cpython-311.pyc` survive. Recovery is from commit `608decf`
/ `8b7789e`. Decompiling the bytecode is **rejected**: it produces a look-alike,
not the registered artifact, which is exactly the error the R-VERIFY rule
forbids.

**B-3 — the S4 exposure registry is absent.** `project_state.json` asserts 1,118
development-exposed complexes; no file enumerates them. The preregistration
requires the new confirmation block to be disjoint from *both* exposure
registries. One does not exist as data, so the block **cannot be sealed
score-blind today.**

No terminal decision-tree verdict is claimed. In particular
`MAPPING_OR_SLOT_CONTRACT_FAIL_CLOSED` is **not** declared: fail-closed requires
a measured retention below the preregistered requirement, and no measurement
exists. Declaring it on the strength of the lemma alone would be exactly the
overreach this project's ledger is built to prevent.

## 5. Authorized next actions, in order

1. **Restore an execution environment** (`conda run -n drug`).
2. **Run the cheapest decisive read first:** the sequence-length distribution
   over the 14,906 governed complexes in `pilot20k_holo_governed_v1/complexes.jsonl`,
   yielding the realised slot-multiplicity histogram and the fraction of
   complexes in the injective `L ≤ 128` regime. This is a pure text read, costs
   minutes, and calibrates the entire ceiling question.
3. **Restore** `s2_teacher.py` and `s3s4_observability.py` from `608decf` /
   `8b7789e` into `research/`.
4. **Recover or re-register** the 1,118-complex S4 exposure registry. If it is
   unrecoverable, register a replacement as a *new* registry with its own hash
   and say so; do not quietly reuse the number.
5. **Verify** every declared SHA-256 in the P1B input chain.
6. **Run the full regression suite.**
7. **Verify M-6 empirically** on the shards: `contact == (distance_bin <= 1)` on
   the masked support.
8. **Only then** execute Stage 1's four-level oracle ceiling, followed by
   Stages 2–4 under `PREREG_S5R_PAIR_LOCAL_AMENDMENT.md`.

## 6. Not authorized

GPU training; real ChEMBL/BindingDB affinity training; DAVIS or recipient
labels; PLIP labels or pose-aware data; production `z` admission; any change to
CSMO, Band, mesh, positive ridge, simplex or frozen theory; P2–P4; a larger ESM,
ESM fine-tuning, a deeper GNN, generic cross-attention, a knowledge graph or
multimodal fusion; and any relaxation of a Gate threshold.

## 7. Honest summary

The session produced no experimental result, and the absence is recorded as a
blocked stage rather than a null. Its value is entirely preventive: it
establishes, from frozen code alone, that the frozen 128-slot contract cannot
carry angular information, that the channel S4 recovered best is precisely the
channel S5 cannot evaluate, and that the pooled-ESM and pooled-geometry losses
are confounded in the base ladder in a way that would have made a failure
uninterpretable. Amending the preregistration before running is cheaper than
running and then arguing about what the number meant.
