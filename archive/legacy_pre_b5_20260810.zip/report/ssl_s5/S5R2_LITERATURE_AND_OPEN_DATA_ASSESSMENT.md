# S5R-2 — literature and open-data assessment

Date: 2026-08-09. Scope: what the external record does and does not license us to
assume about the boundary *"correct-protein geometry is identifiable, but a
transferable protein-specific affinity increment is not"*.

**Standing rule applied throughout:** none of the results below is project
evidence. They are read as (a) prior art establishing that a task is tractable
in principle, or (b) prior art establishing that a failure mode is real. No
external number is imported into any MetaSieve gate.

## 1. Is the P1B-class task (sequence + 2D ligand -> binding residues) real?

Yes, and it is an active 2026 problem, which matters because it means P1B's
`PASS_GEOMETRY_IDENTIFIED` is not anomalous.

| Work | Relevance |
|---|---|
| LiBRe, *J. Chem. Inf. Model.* 2026 — ligand-aware, **sequence-based** binding-residue prediction | Directly the P1B task class. Its stated motivation is that most predictors ignore the ligand although binding residues are defined by the interaction. It reports beating both sequence- and structure-based baselines, and shows embeddings vary with the bound ligand for a fixed sequence. |
| bindEmbed21 / bindNode24 — binding residues from protein embeddings alone | Establishes the protein-only ceiling for the same task; the useful contrast is that protein-only cannot be pair-specific. |
| Seq2Pocket — PLM fine-tuning plus structure-aware post-processing | Confirms pocket-level readouts are obtainable without a pose. |

**What we take:** the existence of a correct-protein, ligand-aware, pose-free
binding-residue signal is prior-art-plausible. This is consistent with the P1B
gate's own measured `correct - deranged_protein` contact AUPRC gap of
`+0.353 [0.341, 0.365]`, which is **project** evidence.

**What we do not take:** none of these works demonstrates an *affinity*
increment, and none of their numbers enters a MetaSieve gate.

## 2. Is "structural SSL passes, affinity does not follow" a real failure mode?

Yes, and it is documented outside this project. This is the single most
important external finding for S5R-2, because it is the reason a structural PASS
is registered as authorising **one** further experiment and nothing else.

* Pretraining-loss improvement does **not** reliably yield downstream gain;
  negative transfer is reported both for molecular property prediction and for
  protein function transfer (Hu et al., *Strategies for Pre-training GNNs*, and
  subsequent replications: 2/8 molecular datasets and 13/40 protein-function
  tasks showed negative transfer).
* Transferability-guided protein-ligand interaction work exists precisely
  because naive fine-tuning from a structural pretext can transfer negatively.
* Generalisation audits of DTA models report that models "develop spurious
  correlations from structural motifs in training data that compete with
  learning transferable physicochemical principles", and fail unpredictably on
  novel targets.

**What we take:** the project's refusal to promote a structural PASS to an
affinity claim is aligned with the external record, not conservative for its own
sake. It also supports registering **T-RULE** (a channel that is a function of
the pretext target measures training fit, not mechanism).

## 3. Meta-learning on named objects

* AdaMBind, *Nat. Commun.* 2026 — meta-learning DTA for low-data / unseen
  targets, few-shot.
* Similarity-aware evaluation work (arXiv 2504.09481) — argues DTA
  generalisation is routinely overstated by leaky splits.

**What we take:** few-shot target adaptation is an accepted framing, and the
credible critique of it is *evaluation leakage*, not architecture. This is why
S5R-2 keeps homology and scaffold closure and uses closure components as
bootstrap units rather than pairs.

**What we do not take:** we do not adopt any reported few-shot improvement as a
prior. MetaSieve's own XP1/XP2 already found interaction in consumed kinase
panels that failed the `k<=5` double-held-out and external-replication
requirements — a stronger, in-project reason for caution.

## 4. Open data — what is actually usable, and for what

| Resource | Affinity? | Licence posture | Admissible role here |
|---|---|---|---|
| **RCSB PDB** (used) | no | CC0-1.0 | The only source S5R-2 reads. 20,295 mmCIF already local; 14,906 governed complexes; 1,887 raw independent entries. |
| **PLINDER** | **no binding affinity at all** (449,383 systems, >500 annotations, curated low-overlap splits) | permissive | Could govern pocket/apo/holo and split quality. **Cannot** be a thermodynamic gauge — it has no affinity to gauge with. Confirms `task.md`'s existing position. |
| **MISATO** | inherits PDBbind affinities; adds QC-optimised ligand geometry + 10 ns MD | see PDBbind constraints | Ensemble/flexibility observability only, and only after a verified pose-aware state. Not acquired. |
| **BindingNet** | modelled complexes (~69,816) by superposition | — | Poses are *modelled*, not experimental. Inadmissible as geometry ground truth under the current teacher contract. |
| **PDBbind / LP-PDBbind** | yes, <20k | redistribution contract not verified compatible; project policy avoids it | Not used. LP-PDBbind's existence is itself evidence that the standard split leaks. |
| **ChEMBL37 / BindingDB** | yes | CC BY-SA 3.0 / CC BY 3.0 | Frozen. D0/D1 closure already established in-project. Not read in S5. |

**Assessment.** There is no open resource that would let S5 shortcut to an
affinity increment without opening a protected surface. The binding constraint
is not data volume: XP3/XP4 already measured that broad public panels carry
assay noise exceeding the interaction component, while low-noise panels have too
few independent protein groups. Acquiring MISATO or PLINDER now would add
structural breadth against a boundary that is not structural-breadth-limited.

**Conclusion:** no new acquisition is justified at this stage. S5R-2 runs
entirely on data already local and already governed.

## 5. What this assessment changes in the design

1. The core channel must not be a function of the pretext target — hence
   **T-RULE** and the demotion of `K1` to `TAUTOLOGICAL_REFERENCE`.
2. Because negative transfer is the documented norm, a structural PASS is
   registered as authorising exactly one separately preregistered affinity
   experiment, with its own thresholds.
3. Because leaky evaluation is the documented critique of few-shot DTA, the
   section probe reports support rank, conditioning, query coverage and
   abstention rather than a headline few-shot score.

## Sources

- [LiBRe: A Ligand-Aware Sequence-Based Binding Residue Prediction Model for Virtual Screening (JCIM 2026)](https://pubs.acs.org/doi/10.1021/acs.jcim.5c02883)
- [Protein embeddings and deep learning predict binding residues for various ligand classes](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8668950/)
- [bindNode24: competitive binding-residue prediction with a 60% smaller model](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC11957672/)
- [Strategies for Pre-training Graph Neural Networks](https://arxiv.org/pdf/1905.12265)
- [A transferability-guided protein-ligand interaction prediction method](https://www.sciencedirect.com/science/article/abs/pii/S1046202325000283)
- [Rethinking the generalization of drug target affinity prediction algorithms via similarity aware evaluation](https://arxiv.org/pdf/2504.09481)
- [A meta learning and task adaptive approach for drug target affinity prediction (Nat. Commun. 2026)](https://www.nature.com/articles/s41467-026-70554-5)
- [A generalizable deep learning framework for structure-based protein–ligand affinity ranking (PNAS)](https://www.pnas.org/doi/10.1073/pnas.2508998122)
- [PLINDER: Protein Ligand INteraction Dataset and Evaluation Resource](https://github.com/plinder-org/plinder)
- [MISATO: machine learning dataset of protein–ligand complexes (Nat. Comput. Sci. 2024)](https://www.nature.com/articles/s43588-024-00627-2)
- [Augmented BindingNet dataset (npj Drug Discovery)](https://www.nature.com/articles/s44386-024-00003-0)
- [ProFSA: Self-supervised Pocket Pretraining via Protein Fragment-Surroundings Alignment](https://arxiv.org/pdf/2310.07229)
