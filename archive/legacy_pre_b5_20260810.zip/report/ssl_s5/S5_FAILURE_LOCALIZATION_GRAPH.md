# S5 failure-localization graph

Date: 2026-08-09.

## 1. Where execution stopped

```text
                    [ Stage 0 : repository and evidence audit ]
                                     |
                    +----------------+----------------+
                    |                                 |
        environment available?              artifacts recoverable?
                    |                                 |
                  FAIL  <-- STOP                     FAIL  <-- STOP
        sandbox disk not found                 s2_teacher.py deleted (.pyc only)
        no shell / python / gpu / git          S4 exposure registry (1,118) absent
                    |                                 |
                    +----------------+----------------+
                                     |
                                     v
        [ Stage 1 ] mapping + ceiling ......... PARTIAL, static only
                                     |
                                     v
        [ Stage 2 ] teacher design ............ SPECIFIED, 0/11 checks run
                                     |
                                     v
        [ Stage 3 ] observability ladder ...... NOT RUN
                                     |
                                     v
        [ Stage 4 ] synthetic control ......... NOT RUN
                                     |
                                     v
        [ Stage 5 ] lightweight GPU head ...... NOT AUTHORISED
```

## 2. Blocking-cause taxonomy

| Node | Cause class | Repairable by | NOT repairable by |
|---|---|---|---|
| B-1 execution environment | infrastructure | restarting the sandbox, or running locally in `conda run -n drug` | any modelling decision |
| B-2 `s2_teacher.py` deleted | provenance | `git show 608decf` / `8b7789e` restore into `research/` | decompiling the `.pyc` (produces a look-alike, not the registered artifact) |
| B-3 S4 exposure registry absent | provenance | recovering the 1,118-complex ID list from the same commits, or re-deriving and re-registering it as a *new* registry | selecting a confirmation block without it |
| B-4 residue→slot map not persisted | contract | re-parsing mmCIF with `gemmi`+`parasail` (deterministic) | reading `pairs.jsonl`, which stores only the hash |
| B-5 numeric ceiling unmeasured | consequence of B-1 | executing Stage 1 | the static lemma, which bounds direction but not magnitude |

## 3. Pre-identified failure branches for the next session

These are the diagnoses to reach for *when* the ladder runs, each with the
observation that selects it. Recording them now prevents post-hoc reasoning.

```text
oracle arm AO fails
    -> teacher / mapping / evaluation pipeline defect
    -> repair; DO NOT add capacity
    verdict: STRUCTURAL_TEACHER_NOT_REPRODUCIBLE

AO passes, synthetic control fails
    -> objective, conditioning, normalisation or solver fault
    -> compare against the E0S/E0R precedent (history.md F-71..F-78)
    verdict: SYNTHETIC_TRAINABILITY_DEFECT

AO + synthetic pass, A5 ~ A1  (no gain over ligand-only)
    -> ligand shortcut
    verdict: LIGAND_SHORTCUT_ONLY

A5 > A1 but A5 ~ A6  (no gain over deranged protein)
    -> partner-insensitive; matches P1R2A / P1R2B1 precedent
    verdict: LIGAND_SHORTCUT_ONLY (protein contrast without correct-protein value)

A5 > A1, A5 > A6, but A5 << AO
    -> the frozen state loses the mechanism
    -> DISAMBIGUATE WITH A5c BEFORE CONCLUDING:
         A5c ~ A5  -> slot geometry (Λ₂/Λ₃) is the ceiling
                      verdict: FROZEN_P1B_LOCAL_STATE_INSUFFICIENT
         A5c >> A5 -> ESM slot mean (Λ₅) is the ceiling
                      verdict: REPRESENTATION_DEFECT_RECOVERABLE
                      repair: carry explicit slot composition. NOT a bigger ESM.

all ten anti-shortcut criteria pass on K1 or K2
    verdict: PAIR_LOCAL_STRUCTURAL_MECHANISM_OBSERVED
    authorises: ONE separately registered source-affinity experiment
    authorises: nothing else. Not z. Not DAVIS. Not P2-P4.
```

## 4. The trap this graph exists to prevent

The historical failure mode across P1C → P1R2B1 is:

```text
correct protein changes geometry or compatibility
    ≠
correct protein adds transferable affinity-ranking information
```

Stage 1 adds a second, representational trap specific to S5:

```text
a channel that reconstructs well
    ≠
a channel whose defining information survives Λ₁…Λ₅
```

Finding M-8 is the concrete instance: directional hydrogen bonding was S4's
best-recovered aggregate channel and is provably `NOT_EVALUABLE` at arm A5,
because the frozen contract carries no angular information. Preregistering it as
a core channel would have produced a structurally guaranteed ligand-dominance
result that looked like biology.
