# S7_L2B — R0 fail-closed: the five indexed artifacts are not materialized

Date: 2026-08-09.
Stage: `S7_L2B_EXACT_RESIDUE_PLM_LOCALIZER`. Step: **R0**.
Governing document: `research/Residue locator/METASIEVE_L2B_FIVE_ARTIFACTS_CONSOLIDATED_REPORT_2026-08-09.md`
(SHA-256 `16e6c623…`, present and read).

```text
TERMINAL VERDICT:  FIVE_ARTIFACTS_NOT_MATERIALIZED
```

This is the **earliest applicable** verdict in the registered hierarchy, so no
later verdict is claimed and execution stops here. R1–R6 were not entered.

## 1. Source-of-truth matrix

| # | Artifact | In tree | In git history | Status | Blocks R0 |
|---|---|---|---|---|---|
| 1 | `METASIEVE_L2B_NEXT_STAGE_ANALYSIS_2026-08-09.md` | no | no | ORIGINAL_UNAVAILABLE | no |
| 2 | `L2A_ORACLE_FACTOR_BUDGET.json` | no | no | ORIGINAL_UNAVAILABLE | **yes** |
| 3 | `L2B_INDEPENDENT_DATA_GATE.json` | no | no | ORIGINAL_UNAVAILABLE | **yes** |
| 4 | `L2B_RESIDUE_STUDENT_FEASIBILITY.json` | no | no | ORIGINAL_UNAVAILABLE | **yes** |
| 5 | `PREREG_L2B_PLM_LOCALIZER.md` | no | no | ORIGINAL_UNAVAILABLE | no |

`research/Residue locator/` contains exactly one file: the consolidated report
itself. `git log --all` returns nothing for any `L2A*`, `L2B*` or
`*PLM_LOCALIZER*` path.

## 2. Why three of them cannot be formally replaced

Replacement was attempted at the level of *inputs*, not of numbers. The inputs do
not exist:

| Missing input | Searched as | Result |
|---|---|---|
| MONN corpus / PLIP annotations | `monn`, `MONN`, `plip`, `PLIP` | **no file anywhere** |
| residue-atom interaction labels | `residue_atom`, `*interaction*` | none (only two unrelated `multipanel_interaction` dirs) |
| anchor / satellite corpus | `anchor`, `satellite` | **none** |
| frozen L2 localizer checkpoint | all `*.pt` in tree | none — see §3 |
| CD-HIT-2D (claimed 40 % closure tool) | `which cd-hit`, `cd-hit-2d` | **not installed** |

The only `l2_` filename hit in the entire tree is the PDB code `5el2` inside
PLINDER metadata — a coincidence, not evidence.

Rebuilding artifacts 2 and 4 would require a labelled residue-atom corpus that
does not exist. Rebuilding artifact 3 would require a **new external
acquisition** of the MONN repository data, which is a governance decision
(licence, redistribution, tier assignment), not a rebuild. Substituting MMseqs2
for CD-HIT-2D would silently change the closure definition and therefore the
experiment.

**No look-alike was created.** Per the governing instruction, recreating a
similar computation and calling it reproduction is forbidden, and it was not
done.

## 3. A structural blocker that data acquisition would not fix

Arm **`B4`** is defined as *the frozen incumbent exact-residue localizer from the
prior low-capacity L2 experiment*. No such checkpoint exists. The only model
checkpoint in the repository is
`report/mechanism_refactor/p1b_pilot20k_seed17_v1/best.pt`, which is the **P1B
contact/distance bridge over a 128-slot protein index** — a different estimand,
a different protein resolution, and explicitly *not* an exact-residue localizer.
It cannot stand in for `B4` without changing what the Gate measures.

Therefore the primary Gate

```text
B5 - B4 >= 0.02 AP,  one-sided LCB95 > 0
```

is **unsatisfiable by construction** in this repository. Acquiring MONN would
unblock the data, but an incumbent `B4` would still have to be built and frozen
first — itself a new experiment needing its own preregistration.

This is the load-bearing finding of R0: **S7_L2B is blocked at two independent
points, and only one of them is a data problem.**

## 4. The governing document's runtime claim is false here

> "The current runtime lacks PyTorch, the ESM software and weights, and a GPU."

Measured in this environment:

| Component | Governing document | Measured |
|---|---|---|
| PyTorch | absent | **2.6.0+cu124 present** |
| GPU | absent | **present, 7.44 GB free at probe** |
| `transformers` | — | present |
| `esm` package | absent | absent (confirmed) |
| `esm2_t33_650M_UR50D` weights | absent | absent — only `esm2_t30_150M_UR50D` is cached |

So the runtime gap is real but **much narrower** than stated, and it is not the
binding constraint. The binding constraints are the missing corpus and the
missing `B4`. Nothing was downloaded or installed, because the GPU authorization
checklist fails at its first item.

`PLM_RUNTIME_NOT_FEASIBLE` is **not** claimed: the 650M contract was never
attempted, so its feasibility on an 8 GB laptop GPU is untested. Claiming it
would be a fabricated verdict.

## 5. Status of every numerical claim in the governing document

All of the following remain **external claims, not repository evidence**:
frozen L2 pair AP `0.01786`; the full oracle factor table and the
`0.23476 [0.22393, 0.24566]` residue-oracle contrast; the ~33× residue-over-atom
ratio; `72,226` same-protein pairs and their Jaccard/overlap statistics; the
sequence-student `0.08664` vs `0.06798` comparison and its `0.01866` shortfall;
`4,067`/`701`; `8,646`/`1,328`/`18,871`/`199,015`; `524`/`157`/`251`/`317`/`2,555`;
`2,404`/`1,297,939`/`7,119`; atom-level AP `0.6767`; and every SHA-256, syntax
check and JSON-parse confirmation reported in §15 of that document.

This does not assert the claims are wrong. It asserts they are **unverifiable
here**, which under the project's evidence-precedence rule is the same as not
being evidence.

Consistent with the prior audits, the withdrawn S5R2, U0-U3 and LSMF claims are
**not** reinstated by this document, and nothing in it was used to revive them.

## 6. What R0 would require to pass

Ordered by dependency, with the governance decision each implies:

1. **Acquire the MONN additional-PDB data** at the named commit, under a tier
   assignment, licence check and redistribution decision in
   `DATASET_ROLE_REGISTRY.json`. *Governance decision required.*
2. **Rebuild the residue-atom edge corpus** from PLIP event identifiers, under a
   new manifest with new artifact names and its own hashes. The historical
   `4,067 / 701` metric identity may **not** be reused.
3. **Install CD-HIT-2D**, or register a deliberate, documented change of the
   homology-closure tool to MMseqs2 — which makes it a different closure and
   therefore a different experiment.
4. **Build and freeze an incumbent `B4`** exact-residue localizer under its own
   preregistration, so the `B5 − B4` Gate has a referent.
5. **Acquire `esm2_t33_650M_UR50D`** weights plus the `esm` package (≈2.5 GB
   download), and record revision, licence, URL and weight SHA-256.
6. **Then** write and freeze the single unified `S7_L2B` preregistration and
   proceed to R1.

Steps 1, 3, 4 and 5 each require explicit authorization. I did not take any of
them.

## 7. Stage-naming reconciliation

The instruction requires **one** stage and forbids parallel S7 and L2B
protocols. The preregistration written in the previous session,
`research/ssl_b2_structural_observability/PREREG_S7_EXACT_RESIDUE_LOCAL_MECHANISM.md`
(SHA-256 `497ffda5…`), is a *different* experiment: exact-residue pocket
composition computed from RCSB coordinates, not residue-atom interaction
localization from PLIP labels.

To avoid two live protocols it is marked **SUPERSEDED_BY_STAGE_NAMING** and
placed on hold. It is not deleted, and its hash is preserved. If MONN cannot be
acquired, it remains the only structural stage this repository can actually run,
because its data — the 13,885 never-scored RCSB candidates — is already
available and already governed.

## 8. Frozen surfaces and label firewall

`theory/`, `model/`, `contracts/`, `scripts/`, `weights/`, `config/` unmodified.
No affinity, DAVIS, recipient, PLIP or pose-aware value read. No commit, no push.
Nothing under `model/` or production `scripts/` was touched.
