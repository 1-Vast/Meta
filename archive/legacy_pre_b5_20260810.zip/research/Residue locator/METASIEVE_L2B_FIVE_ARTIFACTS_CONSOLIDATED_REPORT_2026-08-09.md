# MetaSieve L2B: Consolidated Report Across Five Research Artifacts

**Date:** 9 August 2026  
**Scope:** L2A oracle factor budget, L2B independent-data gate, L2B residue-student feasibility, L2B PLM-localizer preregistration, and the integrated next-stage analysis  
**Current status:** `PLM_LOCALIZER_REGISTERED_NOT_EXECUTABLE_IN_CURRENT_RUNTIME`  
**Protected-label boundary:** No protected affinity labels, recipient labels, RBFE labels, or few-shot support labels were read in this stage.

## 1. Executive conclusion

The five artifacts jointly identify a specific and testable bottleneck rather than a generic need for more model capacity.

The current sequence-plus-2D residue–atom localizer has a component-balanced pair average precision (AP) of only **0.01786**. Oracle decomposition shows that this weakness is overwhelmingly concentrated on the protein side:

- exposing the true active-atom indicator raises pair AP only to **0.02494**, a gain of **0.00707**;
- exposing the true active-residue indicator raises pair AP to **0.25262**, a gain of **0.23476**, with a 95% component-bootstrap interval of **[0.22393, 0.24566]**;
- exposing both active-residue and active-atom indicators raises pair AP to **0.37303**, a gain of **0.35516**, with a 95% interval of **[0.34204, 0.36798]**.

Thus, the dominant missing information is a transferable residue-site prior,

\[
\pi_i = P(\text{residue }i\text{ belongs to the ligand-relevant pocket}\mid\text{protein sequence}),
\]

not additional ligand capacity or a higher-rank residue–atom interaction head.

A deterministic multiscale sequence student confirms that residue-site information is learnable from sequence: it improves residue AP from **0.06798** to **0.08664** and defeats prevalence, motif-shuffled, and deranged-protein controls. However, its gain over the frozen L2 model is **0.01866**, below the preregistered practical threshold of **0.02**. This is a strict fail-closed result, not evidence that sequence is uninformative.

The next justified experiment is therefore the preregistered **L2B-PLM-LOCALIZER**:

1. freeze `esm2_t33_650M_UR50D` and extract per-residue embeddings;
2. retain the validated 64-dimensional per-atom 2D representation;
3. learn an explicit residue prior, an atom propensity, and low-rank typed residue–atom interactions;
4. evaluate under the existing 40% protein-homology and exact-ligand-graph double closure;
5. require simultaneous separation from five destructive controls.

This experiment has not been run. The current runtime lacks PyTorch, the ESM software and weights, and a GPU. No substitute embedding was used to simulate a PLM result.

The independent confirmation cohort is large enough computationally—**524 complexes, 157 closure components, and 2,555 positive residue–atom edges**—but is not yet admissible as a formal time-forward, publication-closed confirmation set. Primary-publication identifiers and authoritative PDB release dates must first be retrieved from the RCSB PDB Data API and incorporated into the closure.

The current authorization state is therefore:

```text
population residue-site information: PRESENT
hand-engineered sequence student: INSUFFICIENT
PLM localizer: PREREGISTERED, NOT EXECUTED
formal independent confirmation set: BLOCKED ON METADATA
source-affinity transfer: NOT AUTHORIZED
k <= 5 support adaptation: FORBIDDEN
frozen production operator: UNCHANGED
```

## 2. The five source artifacts and their roles

| Artifact | Role in the evidence chain | Status |
|---|---|---|
| `METASIEVE_L2B_NEXT_STAGE_ANALYSIS_2026-08-09.md` | Integrates theory, diagnostics, data admissibility, architecture, execution order, and stopping rules | Completed analysis |
| `L2A_ORACLE_FACTOR_BUDGET.json` | Quantifies where recoverable localization information is missing | Completed machine result |
| `L2B_INDEPENDENT_DATA_GATE.json` | Tests whether a non-overlapping confirmation cohort is large and sufficiently closed | Computational gate passed; formal gate failed closed |
| `L2B_RESIDUE_STUDENT_FEASIBILITY.json` | Tests whether deterministic hand-engineered sequence features can learn the residue prior | Completed; failed the practical-effect gate |
| `PREREG_L2B_PLM_LOCALIZER.md` | Freezes the next architecture, controls, metrics, thresholds, execution order, and stopping rules | Registered; not executed |

These artifacts answer different questions. The oracle analysis is diagnostic and label-exposed; it cannot be deployed. The residue student is a development lower-bound experiment. The independent-data result is a data-admissibility gate, not a model score. The PLM document is a prospective protocol, not evidence of model performance.

## 3. Evidence taxonomy

### 3.1 Directly verified results

- The frozen L2 full model attains component-balanced pair AP **0.01786**.
- Oracle active-residue information contains far more recoverable AP than oracle active-atom information.
- A multiscale sequence-only student learns protein-identity- and motif-dependent residue-site signal but misses the practical improvement threshold.
- A closure-compatible 524-complex computation cohort exists.
- The available MONN metadata do not support complete primary-publication and authoritative time-forward closure.
- The production theory and production model were not modified.

### 3.2 Evidence-supported interpretations

- The current bottleneck is primarily the protein residue-site prior rather than the ligand atom representation.
- The existing local 7-mer/hash-like protein representation lacks sufficient long-range structural and functional context.
- A generic binding pocket is partly reusable across ligands, but it is not sufficient for ligand-conditioned edge localization.
- Increasing the rank or capacity of the current bilinear head before improving residue representations is poorly justified.

### 3.3 Unverified research hypotheses

- Frozen ESM2 residue embeddings may raise the residue prior by at least 0.02 AP over the frozen L2 model.
- A PLM residue prior combined with the existing atom representation may recover ligand-conditioned and typed residue–atom interactions.
- A development-domain pass may replicate on a formally publication-closed, time-forward confirmation cohort.
- Successful localization may later produce a correct-protein-specific affinity increment.

None of these hypotheses authorizes affinity transfer or few-shot adaptation before the corresponding gates pass.

## 4. Mathematical and theoretical boundary

### 4.1 The frozen production operator

The production theory defines an IID task-law object whose admissible operator remains

\[
\boxed{\mathsf A(F,z)=K(B(z)F(z))}.
\]

Its regularized target is

\[
\boxed{
g_\mu^\star(z)
=
\arg\min_p
\left\{
L_0(z,B(z)p)+\frac{\mu}{2}\lVert p\rVert_2^2
\right\}.
}
\]

Here:

- \(z\) is an observable, admissible task statistic;
- \(F(z)\) lies on a simplex;
- \(B(z)F(z)\) constructs a valid CDF band;
- \(K\) maps that band to a set of probability laws;
- \(\mu>0\) supplies uniqueness through strong convexity.

This theory does **not** claim pairwise-ranking consistency, residue–atom localization consistency, or automatic transfer from localization AP to affinity prediction.

### 4.2 The trace-set/minimax research structure

The separate research handoff describes support-identifiable trace sets, centers, radii, abstention, gauge invariance, and an information dimension bounded by support size \(k\). It constrains how a future biological statistic or support-conditioned correction may be admitted, but it is not identical to the production operator above.

### 4.3 Legal use of L2B evidence

L2B evaluates whether a biological auxiliary statistic is identifiable. A successful localizer could provide a constrained feature, prior, or component of \(z\). It would not, by itself:

- modify \(B\) or \(K\);
- validate CSMO or BandOperator on the affinity task;
- prove affinity improvement;
- justify a support-conditioned section;
- establish ranking consistency.

The required logical chain remains

\[
\text{localization identification}
\rightarrow
\text{source-affinity increment}
\rightarrow
\text{few-shot support identification}
\rightarrow
\text{admission into }z.
\]

Each arrow requires an independently preregistered gate.

## 5. L2A oracle factor budget

### 5.1 Diagnostic objective

The frozen edge score is decomposed as

\[
s_{ij}
=
s_i^{(r)}
+s_j^{(a)}
+s_{ij}^{(\gamma)},
\]

where:

- \(i\) indexes protein residues;
- \(j\) indexes ligand atoms;
- \(s_i^{(r)}\) is the residue main effect;
- \(s_j^{(a)}\) is the atom main effect;
- \(s_{ij}^{(\gamma)}\) is the residue–atom coupling.

For diagnostic purposes only, the true interaction matrix \(Y\) defines

\[
R_i=\max_j Y_{ij},
\qquad
A_j=\max_i Y_{ij}.
\]

Thus, \(R_i\) exposes whether residue \(i\) participates in any positive edge, and \(A_j\) exposes whether atom \(j\) participates in any positive edge. Adding \(R_i\), \(A_j\), or \(R_iA_j\) to the frozen score estimates how much performance would become recoverable if the corresponding latent factor were known.

These are label-exposed oracle quantities and are not deployable predictors.

### 5.2 Evaluation unit and uncertainty

- Evaluation set: **4,067 satellite complexes**.
- Independent statistical units: **701 closure components**.
- Estimator: component-balanced pair AP.
- Uncertainty: **2,000 whole-component bootstrap replicates**.

Complexes or individual residue–atom pairs were not treated as independent replicates.

### 5.3 Complete factor table

| Score arm | Component-balanced pair AP | Interpretation |
|---|---:|---|
| Prevalence | 0.00217 | No-information reference |
| Atom main effect | 0.00353 | Atom propensity alone is weak |
| Residue main effect | 0.00952 | Existing residue prior is weak |
| Additive residue + atom | 0.00926 | Existing marginals remain insufficient |
| Interaction only | 0.01435 | Existing coupling contains signal but is too weak |
| Full frozen L2 | 0.01786 | Current sequence-plus-2D result |
| Oracle atom | 0.02494 | Limited headroom from atom identity |
| Oracle residue | 0.25262 | Large headroom from residue localization |
| Oracle residue + atom | 0.37303 | Marginal rectangle upper bound, not deployable |

### 5.4 Paired oracle contrasts

| Contrast | Point estimate | 95% component-bootstrap interval |
|---|---:|---:|
| Oracle atom − full | 0.00707 | [0.00614, 0.00819] |
| Oracle residue − full | 0.23476 | [0.22393, 0.24566] |
| Oracle residue + atom − full | 0.35516 | [0.34204, 0.36798] |

The oracle-residue gain is approximately 33 times the oracle-atom gain:

\[
\frac{0.23476}{0.00707}\approx 33.2.
\]

This ratio is diagnostic, not a causal decomposition. Nevertheless, it decisively prioritizes residue representation over ligand-encoder expansion for the next controlled experiment.

### 5.5 Generic-pocket reuse analysis

Across **72,226 pairs of complexes** sharing an identical protein sequence but containing different exact ligand graphs, the active-residue sets have:

| Statistic | Median | Mean |
|---|---:|---:|
| Jaccard similarity | 0.47265 | 0.48805 |
| Overlap coefficient | 0.75766 | 0.72306 |

The high overlap coefficient supports learning a reusable protein-side pocket prior. The Jaccard similarity being far below one shows that the pocket is not fully ligand-invariant. Therefore, a valid model requires both:

\[
\text{generic residue prior }\pi_i
\quad + \quad
\text{ligand-conditioned coupling }\gamma_{ij}.
\]

A protein-only pocket predictor can be useful, but cannot by construction pass deranged-ligand or atom-environment-shuffle controls.

## 6. L2B-0 residue-student feasibility experiment

### 6.1 Research question

Can a deterministic, sequence-only model learn a transferable residue-site prior under strict protein closure, before paying the cost of a large PLM?

This experiment was a lower-bound development test. It was not a substitute for the full residue–atom Gate.

### 6.2 Training and inputs

- Training anchor: **8,646 complexes**.
- Exact training sequences: **1,328**.
- Teacher label for each sequence: union of residues touched by any mapped PLIP edge across its anchor complexes.
- Positive training residues: **18,871**.
- Fixed sampled training rows: **199,015**.
- Test set: **4,067 satellite complexes** in **701 closure components**.
- Inference input: protein sequence only.

The student uses **512 deterministic multiscale features**, including:

- residue identities at near and far offsets;
- local composition over radii 3, 7, 15, 31, and 63;
- whole-sequence composition;
- relative-position Fourier features;
- distances to the N- and C-termini.

### 6.3 Residue-level results

| Residue-scoring arm | Component-balanced residue AP |
|---|---:|
| Multiscale sequence student | 0.08664 |
| Frozen L2 full model | 0.06798 |
| Motif shuffle | 0.04494 |
| Deranged protein | 0.04404 |
| Prevalence | 0.02495 |

### 6.4 Preregistered contrasts

| Contrast | Estimate | 95% component-bootstrap interval | Required effect | Verdict |
|---|---:|---:|---:|---|
| Student − frozen L2 | 0.01866 | [0.01286, 0.02420] | ≥ 0.02 | **FAIL** |
| Student − prevalence | 0.06169 | [0.05652, 0.06674] | ≥ 0.05 | PASS |
| Student − motif shuffle | 0.04170 | [0.03656, 0.04691] | ≥ 0.02 | PASS |
| Student − deranged protein | 0.04274 | [0.03787, 0.04789] | ≥ 0.02 | PASS |

The primary improvement misses the practical threshold by

\[
0.02000-0.01866=0.00134\text{ AP}.
\]

Because the threshold was frozen in advance, statistical significance does not override the practical-effect requirement.

### 6.5 Correct interpretation

The result supports the following claims:

- residue-site signal is learnable from sequence;
- the signal depends on the correct protein identity and residue order;
- deterministic multiscale features improve on the previous local representation;
- the improvement is too small to justify another hand-feature iteration.

It does not support the claim that sequence-only localization is impossible. It specifically rejects the cheaper hypothesis that extending k-mers, local windows, or random/hash features is sufficient.

Because the student never observes the ligand, its deranged-ligand contrast is exactly zero by construction. It cannot establish partner-specific residue–atom localization and cannot pass the full L2B Gate.

## 7. Independent confirmation data gate

### 7.1 Source and edge reconstruction

The candidate confirmation records come from the additional PDB data in the MONN repository at commit

```text
f2b62ccf49c18a9502aa0eb0d582c6e0735ef200
```

Residue–atom edges are reconstructed only when residue and atom annotations share the complete PLIP event identifier. Base interaction classes are not used to form Cartesian-product edges.

Closure is applied jointly over:

- exact PDB identity;
- exact protein sequence;
- UniProt identity;
- exact ligand graph;
- verified 40% protein homology using CD-HIT-2D.

### 7.2 Cohort attrition and final capacity

| Stage | Count |
|---|---:|
| Raw rows / interaction dictionaries | 1,853 |
| Complexes with at least one correctly mapped positive edge | 1,851 |
| Remaining after exact sequence, UniProt, PDB, and ligand-graph closure | 628 |
| Removed by 40% CD-HIT-2D homology exclusion | 104 |
| Final retained complexes | 524 |
| Final exact sequences | 251 |
| Final exact ligand graphs | 317 |
| Final closure components | 157 |
| Final positive residue–atom edges | 2,555 |

The preregistered minimums were:

| Quantity | Minimum | Observed | Capacity verdict |
|---|---:|---:|---|
| Complexes | 300 | 524 | PASS |
| Exact sequences | 100 | 251 | PASS |
| Exact ligand graphs | 150 | 317 | PASS |
| Closure components | 100 | 157 | PASS |
| Positive edges | 2,000 | 2,555 | PASS |

Crossings against the development corpus are zero for exact sequence, UniProt, PDB, exact ligand graph, and verified 40% homology.

### 7.3 Why the formal independent-data gate still fails

The packaged MONN tables do not provide both of the metadata fields required by the protocol:

1. a canonical primary-publication identifier for every PDB entry, preferably DOI or PubMed ID;
2. the authoritative initial PDB release date.

The repository's 2020 commit date cannot be used as a proxy for the release date of every included structure. Therefore:

```text
compute_data_gate = PASS
formal_independent_data_gate = FAIL_CLOSED
terminal = L2B_COMPUTE_COHORT_AVAILABLE_FORMAL_CONFIRMATION_BLOCKED
```

The 524 complexes must remain unscored until metadata repair and re-closure are complete.

### 7.4 Required metadata repair

Before any independent model score is produced:

1. query the RCSB PDB Data API for all development and candidate PDB entries;
2. retrieve the primary citation, DOI and/or PubMed ID, and authoritative initial release date;
3. freeze a time cutoff after PDBbind-v2018 under the preregistered rule;
4. union publication identity with the existing sequence, UniProt, PDB, ligand-graph, and 40% homology closure;
5. regenerate the candidate cohort;
6. rerun all five minimum-capacity checks;
7. record hashes before any independent prediction is generated.

If the repaired cohort falls below any minimum, the correct action is to find a new confirmation domain, not to relax the closure.

## 8. Architecture evidence from related work

The architecture choice is supported, but not validated, by several external precedents:

- **MONN** supplies structure-derived residue–atom non-covalent-interaction labels. These PLIP annotations are useful supervision but are not causal free-energy labels.
- **InteractBind** supports the value of large-scale training on typed protein–ligand interactions, but its evaluation is not equivalent to complete-matrix, component-balanced pair AP under the present double closure.
- **LiBRe** supports ligand-aware sequence residue prediction. Its globally pooled ligand state does not provide an explicit atom–residue edge localizer.
- **LaMPSite** is architecturally close because it combines ESM2, ligand graphs, and a residue–atom interaction tensor. Its leakage protocol and DCA-style metrics do not replace the present 40% homology plus exact-ligand-graph closure or the five destructive controls.
- **IF-SitePred** supports structure embeddings for pocket localization. A method requiring experimental or predicted structure belongs to a separately registered `structure-required` route, not to the current sequence-only claim.
- Time-forward PDBbind studies support simultaneous protein and ligand leakage control rather than random splitting followed by an OOD claim.

These papers motivate the model family. They do not change the estimand, statistical unit, thresholds, or stopping rules.

## 9. Preregistered L2B-PLM-LOCALIZER

### 9.1 Protein encoder

The protein encoder is fixed to the official

```text
esm2_t33_650M_UR50D
```

configuration:

- all ESM2 parameters frozen;
- model in evaluation mode so dropout is disabled;
- final-layer 1,280-dimensional per-token representation;
- no fine-tuning on development or confirmation labels.

The development corpus contains:

- **2,404 exact sequences**;
- **1,297,939 residues**;
- maximum sequence length **7,119**.

The sealed computation cohort contains:

- **251 exact sequences**;
- **123,265 residues**;
- maximum sequence length **6,729**.

### 9.2 Long-sequence windowing

To avoid truncating long proteins:

- window length: **1,000 residues**;
- stride: **500 residues**;
- add a final window ending exactly at the C-terminus when required;
- average embeddings arithmetically at overlapping residue positions.

Development extraction requires approximately:

- **2,882 windows**;
- **1,605,630 token-forwards**;
- **3.09 GiB** for the final fp16 residue cache, excluding model weights and temporary activations.

The independent cohort must remain sealed until development passes. It would then require approximately:

- **284 windows**;
- **143,417 token-forwards**;
- **0.29 GiB** of fp16 residue cache.

### 9.3 Ligand representation

The ligand branch remains the validated **64-dimensional per-atom 2D representation**. It already satisfies atom-permutation equivariance and achieves atom-level AP **0.6767**. The small oracle-atom budget further argues against changing the ligand encoder in the same experiment.

Holding this branch fixed ensures that the primary attributable change is the protein residue representation.

### 9.4 Factorized typed head

For ESM residue embedding \(h_i\) and atom state \(a_j\), define

\[
r_i=operatorname{GELU}\!\left(W_h\operatorname{LN}(h_i)+b_h\right),
\qquad
r_i\in\mathbb R^{128},
\]

\[
\pi_i=sigma(w_\pi^\top r_i+b_\pi),
\qquad
\rho_j=sigma(w_\rho^\top a_j+b_\rho),
\]

and, for interaction channel \(c\),

\[
s_{ij}^{(c)}
=
b_c
+\alpha_c\operatorname{logit}(\pi_i)
+\beta_c\operatorname{logit}(\rho_j)
+(P_cr_i)^\top(Q_ca_j),
\]

\[
q_{ij}^{(c)}=\sigma\!\left(s_{ij}^{(c)}\right).
\]

The channels are:

- binary interaction;
- hydrogen bond;
- electrostatic;
- hydrophobic/aromatic;
- halogen.

The interaction term uses rank **32** per channel. A repulsive/steric mechanism must not be claimed because no corresponding positive PLIP label exists in this supervision source.

The factorization is scientifically important:

- \(\pi_i\) represents protein-side pocket membership;
- \(\rho_j\) represents ligand atom propensity;
- \((P_cr_i)^\top(Q_ca_j)\) represents partner-specific, typed coupling.

This makes it possible to determine whether an apparent gain comes from a generic pocket, a generic ligand propensity, or a genuine residue–atom interaction.

### 9.5 Training sequence

1. Train \(\pi_i\) on the anchor-domain union-of-active-residues labels.
2. Freeze the residue-prior module.
3. Train atom propensity and typed edge heads.
4. Use exactly **six unique negative edges per positive edge**.
5. Train for **six epochs** with deterministic AdamW.
6. Do not tune on satellites.
7. Do not perform satellite-based early stopping or model selection.

The repaired negative-sampling contract must produce exactly six unique negatives for every positive, including fallback sampling when local candidate sets are too small.

## 10. Evaluation protocol and gates

### 10.1 Development evaluation

- Score the complete residue-by-atom matrix for every satellite complex.
- Use the same **4,067 complexes** and **701 closure components**.
- Report component-balanced AP.
- Estimate uncertainty with **2,000 whole-component bootstrap replicates**.
- Keep the independent cohort sealed.

### 10.2 Five mandatory destructive controls

The correct model must outperform all of the following by at least **0.02 AP**:

```text
prevalence
deranged protein
motif shuffle
deranged ligand
atom-environment shuffle
```

For every contrast, the 95% component-bootstrap lower confidence bound must also be greater than zero.

The controls distinguish different shortcuts:

| Control | Failure indicates |
|---|---|
| Prevalence | No useful localization beyond class imbalance |
| Deranged protein | Protein identity is not load-bearing |
| Motif shuffle | Residue order/local context is not load-bearing |
| Deranged ligand | The model is only predicting a generic protein pocket |
| Atom-environment shuffle | The model is not using ligand atomic context |

### 10.3 Typed-channel gate

At least two evaluable typed channels must each outperform both deranged protein and deranged ligand by **at least 0.01 AP**, with positive 95% lower bounds.

Passing only the binary channel supports contact localization, not identification of named biochemical mechanisms.

### 10.4 Residue-prior auxiliary gate

The PLM residue prior must improve component-balanced residue AP over the frozen L2 model by at least **0.02**, with a positive 95% lower bound.

This auxiliary gate ensures that the architectural change actually solves the bottleneck identified by L2A.

### 10.5 Attribution ablations

The following must be reported:

- \(\pi\)-only;
- \(\rho\)-only;
- additive \(\pi+\rho\);
- \(\gamma=0\), removing the bilinear interaction;
- the full factorized model.

These ablations explain the source of a gain but do not replace the five mandatory controls.

## 11. Strict execution order

The order is part of the scientific protocol:

1. **Repair confirmation metadata.** Retrieve RCSB primary citations and release dates for both development and candidate entries; freeze the time cutoff; rebuild publication/time closure; rerun capacity checks.
2. **Prepare the exact PLM runtime.** Install compatible PyTorch and official ESM dependencies, obtain official weights, provide a GPU, and record package versions, weight SHA-256, windowing rules, and per-sequence cache hashes.
3. **Run development only.** Train on the anchor and score the 4,067 satellite complexes. Do not extract or score the independent cohort.
4. **Apply the stopping rules immediately.** Any failure of the residue, five-control, or typed-channel gates stops the sequence-plus-2D branch.
5. **Run independent confirmation once** only if development passes completely and the metadata-repaired cohort still satisfies every capacity minimum.
6. **Register a new source-affinity gate** only if independent localization passes.
7. **Open few-shot support adaptation** only if the source-affinity gate also passes.

No protected affinity or support label may be read to choose PLM hyperparameters or rescue a failed localization gate.

## 12. Downstream source-affinity gate

Localization success is necessary but not sufficient. A separate prospective source-affinity experiment must require the correct model to beat each of the following:

- additive baseline;
- ligand-only model;
- wrong-protein model;
- motif-shuffled model;

by a favorable preregistered contrast of at least **0.03 pKi**, with a positive 95% component-bootstrap lower bound under the separately frozen error estimand. The exact sign convention must be stated in that new preregistration. Named-channel deletion must also remove the corresponding gain.

Only after this gate passes can one argue that the localized field contributes correct-protein-specific affinity information.

## 13. Few-shot support remains closed

Even a successful source-affinity result does not automatically identify a \(k\le5\) support adaptation operator. The support stage must still demonstrate:

- support/query chemical separation;
- target-specific improvement over foreign and permuted support;
- a correction constrained to the support-identifiable row space;
- query coverage and abstention;
- stability across independent target components and random seeds;
- improvement beyond matched-capacity and matched-amplitude controls.

Until that stage is preregistered and passed, the correct status is:

```text
FEW_SHOT_SUPPORT_SECTION_NOT_OPENED
BIOLOGICAL_STATISTIC_NOT_ADMITTED_TO_Z
```

## 14. Stopping rules and scientific interpretation

| Observation | Permitted conclusion | Required action |
|---|---|---|
| PLM residue gain < 0.02 | Sequence-only residue prior remains insufficient | Stop sequence-only; only a separately registered structure-required model is allowed |
| Residue AP passes, but deranged-protein or motif-shuffle control fails | No load-bearing local protein identity | Stop |
| Protein controls pass, but deranged-ligand or atom-shuffle control fails | Generic pocket only; no ligand-conditioned field | Stop the sequence-plus-2D mechanism route |
| Binary channel passes, typed channels fail | Contact localization only | Do not open named-channel affinity testing |
| Development passes, but formal independent closure fails | No admissible confirmation domain | Find a new time-forward dataset; do not score the blocked cohort |
| Development passes, independent localization fails | Development-domain overfit or distribution dependence | Stop or move to a separately preregistered structure-required route |
| Development and independent localization pass | Localization prerequisite established | Register source-affinity gate |
| Localization and source-affinity gates pass | Correct-protein affinity signal established on source tasks | Register, but do not yet claim, few-shot support adaptation |

Increasing ordinary sequence-plus-2D capacity after a gate failure is explicitly disallowed. A structure-required model is a new hypothesis because it changes inference information, and therefore requires a new preregistration and confirmation domain.

## 15. Reproducibility requirements

The completed artifacts report that:

- all three analysis programs passed Python syntax checks;
- all three JSON result files parsed successfully;
- the factor-budget and residue-student result tables each contain 4,067 per-complex records;
- the independent closure table contains 524 records;
- input, output, model, and protocol SHA-256 values were stored in the machine reports;
- the production theory, `model/`, CSMO, BandOperator, and deployment readout were unchanged.

The PLM run must additionally record:

- operating system and CUDA versions;
- Python and PyTorch versions;
- official ESM code revision and package source;
- model-weight SHA-256;
- deterministic seed and algorithm settings;
- exact sequence-window manifest;
- per-sequence embedding-cache hashes;
- training-row and negative-sampling manifests;
- closure-component assignments;
- all per-complex predictions before aggregation;
- bootstrap seed and sampled component indices.

## 16. Risks and failure modes

### 16.1 Attention is not mechanism identification

An attention map trained only from affinity or global pair labels can encode ligand SAR, protein-family identity, or dataset frequency while appearing spatially localized. The model must be judged by destructive partner controls and typed edge supervision, not by visual plausibility.

### 16.2 Generic-pocket shortcut

Because active residues overlap strongly across ligands for the same protein, a strong \(\pi_i\) can raise aggregate AP without using the ligand. Deranged-ligand and atom-environment-shuffle controls are therefore load-bearing.

### 16.3 Protein-family leakage

Random PDB splits can place homologous pockets on both sides. Exact-sequence exclusion is insufficient; the 40% homology closure must remain intact.

### 16.4 Ligand-identity leakage

Exact graph, CCD, or close chemical reuse can inflate interaction localization. Exact ligand-graph closure remains mandatory, and future affinity gates require scaffold-aware auditing.

### 16.5 Publication and temporal leakage

Different PDB entries from one paper can share targets, ligands, constructs, and annotation decisions. PDB identity alone does not close this dependency. Primary-publication closure and authoritative release dates are required for formal confirmation.

### 16.6 Typed-label limitations

PLIP labels are deterministic structural annotations, not energetic ground truth. A typed-channel pass establishes recoverable geometry/chemistry under those rules; it does not prove thermodynamic causality.

### 16.7 Metric instability from ties

Earlier diagnostic reconstruction showed that float32 versus float64 score ordering can alter AP when many edges are nearly tied. The formal run must preserve the exact scoring dtype and deterministic tie behavior, and verify reconstruction to the preregistered tolerance.

### 16.8 Runtime substitution

Random embeddings, hand-engineered features, or a different PLM cannot be reported as the preregistered ESM2 result. Any change of backbone, dimensionality, fine-tuning status, or windowing policy creates a different experiment.

## 17. Cheapest decisive next actions

The next work should be limited to two tasks before any further affinity research:

### Action A: repair the confirmation data contract

Produce a machine-readable RCSB metadata table and a new closure report showing:

- primary-citation IDs;
- release dates;
- frozen time cutoff;
- zero publication crossings;
- zero exact and homology crossings;
- retained counts against all five capacity thresholds.

### Action B: execute the frozen development PLM Gate

Extract the exact ESM2 embeddings, train the preregistered low-capacity factorized head, and evaluate once on the existing 701 satellite components.

These two actions discriminate the remaining hypotheses at lower cost than end-to-end affinity training:

| Result | Interpretation |
|---|---|
| Residue prior fails | Sequence-only protein context is insufficient |
| Residue prior passes, ligand controls fail | Generic pocket recovered, partner-specific mechanism absent |
| Binary passes, typed fails | Contact localization without named chemistry |
| Full development passes, independent fails | Domain-specific localization or leakage-sensitive generalization |
| Both pass | Local biological field is identified strongly enough to justify affinity testing |

## 18. Final judgment

The five artifacts materially narrow the research problem.

They establish that the data contain reusable, protein-identity-dependent residue-site information and that this information is the dominant source of unrealized localization headroom. They also show that a carefully engineered sequence-only student is not strong enough to meet the practical threshold, so further k-mer or local-window expansion is not a justified research direction.

They do **not** establish that a PLM solves the problem, that typed residue–atom mechanisms generalize, that localization improves affinity, or that five support examples identify a target-specific adaptation operator.

The only currently justified model experiment is the frozen ESM2 L2B development Gate, preceded by RCSB-based repair of the independent data contract. If the PLM model cannot simultaneously beat prevalence, wrong protein, motif shuffle, wrong ligand, and atom-environment shuffle under the frozen thresholds, the sequence-plus-2D biological \(z\) route should be terminated. If it passes development and formal independent confirmation, the project may proceed—once—to a separately preregistered source-affinity Gate.

Until then, the production operator and few-shot support section must remain unchanged and closed.

## 19. References linked by the source analysis

- MONN: [Multi-objective neural network for protein–ligand interaction prediction](https://www.sciencedirect.com/science/article/pii/S2405471220300818)
- MONN source repository: [lishuya17/MONN](https://github.com/lishuya17/MONN)
- InteractBind: [Large-scale protein–ligand non-covalent interaction prediction](https://arxiv.org/abs/2605.24045)
- LiBRe: [Ligand-aware binding-residue prediction](https://pubs.acs.org/doi/10.1021/acs.jcim.5c02883)
- LaMPSite: [Ligand-aware protein binding-site prediction with ESM2 and residue–atom interactions](https://arxiv.org/abs/2312.03016)
- IF-SitePred: [Binding-site prediction using protein structure embeddings](https://link.springer.com/article/10.1186/s13321-024-00821-4)
- Leakage and time-forward PDBbind evaluation: [LP-PDBBind/time-split analysis](https://arxiv.org/html/2308.09639v2)
- ESM implementation and pretrained models: [facebookresearch/esm](https://github.com/facebookresearch/esm)
- Authoritative PDB metadata interface: [RCSB PDB Data API](https://data.rcsb.org/)

These references motivate data sources and architecture choices. None substitutes for the preregistered closure, controls, or confirmation criteria in this report.

## Appendix A. Compact numerical ledger

| Quantity | Value |
|---|---:|
| Frozen L2 pair AP | 0.01786 |
| Prevalence pair AP | 0.00217 |
| Oracle atom pair AP | 0.02494 |
| Oracle residue pair AP | 0.25262 |
| Oracle residue + atom pair AP | 0.37303 |
| Oracle atom − full | 0.00707 [0.00614, 0.00819] |
| Oracle residue − full | 0.23476 [0.22393, 0.24566] |
| Oracle residue + atom − full | 0.35516 [0.34204, 0.36798] |
| Same-protein/different-ligand pairs | 72,226 |
| Active-residue Jaccard, median / mean | 0.47265 / 0.48805 |
| Active-residue overlap coefficient, median / mean | 0.75766 / 0.72306 |
| Sequence-student residue AP | 0.08664 |
| Frozen L2 residue AP | 0.06798 |
| Student − frozen L2 | 0.01866 [0.01286, 0.02420] |
| Student − prevalence | 0.06169 [0.05652, 0.06674] |
| Student − motif shuffle | 0.04170 [0.03656, 0.04691] |
| Student − deranged protein | 0.04274 [0.03787, 0.04789] |
| Development satellites / components | 4,067 / 701 |
| Candidate independent complexes / components | 524 / 157 |
| Candidate exact sequences / ligand graphs | 251 / 317 |
| Candidate positive edges | 2,555 |
| ESM2 embedding dimension | 1,280 |
| Projected residue dimension | 128 |
| Typed interaction rank | 32 |
| Required full-control advantage | ≥ 0.02 AP, 95% LCB > 0 |
| Required typed-channel advantage | ≥ 0.01 AP against wrong protein and wrong ligand |
| Required PLM residue gain | ≥ 0.02 AP, 95% LCB > 0 |

## Appendix B. Artifact-level verdicts

```text
L2A_ORACLE_FACTOR_BUDGET:
    PROTEIN_RESIDUE_LOCALIZATION_IS_THE_DOMINANT_INFORMATION_DEFICIT

L2B_RESIDUE_STUDENT_FEASIBILITY:
    RESIDUE_SIGNAL_IS_LEARNABLE_BUT_HAND_ENGINEERED_STUDENT_FAILS_PRACTICAL_GATE

L2B_INDEPENDENT_DATA_GATE:
    COMPUTE_CAPACITY_PASS
    FORMAL_PUBLICATION_TIME_CLOSURE_FAIL_CLOSED

PREREG_L2B_PLM_LOCALIZER:
    FROZEN_AND_NOT_YET_EXECUTED

INTEGRATED_NEXT_STAGE:
    REPAIR_METADATA
    RUN_DEVELOPMENT_PLM_GATE
    STOP_ON_ANY_MANDATORY_CONTROL_FAILURE
    DO_NOT_OPEN_AFFINITY_OR_FEW_SHOT SUPPORT
```
