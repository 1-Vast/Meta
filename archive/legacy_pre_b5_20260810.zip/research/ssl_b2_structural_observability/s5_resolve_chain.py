"""S5 Stage 0R-b — resolve which frozen artefact version the P1B checkpoint was
actually trained against, by hashing every candidate and matching the four
hashes declared in the P1B run manifest.

The prior Stage 0 audit pinned the v1 supervision bank from prose. This script
decides it from bytes. Read-only.
"""
from __future__ import annotations

import hashlib
import json
import os
import sys

ROOT = r"D:\MetaSieve"
OPEN = os.path.join(ROOT, "dataset", "processed", "open_structures")
OUT = os.path.join(ROOT, "report", "ssl_s5")

DECLARED = {
    "ligand_bank": "823815c2e436d28403b14bc79fa5e86b99b511fdfda50b104995ad64abbe7012",
    "protein_manifest": "dc087bda9679951a4593776a598f006621a686e6cf6204e5c6645851eff72f43",
    "records": "45907b45b590c6ec27242fc07028444133a5f562f79eff9ba5951cb0b09fae1a",
    "supervision_manifest": "ad0e4803165cc8be0eacff1a833df4a67861ba231ac1048e42a066d280588fea",
}


def sha256(path, chunk=1 << 20):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while True:
            b = f.read(chunk)
            if not b:
                break
            h.update(b)
    return h.hexdigest()


def walk_candidates():
    """Every file that could plausibly be one of the four declared inputs."""
    for dirpath, _dirs, files in os.walk(OPEN):
        for fn in files:
            if fn.endswith((".json", ".jsonl", ".pt")):
                yield os.path.join(dirpath, fn)


def main():
    os.makedirs(OUT, exist_ok=True)
    inverse = {v: k for k, v in DECLARED.items()}
    resolved = {k: [] for k in DECLARED}
    scanned = 0
    for p in walk_candidates():
        try:
            h = sha256(p)
        except OSError:
            continue
        scanned += 1
        if h in inverse:
            resolved[inverse[h]].append(os.path.relpath(p, ROOT))

    print(f"scanned {scanned} candidate files under open_structures\n")
    for k in DECLARED:
        hits = resolved[k]
        print(f"{k:22s} -> {hits if hits else 'UNRESOLVED'}")

    # Verify the supervision bank the checkpoint actually points at.
    sup_dir = None
    if resolved["supervision_manifest"]:
        sup_dir = os.path.dirname(os.path.join(ROOT, resolved["supervision_manifest"][0]))
    shard_report = None
    if sup_dir:
        man = json.load(open(os.path.join(sup_dir, "manifest.json")))
        ok = bad = miss = 0
        for s in man["shards"]:
            p = os.path.join(sup_dir, s["path"])
            if not os.path.exists(p):
                miss += 1
            elif sha256(p) == s["sha256"]:
                ok += 1
            else:
                bad += 1
        shard_report = {"bank": os.path.relpath(sup_dir, ROOT), "shards_ok": ok,
                        "shards_mismatch": bad, "shards_missing": miss,
                        "records": man.get("pairs"),
                        "records_sha256": man.get("records_sha256"),
                        "governance_manifest_sha256":
                            man.get("homology_governance_manifest_sha256"),
                        "verdict": "PASS" if bad == 0 and miss == 0 else "FAIL"}
        print(f"\nsupervision bank actually referenced by the checkpoint: "
              f"{shard_report['bank']}  {shard_report['verdict']} "
              f"(ok={ok} bad={bad} missing={miss})")

        # follow records_sha256 and governance hash one more hop
        for label, target in (("supervision.records_sha256", man.get("records_sha256")),
                              ("supervision.governance_manifest",
                               man.get("homology_governance_manifest_sha256"))):
            hit = None
            for p in walk_candidates():
                try:
                    if sha256(p) == target:
                        hit = os.path.relpath(p, ROOT)
                        break
                except OSError:
                    continue
            print(f"  {label:34s} -> {hit or 'UNRESOLVED'}")
            shard_report[label] = hit

    res = {"schema": "MetaSieve.S5ProvenanceChainResolution.v1",
           "declared_by_p1b_manifest": DECLARED,
           "resolved_paths": resolved,
           "supervision_bank_in_use": shard_report}
    out = os.path.join(OUT, "S5_PROVENANCE_CHAIN_RESOLUTION.json")
    json.dump(res, open(out, "w"), indent=2)
    print(f"\nwrote {out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
