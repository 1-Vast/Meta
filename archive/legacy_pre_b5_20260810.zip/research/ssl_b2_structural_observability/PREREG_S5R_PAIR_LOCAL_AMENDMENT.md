# S5R — amendment to the S5 pair-local observability preregistration

Registered: 2026-08-09.
Status: **AMENDMENT, NOT REPLACEMENT.**
`PREREG_S5_LOCAL_MECHANISM_OBSERVABILITY.md` remains the governing document.
This file amends it in four places, all forced by code-derived findings in
`report/ssl_s5/S5_MAPPING_AND_SLOT_RETENTION_AUDIT.md`. Nothing here relaxes a
threshold, adds a module or widens the label surface.

Real affinity values, DAVIS/recipient labels, production `z`, CSMO/Band changes
and P2–P4 remain frozen. S5 remains label-free with respect to affinity.

## Amendment 1 — core channel set is narrowed

**Governing text amended:** §5 and §9 of the base preregistration, which allow a
"prespecified core channel" drawn from the six S2 channels.

**Finding forcing the amendment (M-7, EXACT).** The frozen path carries **no
angular information at any stage**. `_geometry` reduces each (ligand atom, slot)
pair to a min Euclidean distance, then to one of five bins. Donor–H···acceptor
angles and ring-plane normals are absent from the supervision tensor, from the
rank-32 bridge heads, and from the ESM slot state.

**Finding forcing the amendment (M-8, EXACT).** Directional hydrogen bonding is
simultaneously (a) the channel S4 recovered best in aggregate
(`R² = +0.268 [0.166, 0.378]` versus mean) and (b) `NOT_REPRESENTABLE` at the
deployable arm. Keeping it as a core channel would guarantee ligand dominance
for representational reasons and invite reading that artefact as biology.

**Amendment.** The feasibility criterion may be satisfied **only** by
`K1` (pocket burial coverage) or `K2` (apolar-contact burial), as defined in
`report/ssl_s5/S5_TEACHER_SPECIFICATION_AND_REPRODUCIBILITY.md` §3.
`K3`–`K6` are oracle-arm diagnostics. `K5` and `K6` must be printed with an
explicit `NOT_EVALUABLE` flag wherever they appear. A channel that is
`NOT_EVALUABLE` is not a zero-valued failure and may not be counted as evidence
in either direction.

## Amendment 2 — one arm added: `A5c`

**Governing text amended:** §6 ladder table.

**Findings forcing the amendment (M-5, §4 of the audit, EXACT).** Slot binning is
over sequence index; pockets are assembled from sequence-distant residues.
Therefore the slot `min` is generically attained by the pocket residue itself
(geometry survives comparatively well), while the ESM slot mean gives that
residue weight exactly `1/⌈L/128⌉` (identity is diluted linearly in `L`).
These two effects are confounded in every arm of the base ladder.

**Amendment.** Add exactly one arm:

```text
A5c :  A5 with the mean-ESM slot state replaced by an explicit
       20-dimensional slot residue-type composition vector,
       computed from the canonical sequence under the identical
       slot map  (i * 128) // L.
```

Cost: ~20 input dimensions. **No new module, no new encoder, no new parameters
in any frozen component.** This is inside the "minimum mechanism-specific model"
constraint and is registered specifically so that a Λ₅ failure is not
mistaken for a Λ₂/Λ₃ failure.

**Registered hypothesis H-DILUTION.** If `Λ₅` is the binding constraint then
(i) per-complex reconstruction decays monotonically with `L`, and
(ii) `A5c` recovers a measurable part of the correct-minus-ligand-only gap.

**Registered interpretation, fixed before scoring:**

| Observation | Verdict | Authorised repair |
|---|---|---|
| `A5c ≈ A5`, both `<< AO` | `FROZEN_P1B_LOCAL_STATE_INSUFFICIENT` | none at this stage; separately register pose-aware S7 |
| `A5c >> A5` | `REPRESENTATION_DEFECT_RECOVERABLE` | carry explicit slot composition |

In neither branch is a larger ESM, ESM fine-tuning, a deeper GNN,
cross-attention, a knowledge graph or multimodal fusion authorised.

## Amendment 3 — `A4`/`A5` are declared non-nested on the label side

**Governing text amended:** §6, arms `C4`/`C5`.

**Finding forcing the amendment (M-6, EXACT).** In `_geometry`,
`contact = 1[d ≤ 6]` and `digitize(d, [4,6,8,10]) ≤ 1 ⟺ d < 6`. The two
supervision targets coincide except on the null set `{d = 6.0}`. Contact carries
no information the distance bins lack.

**Amendment.** Any `A5 − A4` difference must be reported as a **difference
between two separately parameterised frozen heads**, not as additional
structural information. A positive `A5 − A4` gap is not evidence of geometry
retention and may not be cited as such.

**Added precondition.** Before the ladder runs, verify on the supervision shards
that `contact == (distance_bin <= 1)` on the masked support, up to the
`d = 6.0` null set. A violation indicates shard corruption or a contract drift
and is `S5_TEACHER_OR_SLOT_CONTRACT_DEFECT`.

## Amendment 4 — three teacher-fidelity defects registered before scoring

**Governing text amended:** §5, which asserts a chemistry-faithful teacher.

| ID | Defect | Frozen rule adopted |
|---|---|---|
| D-1 | `_protein_residue_atoms` applies no `type_symbol` filter, so deposited protein hydrogens enter the min-distance, while ligand hydrogens are excluded | The S5 teacher is defined over **heavy atoms only**. The divergence from the frozen supervision is measured and reported as its own term; it is a candidate explanation for any oracle-versus-slot gap. |
| D-2 | Residues with no tabulated one-letter code become `"X"` and align against the BLOSUM62 `X` row rather than failing closed; the base prereg's exclusion of modified residues is not implemented | `"X"` residues contribute `0` to `K2`/`K4`, still contribute to `K1` (geometry only), and are counted in an `unresolved_chemistry_residues` census. |
| D-3 | The governed corpus contains cofactors and metalloporphyrins (e.g. `101m`/`HEM`); metal coordination is unmodelled and `K4` misassigns it | A frozen pre-scoring exclusion rule for metal-containing and non-drug-like CCD components, registered **before** outcomes are inspected. |

## Unchanged

- Thresholds: `R²(correct vs mean) ≥ 0.02`;
  `R²(correct) − R²(ligand-only) ≥ 0.02`;
  `− R²(deranged) ≥ 0.02`; `− R²(pair-shuffle) ≥ 0.02`;
  each with 95 % LCB above zero.
- Inference and bootstrap units are closure components; atom–residue pairs are
  never IID.
- All ten anti-shortcut criteria.
- Terminal verdict set and the downstream decision tree.
- The promotion boundary: a structural PASS authorises **one** separately
  registered source-affinity experiment and nothing else.
- Frozen surfaces: `K(B(z)F(z))`, CSMO, Band, positive ridge, the simplex, the
  fixed mesh, `theory/FINAL_FROZEN_THEORY/`, `model/`, production `scripts/`.

## Execution preconditions — currently unmet

S5R may not execute until **all** of the following hold:

1. an execution environment exists (`conda run -n drug`);
2. `s2_teacher.py` and `s3s4_observability.py` are restored from commit
   `608decf` / `8b7789e` — not decompiled from `.pyc`;
3. the 1,118-complex S4 exposure registry is recovered, or a replacement is
   re-derived and re-registered as a **new** registry with its own hash;
4. every declared SHA-256 in the P1B input chain is verified;
5. the regression suite passes.

Until then the stage status is `S5_REGISTERED_NOT_RUN`, unchanged.
