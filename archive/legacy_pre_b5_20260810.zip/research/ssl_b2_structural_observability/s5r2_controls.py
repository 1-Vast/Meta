"""S5R-2 destructive controls that need a second frozen P1B forward pass.

Produces, for every record:
  * `e_deranged`  : arm AD — P1B run with a score-blind wrong protein
                    (different homology group, exact residue-slot count,
                    nearest sequence length) — the P1B gate's own policy.
  * `esm_pocket`  : arm A5e — background-subtracted, pocket-weighted mean of the
                    frozen ESM slot states, using the P1B contact posterior as
                    the pocket weight. Tests H-DILUTION against explicit
                    composition.

Nothing here is fitted. The derangement map is frozen and hashed before any arm
is scored. No affinity value, DAVIS record or recipient label is opened.
"""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

import numpy as np
import torch

ROOT = Path(r"D:\MetaSieve")
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "research" / "ssl_b2_structural_observability"))

from contracts.ligand_graph import ATOM_FEAT_DIM, BOND_FEAT_DIM, MAX_ATOMS  # noqa: E402
from s5r2_build import (CACHE, CHECKPOINT, LIGAND_BANK, OUT, PROTEIN_BANK,  # noqa: E402
                        RECORDS, S, SUPERVISION, ShardCache, build_model,
                        enrichment, read_jsonl, slot_composition)


def build_derangement(records, occ, n_std, seed=20260809):
    """Frozen, score-blind wrong-protein map.

    Policy (verbatim from report/mechanism_refactor/p1b_gate_.../gate_report.json):
      different registered homology group, exact residue-slot count,
      nearest sequence length.
    Candidates are drawn within the same split so no split boundary is crossed.
    """
    rng = np.random.default_rng(seed)
    n = len(records)
    slots = occ.sum(1).astype(int)
    lens = np.array([len(r["sequence"]) for r in records])
    groups = np.array([r["homology_group_id"] for r in records])
    splits = np.array([r["source_split"] for r in records])

    partner = np.full(n, -1, dtype=np.int64)
    reasons = {"ok": 0, "no_candidate": 0}
    for sp in sorted(set(splits.tolist())):
        pool = np.where(splits == sp)[0]
        by_slots = {}
        for j in pool:
            by_slots.setdefault(int(slots[j]), []).append(j)
        for i in pool:
            cands = [j for j in by_slots.get(int(slots[i]), []) if groups[j] != groups[i]]
            if not cands:
                reasons["no_candidate"] += 1
                continue
            cands = np.array(cands)
            d = np.abs(lens[cands] - lens[i])
            best = cands[d == d.min()]
            partner[i] = int(best[rng.integers(0, len(best))])
            reasons["ok"] += 1
    return partner, reasons


def main():
    records = read_jsonl(RECORDS)
    feats = np.load(CACHE / "s5r2_features.npz", allow_pickle=True)
    occ, n_std_all, w_pred_all = feats["occ"], feats["n_std"], feats["w_pred"]
    valid = feats["valid"]
    n = len(records)

    partner, reasons = build_derangement(records, occ, n_std_all)
    coverage = float((partner >= 0).mean())
    map_rows = [{"i": int(i), "entry": records[i]["source_entry_id"],
                 "partner": int(partner[i]),
                 "partner_entry": records[partner[i]]["source_entry_id"]
                 if partner[i] >= 0 else None}
                for i in range(n)]
    map_json = json.dumps(map_rows, sort_keys=True, separators=(",", ":"))
    map_sha = hashlib.sha256(map_json.encode()).hexdigest()
    print(f"derangement coverage={coverage:.4f} sha256={map_sha[:16]} {reasons}")

    pairs = {r["source_entry_id"]: r for r in read_jsonl(SUPERVISION / "pairs.jsonl")}
    prot_manifest = json.loads((PROTEIN_BANK / "manifest.json").read_text(encoding="utf-8"))
    protein_dim = int(prot_manifest["hidden_dim"])
    prot_lookup = {}
    for shard in prot_manifest["shards"]:
        with np.load(PROTEIN_BANK / shard["path"], allow_pickle=False) as z:
            for row, key in enumerate(z["keys"]):
                prot_lookup[str(key)] = (shard["path"], row)

    ligands = torch.load(LIGAND_BANK, map_location="cpu", weights_only=False)
    device = "cuda" if torch.cuda.is_available() else "cpu"
    model = build_model(protein_dim, device)

    e_der = np.zeros((n, 20), np.float64)
    esm_pocket = np.zeros((n, protein_dim), np.float32)
    der_valid = np.zeros(n, bool)

    geo_cache, esm_cache = ShardCache(2), ShardCache(4)
    batch = 16
    for start in range(0, n, batch):
        idx = list(range(start, min(start + batch, n)))
        X = torch.zeros(len(idx), MAX_ATOMS, ATOM_FEAT_DIM)
        A = torch.zeros(len(idx), MAX_ATOMS, MAX_ATOMS, BOND_FEAT_DIM)
        amask = torch.zeros(len(idx), MAX_ATOMS)
        pooled = np.zeros((len(idx), protein_dim), np.float32)
        resid = np.zeros((len(idx), S, protein_dim), np.float32)
        resid_correct = np.zeros((len(idx), S, protein_dim), np.float32)
        rmask = np.zeros((len(idx), S), np.float32)
        keep = []
        for b, i in enumerate(idx):
            rec = records[i]
            pair = pairs[rec["source_entry_id"]]
            g = geo_cache.get(SUPERVISION / pair["shard"],
                              ("atom_mask", "residue_mask"))
            k = pair["shard_index"]
            rm = g["residue_mask"][k]
            rmask[b] = rm.astype(np.float32)
            graph = ligands[rec["ccd_sha256"]]
            X[b] = graph["X"]
            amask[b] = graph["mask"]
            edge = graph["edge_index"].long()
            A[b, edge[0], edge[1]] = graph["edge_attr"]

            sp_c, row_c = prot_lookup[rec["sequence_sha256"]]
            ec = esm_cache.get(PROTEIN_BANK / sp_c, ("pooled", "residues"))
            resid_correct[b] = ec["residues"][row_c].astype(np.float32)

            j = int(partner[i])
            if j < 0 or not valid[i]:
                pooled[b] = ec["pooled"][row_c].astype(np.float32)
                resid[b] = resid_correct[b]
                continue
            sp_d, row_d = prot_lookup[records[j]["sequence_sha256"]]
            ed = esm_cache.get(PROTEIN_BANK / sp_d, ("pooled", "residues"))
            pooled[b] = ed["pooled"][row_d].astype(np.float32)
            resid[b] = ed["residues"][row_d].astype(np.float32)
            keep.append(b)

        with torch.inference_mode():
            _, atoms = model.ligand(X.to(device), A.to(device), amask.to(device))
            _, residues = model.protein(torch.from_numpy(pooled).to(device),
                                        torch.from_numpy(resid).to(device))
            pred = model.bridge(atoms, amask.to(device), residues,
                                torch.from_numpy(rmask).to(device))
            pc = pred.contact_prob.float().cpu().numpy()

        for b, i in enumerate(idx):
            occupied = rmask[b].astype(bool)
            # ---- A5e: pocket-weighted, background-subtracted frozen ESM ----
            wp = w_pred_all[i].astype(np.float64) * occupied
            nb = n_std_all[i].astype(np.float64) * occupied
            if wp.sum() > 0 and nb.sum() > 0:
                esm_pocket[i] = ((wp[:, None] * resid_correct[b]).sum(0) / wp.sum()
                                 - (nb[:, None] * resid_correct[b]).sum(0) / nb.sum())
            # ---- AD: enrichment under the wrong protein ----
            if b not in keep:
                continue
            j = int(partner[i])
            amb = amask[b].numpy().astype(bool)
            Cd, n_std_d, _ = slot_composition(records[j]["sequence"])
            wd = (pc[b] * amb[:, None]).sum(0).astype(np.float64) * occupied
            rd = enrichment(wd, Cd, n_std_d, occupied)
            if rd is None:
                continue
            e_der[i] = rd[0]
            der_valid[i] = True

        if (start // batch) % 100 == 0:
            print(f"  {min(start + batch, n)}/{n}", flush=True)

    np.savez_compressed(CACHE / "s5r2_controls.npz",
                        e_deranged=e_der, der_valid=der_valid,
                        partner=partner, esm_pocket=esm_pocket)
    meta = {"schema": "MetaSieve.S5R2Controls.v1",
            "derangement_policy": "different homology group, exact residue-slot "
                                  "count, nearest sequence length, within split",
            "derangement_seed": 20260809,
            "derangement_map_sha256": map_sha,
            "derangement_coverage": coverage,
            "derangement_valid": int(der_valid.sum()),
            "reasons": reasons,
            "checkpoint_sha256": hashlib.sha256(CHECKPOINT.read_bytes()).hexdigest()}
    (OUT / "S5R2_CONTROL_MAP.json").write_text(json.dumps(meta, indent=2),
                                               encoding="utf-8")
    print(json.dumps(meta, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
