"""S5R-2 — immutable artifact hash manifest for every code file and output."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

ROOT = Path(r"D:\MetaSieve")
OUT = ROOT / "report" / "ssl_s5"
RES = ROOT / "research" / "ssl_b2_structural_observability"
CACHE = ROOT / "dataset" / "processed" / "ssl_s5"


def sha256(p, chunk=1 << 20):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        while True:
            b = f.read(chunk)
            if not b:
                break
            h.update(b)
    return h.hexdigest()


def main():
    groups = {
        "research_code": sorted(RES.glob("s5r2_*.py")) + sorted(RES.glob("s5_*.py")),
        "recovered_registered_code": [RES / "s2_teacher.py",
                                      RES / "s3s4_observability.py"],
        "preregistrations": sorted(RES.glob("PREREG_*.md")),
        "results": sorted(OUT.glob("S5R2_*.json")) + sorted(OUT.glob("S5R2_*.md")),
        "derived_features": sorted(CACHE.glob("*.npz")),
        "frozen_inputs": [
            ROOT / "report/mechanism_refactor/p1b_pilot20k_seed17_v1/best.pt",
            ROOT / "dataset/processed/open_structures/pilot20k_mechanism_ligands_v1.pt",
            ROOT / "dataset/processed/open_structures/pilot20k_structure_supervision_v2/manifest.json",
            ROOT / "dataset/processed/open_structures/pilot20k_esm2_t30_slots128_v1/manifest.json",
            ROOT / "dataset/processed/open_structures/pilot20k_homology_split_v2/complexes.jsonl",
            ROOT / "dataset/processed/open_structures/pilot20k_holo_governed_v2/complexes.jsonl",
            ROOT / "dataset/processed/open_structures/pilot20k_governance_v2/manifest.json",
        ],
    }
    manifest = {"schema": "MetaSieve.S5R2ArtifactHashes.v1", "groups": {}}
    for name, paths in groups.items():
        entries = {}
        for p in paths:
            p = Path(p)
            if p.is_file():
                entries[str(p.relative_to(ROOT)).replace("\\", "/")] = {
                    "sha256": sha256(p), "bytes": p.stat().st_size}
        manifest["groups"][name] = entries
        print(f"{name}: {len(entries)} files")
    dest = OUT / "S5R2_ARTIFACT_HASHES.json"
    dest.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    print(f"wrote {dest}")


if __name__ == "__main__":
    main()
