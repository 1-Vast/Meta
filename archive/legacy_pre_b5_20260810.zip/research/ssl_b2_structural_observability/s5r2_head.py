"""S5R-2 Stages 4 and 5 — pair-local head, with a synthetic trainability control
and a full module-participation audit.

    --mode synthetic   Stage 4. The target is a fixed, known function of the
                       frozen pair state. If the head cannot recover it, the
                       defect is optimisation, not biology
                       (S5_HEAD_OR_OPTIMIZATION_NOT_IDENTIFIED).
    --mode real        Stage 5. The target is the pair-local named-channel
                       contribution from true coordinates. Asks exactly one
                       question: does a learned pair map add anything over the
                       zero-parameter deterministic readout?

Everything upstream is frozen and run under inference_mode: ESM slot bank,
ProteinEncoder, ligand GINE, the P1B bridge and both geometry heads. The only
trainable object is g_theta.

Module-participation audit (requirement 3), all reported:
  gradient norms per branch, parameter movement, activation variance,
  branch ablation, input shuffling, gradient blocking, capacity-matched control.

No affinity value, DAVIS record, recipient label or pose-aware datum is opened.
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn

ROOT = Path(r"D:\MetaSieve")
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "research" / "ssl_b2_structural_observability"))

from contracts.ligand_graph import ATOM_FEAT_DIM, BOND_FEAT_DIM, MAX_ATOMS  # noqa: E402
from s5r2_build import (CACHE, LIGAND_BANK, OUT, PROTEIN_BANK, RECORDS, S,  # noqa: E402
                        SUPERVISION, ShardCache, build_model, read_jsonl,
                        slot_composition)
from s5r2_ladder import SETS, indicator  # noqa: E402

CHANNELS = list(SETS)
D_ATOM, D_SLOT, D_GEOM = 128 + ATOM_FEAT_DIM, 128 + 20, 6


class PairHead(nn.Module):
    """g_theta with three named input branches so participation is auditable.

    `stats` supplies frozen per-feature (mean, std) for each branch, estimated
    once from a calibration sample and registered as buffers. This is the
    normalisation repair that PREREG_S5 section 7 names explicitly as an
    authorised outcome of the synthetic trainability control. It adds no
    capacity: the statistics are constants, not parameters.
    """

    def __init__(self, hidden=1024, out=len(CHANNELS), stats=None):
        super().__init__()
        self.lig_branch = nn.Linear(D_ATOM, 256)
        self.prot_branch = nn.Linear(D_SLOT, 256)
        self.geom_branch = nn.Linear(D_GEOM, 64)
        self.trunk = nn.Sequential(
            nn.Linear(256 + 256 + 64, hidden), nn.SiLU(),
            nn.Linear(hidden, hidden), nn.SiLU(),
            nn.Linear(hidden, out))
        self.last_act = {}
        self.normalised = stats is not None
        for name, dim in (("lig", D_ATOM), ("prot", D_SLOT), ("geom", D_GEOM)):
            mu = stats[name][0] if stats else torch.zeros(dim)
            sd = stats[name][1] if stats else torch.ones(dim)
            self.register_buffer(f"{name}_mu", mu)
            self.register_buffer(f"{name}_sd", sd)

    def forward(self, lig, prot, geom, block=(), ablate=()):
        lig = (lig - self.lig_mu) / self.lig_sd
        prot = (prot - self.prot_mu) / self.prot_sd
        geom = (geom - self.geom_mu) / self.geom_sd
        a = self.lig_branch(lig)
        b = self.prot_branch(prot)
        c = self.geom_branch(geom)
        if "ligand" in block:
            a = a.detach()
        if "protein" in block:
            b = b.detach()
        if "geometry" in block:
            c = c.detach()
        if "ligand" in ablate:
            a = torch.zeros_like(a)
        if "protein" in ablate:
            b = torch.zeros_like(b)
        if "geometry" in ablate:
            c = torch.zeros_like(c)
        self.last_act = {"ligand": a, "protein": b, "geometry": c}
        return self.trunk(torch.cat([a, b, c], dim=-1))


def synthetic_target(lig, prot, geom, seed=1234):
    """A fixed, smooth, known function of the frozen pair state (Stage 4)."""
    g = torch.Generator(device="cpu").manual_seed(seed)
    wl = torch.randn(lig.shape[-1], len(CHANNELS), generator=g)
    wp = torch.randn(prot.shape[-1], len(CHANNELS), generator=g)
    wg = torch.randn(geom.shape[-1], len(CHANNELS), generator=g)
    wl, wp, wg = (w.to(lig.device) for w in (wl, wp, wg))
    z = lig @ wl / np.sqrt(lig.shape[-1]) + prot @ wp / np.sqrt(prot.shape[-1])
    return torch.tanh(z) * torch.sigmoid(geom @ wg)


class PairStream:
    """Builds frozen pair states [B,N,S,*] from the immutable banks."""

    def __init__(self, device):
        self.device = device
        self.records = read_jsonl(RECORDS)
        self.pairs = {r["source_entry_id"]: r
                      for r in read_jsonl(SUPERVISION / "pairs.jsonl")}
        man = json.loads((PROTEIN_BANK / "manifest.json").read_text(encoding="utf-8"))
        self.protein_dim = int(man["hidden_dim"])
        self.lookup = {}
        for shard in man["shards"]:
            with np.load(PROTEIN_BANK / shard["path"], allow_pickle=False) as z:
                for row, key in enumerate(z["keys"]):
                    self.lookup[str(key)] = (shard["path"], row)
        self.ligands = torch.load(LIGAND_BANK, map_location="cpu", weights_only=False)
        self.model = build_model(self.protein_dim, device)
        for p in self.model.parameters():
            p.requires_grad_(False)
        self.geo = ShardCache(2)
        self.esm = ShardCache(4)
        self.U = torch.tensor(np.stack([indicator(SETS[c]) for c in CHANNELS]).T,
                              dtype=torch.float32, device=device)   # [20, C]

    def batch(self, idxs):
        B = len(idxs)
        X = torch.zeros(B, MAX_ATOMS, ATOM_FEAT_DIM)
        A = torch.zeros(B, MAX_ATOMS, MAX_ATOMS, BOND_FEAT_DIM)
        am = torch.zeros(B, MAX_ATOMS)
        pooled = np.zeros((B, self.protein_dim), np.float32)
        resid = np.zeros((B, S, self.protein_dim), np.float32)
        rm = np.zeros((B, S), np.float32)
        contact = np.zeros((B, MAX_ATOMS, S), np.float32)
        comp = np.zeros((B, S, 20), np.float32)
        for b, i in enumerate(idxs):
            rec = self.records[i]
            pr = self.pairs[rec["source_entry_id"]]
            g = self.geo.get(SUPERVISION / pr["shard"],
                             ("contact", "atom_mask", "residue_mask"))
            k = pr["shard_index"]
            contact[b] = g["contact"][k].astype(np.float32)
            rm[b] = g["residue_mask"][k].astype(np.float32)
            gr = self.ligands[rec["ccd_sha256"]]
            X[b] = gr["X"]
            am[b] = gr["mask"]
            e = gr["edge_index"].long()
            A[b, e[0], e[1]] = gr["edge_attr"]
            sp, row = self.lookup[rec["sequence_sha256"]]
            z = self.esm.get(PROTEIN_BANK / sp, ("pooled", "residues"))
            pooled[b] = z["pooled"][row].astype(np.float32)
            resid[b] = z["residues"][row].astype(np.float32)
            C, _n_std, _ = slot_composition(rec["sequence"])
            comp[b] = C.astype(np.float32)

        dev = self.device
        X, A, am = X.to(dev), A.to(dev), am.to(dev)
        rm_t = torch.from_numpy(rm).to(dev)
        with torch.inference_mode():
            _, atoms = self.model.ligand(X, A, am)
            _, residues = self.model.protein(torch.from_numpy(pooled).to(dev),
                                             torch.from_numpy(resid).to(dev))
            pred = self.model.bridge(atoms, am, residues, rm_t)
            pc = pred.contact_prob.float()
            pd = pred.distance_prob.float()
        atoms, residues = atoms.clone(), residues.clone()
        pc, pd = pc.clone(), pd.clone()

        N = MAX_ATOMS
        lig = torch.cat([atoms, X], dim=-1).unsqueeze(2).expand(B, N, S, D_ATOM)
        comp_t = torch.from_numpy(comp).to(dev)
        prot = torch.cat([residues, comp_t], dim=-1).unsqueeze(1).expand(B, N, S, D_SLOT)
        geom = torch.cat([pc.unsqueeze(-1), pd], dim=-1)
        mask = (am.unsqueeze(-1) * rm_t.unsqueeze(1))
        ct = torch.from_numpy(contact).to(dev)
        target = ct.unsqueeze(-1) * (comp_t @ self.U).unsqueeze(1)
        return lig, prot, geom, mask, target


def calibration_stats(stream, idxs, batch, n_batches=25):
    """Frozen per-feature mean/std per branch, from a calibration sample only."""
    acc = {k: [] for k in ("lig", "prot", "geom")}
    for s in range(0, min(len(idxs), n_batches * batch), batch):
        lig, prot, geom, mask, _ = stream.batch(idxs[s:s + batch])
        m = mask.bool()
        for k, t in (("lig", lig), ("prot", prot), ("geom", geom)):
            acc[k].append(t[m].float().cpu())
    stats = {}
    for k, chunks in acc.items():
        x = torch.cat(chunks, 0)
        stats[k] = (x.mean(0), x.std(0).clamp_min(1e-3))
    return stats


def aggregate_eval(head, stream, idxs, batch, feats):
    """Stage 5's decisive question: does the learned pair map beat the
    zero-parameter deterministic readout on the registered coordinate `e`?

    The head's pair outputs are aggregated with exactly A5's denominator
    (the P1B contact posterior), so A5 is the special case
    g_theta(u_ij) = p_contact_ij * C[j, u_c]. Same rows, same target, same
    background subtraction.
    """
    head.eval()
    u = torch.tensor(np.stack([indicator(SETS[c]) for c in CHANNELS]).T,
                     dtype=torch.float32, device=stream.device)
    e_head, rows = [], []
    with torch.no_grad():
        for s in range(0, len(idxs), batch):
            chunk = idxs[s:s + batch]
            lig, prot, geom, mask, _t = stream.batch(chunk)
            with torch.autocast("cuda", torch.float16,
                                enabled=stream.device == "cuda"):
                out = head(lig, prot, geom).float()
            pc = geom[..., 0]                                   # p(contact)
            denom = (pc * mask).sum(dim=(1, 2)).clamp_min(1e-9)
            q = (out * mask.unsqueeze(-1)).sum(dim=(1, 2)) / denom.unsqueeze(-1)
            for b, i in enumerate(chunk):
                occ = feats["occ"][i].astype(bool)
                nb = feats["n_std"][i].astype(np.float64) * occ
                C = feats["comp"][i].astype(np.float64)
                bg = (nb[:, None] * C).sum(0) / max(nb.sum(), 1e-9)
                bgc = bg @ u.cpu().numpy()
                e_head.append(q[b].cpu().numpy() - bgc)
                rows.append(int(i))
    return np.asarray(e_head), np.asarray(rows)


def masked_huber(pred, target, mask, delta=1.0):
    d = pred - target
    a = d.abs()
    loss = torch.where(a <= delta, 0.5 * d * d, delta * (a - 0.5 * delta))
    m = mask.unsqueeze(-1)
    return (loss * m).sum() / m.sum().clamp_min(1.0) / pred.shape[-1]


def evaluate(head, stream, idxs, mode, batch, ablate=(), shuffle=None):
    head.eval()
    tot = n = 0.0
    with torch.no_grad():
        for s in range(0, len(idxs), batch):
            lig, prot, geom, mask, target = stream.batch(idxs[s:s + batch])
            if mode == "synthetic":
                target = synthetic_target(lig, prot, geom)
            if shuffle == "protein":
                prot = prot[:, :, torch.randperm(prot.shape[2], device=prot.device)]
            elif shuffle == "ligand":
                lig = lig[:, torch.randperm(lig.shape[1], device=lig.device)]
            elif shuffle == "geometry":
                geom = geom[:, :, torch.randperm(geom.shape[2], device=geom.device)]
            with torch.autocast("cuda", torch.float16, enabled=stream.device == "cuda"):
                out = head(lig, prot, geom, ablate=ablate)
                loss = masked_huber(out.float(), target, mask)
            tot += float(loss) * len(idxs[s:s + batch])
            n += len(idxs[s:s + batch])
    return tot / max(n, 1)


def train(head, stream, tr, mode, batch, epochs, lr, block=(), log=None):
    opt = torch.optim.AdamW(head.parameters(), lr=lr, weight_decay=1e-4)
    scaler = torch.amp.GradScaler("cuda", enabled=stream.device == "cuda")
    grad_norms = {"ligand": [], "protein": [], "geometry": [], "trunk": []}
    act_var = {"ligand": [], "protein": [], "geometry": []}
    head.train()
    step = 0
    for _ep in range(epochs):
        order = np.random.default_rng(_ep).permutation(tr)
        for s in range(0, len(order), batch):
            idxs = order[s:s + batch].tolist()
            lig, prot, geom, mask, target = stream.batch(idxs)
            if mode == "synthetic":
                target = synthetic_target(lig, prot, geom)
            with torch.autocast("cuda", torch.float16, enabled=stream.device == "cuda"):
                out = head(lig, prot, geom, block=block)
                loss = masked_huber(out.float(), target, mask)
            opt.zero_grad(set_to_none=True)
            scaler.scale(loss).backward()
            scaler.unscale_(opt)
            for name, mod in (("ligand", head.lig_branch), ("protein", head.prot_branch),
                              ("geometry", head.geom_branch), ("trunk", head.trunk)):
                g = sum(float(p.grad.norm()) ** 2 for p in mod.parameters()
                        if p.grad is not None) ** 0.5
                grad_norms[name].append(g)
            for name, a in head.last_act.items():
                act_var[name].append(float(a.float().var()))
            torch.nn.utils.clip_grad_norm_(head.parameters(), 5.0)
            scaler.step(opt)
            scaler.update()
            step += 1
            if log and step % 50 == 0:
                print(f"    step {step} loss={float(loss):.5f}", flush=True)
    return grad_norms, act_var


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mode", choices=("synthetic", "real"), required=True)
    ap.add_argument("--train-n", type=int, default=1200)
    ap.add_argument("--test-n", type=int, default=400)
    ap.add_argument("--batch", type=int, default=4)
    ap.add_argument("--epochs", type=int, default=2)
    ap.add_argument("--lr", type=float, default=3e-4)
    ap.add_argument("--hidden", type=int, default=1024)
    ap.add_argument("--normalize", action="store_true",
                    help="apply frozen per-branch input standardisation "
                         "(the registered repair for a scale-conditioning defect)")
    ap.add_argument("--tag", default="")
    args = ap.parse_args()

    device = "cuda" if torch.cuda.is_available() else "cpu"
    # NpzFile decompresses on every key access; materialise once.
    with np.load(CACHE / "s5r2_features.npz", allow_pickle=True) as z:
        f = {k: z[k] for k in z.files}
    valid, split = f["valid"], f["split"]
    rng = np.random.default_rng(20260809)
    tr_all = np.where(valid & (split == "train"))[0]
    te_all = np.where(valid & (split == "test"))[0]
    tr = rng.choice(tr_all, min(args.train_n, len(tr_all)), replace=False)
    te = rng.choice(te_all, min(args.test_n, len(te_all)), replace=False)

    stream = PairStream(device)
    stats = None
    if args.normalize:
        print("estimating frozen per-branch calibration statistics ...", flush=True)
        stats = calibration_stats(stream, tr.tolist(), args.batch)
        stats = {k: (v[0].to(device), v[1].to(device)) for k, v in stats.items()}
    head = PairHead(args.hidden, stats=stats).to(device)
    n_par = sum(p.numel() for p in head.parameters())
    print(f"mode={args.mode} params={n_par:,} train={len(tr)} test={len(te)} dev={device}",
          flush=True)
    if not 1e6 <= n_par <= 5e6:
        print(f"WARNING: parameter count {n_par} outside the registered 1-5M band")

    init = {k: v.detach().clone() for k, v in head.state_dict().items()}
    t0 = time.time()
    base_loss = evaluate(head, stream, te.tolist(), args.mode, args.batch)
    grad_norms, act_var = train(head, stream, tr, args.mode, args.batch,
                                args.epochs, args.lr, log=True)
    final_loss = evaluate(head, stream, te.tolist(), args.mode, args.batch)
    print(f"untrained={base_loss:.5f}  trained={final_loss:.5f}  "
          f"({time.time() - t0:.0f}s)", flush=True)

    audit = {"schema": "MetaSieve.S5R2ModuleParticipation.v1", "mode": args.mode,
             "input_standardisation": bool(args.normalize),
             "parameters": int(n_par), "train_records": int(len(tr)),
             "test_records": int(len(te)), "epochs": args.epochs,
             "loss_untrained": base_loss, "loss_trained": final_loss,
             "gradient_norm_mean": {k: float(np.mean(v)) for k, v in grad_norms.items()},
             "gradient_norm_last_decile": {
                 k: float(np.mean(v[-max(1, len(v) // 10):])) for k, v in grad_norms.items()},
             "activation_variance_mean": {k: float(np.mean(v)) for k, v in act_var.items()},
             "parameter_movement_relative": {}, "branch_ablation": {},
             "input_shuffle": {}, "gradient_blocking": {}}

    for mod_name, prefix in (("ligand", "lig_branch"), ("protein", "prot_branch"),
                             ("geometry", "geom_branch"), ("trunk", "trunk")):
        num = den = 0.0
        for k, v in head.state_dict().items():
            if k.startswith(prefix):
                num += float((v.detach().cpu() - init[k].cpu()).norm()) ** 2
                den += float(init[k].cpu().norm()) ** 2
        audit["parameter_movement_relative"][mod_name] = float((num ** 0.5) /
                                                               max(den ** 0.5, 1e-12))

    for br in ("ligand", "protein", "geometry"):
        audit["branch_ablation"][br] = {
            "loss": evaluate(head, stream, te.tolist(), args.mode, args.batch,
                             ablate=(br,))}
        audit["branch_ablation"][br]["delta_vs_trained"] = (
            audit["branch_ablation"][br]["loss"] - final_loss)
        audit["input_shuffle"][br] = {
            "loss": evaluate(head, stream, te.tolist(), args.mode, args.batch,
                             shuffle=br)}
        audit["input_shuffle"][br]["delta_vs_trained"] = (
            audit["input_shuffle"][br]["loss"] - final_loss)

    for br in ("ligand", "protein", "geometry"):
        h2 = PairHead(args.hidden, stats=stats).to(device)
        train(h2, stream, tr, args.mode, args.batch, args.epochs, args.lr, block=(br,))
        audit["gradient_blocking"][br] = {
            "loss": evaluate(h2, stream, te.tolist(), args.mode, args.batch),
            "note": f"{br} branch detached from the graph for the whole run"}
        audit["gradient_blocking"][br]["delta_vs_trained"] = (
            audit["gradient_blocking"][br]["loss"] - final_loss)
        del h2
        torch.cuda.empty_cache()

    if args.mode == "real":
        e_head, rows = aggregate_eval(head, stream, te.tolist(), args.batch, f)
        comp_report = {}
        for ci, cname in enumerate(CHANNELS):
            uvec = indicator(SETS[cname])
            y = f["e_true"][rows] @ uvec
            base = f["e_true"][tr] @ uvec
            a5 = f["e_pred"][rows] @ uvec
            hh = e_head[:, ci]

            def r2(p):
                return float(1 - ((y - p) ** 2).sum() /
                             max(((y - base.mean()) ** 2).sum(), 1e-12))

            # identical affine calibration for both, fitted on the same rows
            def cal(p):
                A = np.column_stack([p, np.ones_like(p)])
                c, *_ = np.linalg.lstsq(A, y, rcond=None)
                return p * c[0] + c[1]

            comp_report[cname] = {
                "r2_zero_parameter_A5": r2(cal(a5)),
                "r2_trained_head": r2(cal(hh)),
                "head_minus_A5": r2(cal(hh)) - r2(cal(a5)),
            }
        audit["aggregate_vs_zero_parameter"] = comp_report
        audit["head_beats_zero_parameter_on_core"] = bool(
            comp_report["APOLAR"]["head_minus_A5"] > 0)
        print("\naggregate comparison on the registered coordinate e "
              f"({len(rows)} test complexes):")
        for cname, v in comp_report.items():
            print(f"  {cname:9s} A5={v['r2_zero_parameter_A5']:+.4f} "
                  f"head={v['r2_trained_head']:+.4f} "
                  f"delta={v['head_minus_A5']:+.4f}")

    verdict = {}
    for br in ("ligand", "protein", "geometry"):
        used = (audit["gradient_norm_last_decile"][br] > 1e-8
                and audit["parameter_movement_relative"][br] > 1e-3
                and audit["branch_ablation"][br]["delta_vs_trained"] > 0
                and audit["input_shuffle"][br]["delta_vs_trained"] > 0)
        verdict[br] = "CAUSALLY_USED" if used else "NOT_CAUSALLY_USED"
    audit["module_verdict"] = verdict
    audit["all_modules_participate"] = all(v == "CAUSALLY_USED" for v in verdict.values())

    out = OUT / f"S5R2_HEAD_{args.mode.upper()}{args.tag}.json"
    out.write_text(json.dumps(audit, indent=2), encoding="utf-8")
    print(json.dumps(audit, indent=2))
    print(f"wrote {out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
