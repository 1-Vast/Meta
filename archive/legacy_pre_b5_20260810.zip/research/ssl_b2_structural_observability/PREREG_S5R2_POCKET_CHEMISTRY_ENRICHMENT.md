# S5R-2 — pocket-chemistry enrichment as the pair-local structural channel

Registered: 2026-08-09, **before any arm was scored**.
Status: **AMENDMENT to `PREREG_S5_LOCAL_MECHANISM_OBSERVABILITY.md`**, itself
already amended by `PREREG_S5R_PAIR_LOCAL_AMENDMENT.md`. Both remain governing.
This document adds a channel definition, one required criterion, and a
tautology rule. It **relaxes nothing**, adds no module, widens no label surface.

S5 remains label-free with respect to affinity. Real affinity values,
DAVIS/recipient labels, PLIP, pose-aware data, production `z`, CSMO, Band, the
positive ridge, the simplex, the fixed mesh, `K(B(z)F(z))`,
`theory/FINAL_FROZEN_THEORY/`, `model/` and production `scripts/` are unchanged
and unread-for-write.

## 0. Stage-0 preconditions — now met

The five execution preconditions of `PREREG_S5R_PAIR_LOCAL_AMENDMENT.md` §
"Execution preconditions" are discharged:

| # | Precondition | Evidence |
|---|---|---|
| 1 | execution environment | `conda run -n drug`, Python 3.11.15, torch 2.6.0+cu124, CUDA 12.4, RTX 4060 Laptop 8 GB |
| 2 | `s2_teacher.py`, `s3s4_observability.py` restored, not decompiled | `git checkout 608decf --`; both are **bytecode-identical** to the surviving `__pycache__` under CPython 3.11 (`S5_ARTIFACT_RECOVERY_VERIFICATION.json`) |
| 3 | 1,118-complex S4 exposure registry | recovered: `report/ssl_b2_structural_observability/` + `dataset/processed/ssl_b2/teacher_dataset.npz` (`pdbs`, `pclus`, `scaffold`) |
| 4 | declared SHA-256 verified | `S5_INPUT_HASH_VERIFICATION.json`, `S5_PROVENANCE_CHAIN_RESOLUTION.json` |
| 5 | regression suite | 75 passed |

### 0.1 Provenance correction — the prior audit pinned the wrong bank

The Stage 0 audit asserted the P1B checkpoint's inputs were the `_v1` banks.
Resolved from bytes, the four hashes declared in
`report/mechanism_refactor/p1b_pilot20k_seed17_v1/manifest.json` are:

```text
supervision_manifest ad0e4803 -> pilot20k_structure_supervision_v2/manifest.json
records              45907b45 -> pilot20k_homology_split_v2/complexes.jsonl
protein_manifest     dc087bda -> pilot20k_esm2_t30_slots128_v1/manifest.json
ligand_bank          823815c2 -> pilot20k_mechanism_ligands_v1.pt
```

and one hop further, supervision v2 declares
`records_sha256 -> pilot20k_holo_governed_v2/complexes.jsonl` and
`homology_governance_manifest_sha256 -> pilot20k_governance_v2/manifest.json`.
All 117 v2 supervision shards and all 117 ESM shards verify.
**S5R-2 uses the v2 chain exclusively.** The v1 banks are not P1B's inputs and
are not read.

## 1. Why a new channel definition is required

Amendment 1 restricted the feasibility criterion to `K1` (pocket burial
coverage) and `K2` (apolar-contact burial). Reading the frozen builder
`scripts/build_structure_supervision.py::_geometry` establishes a fact that
disqualifies `K1` as stated:

> `contact = 1[d <= 6]` **is** the P1B training target.

`K1`, defined as per-slot burial coverage, is therefore a deterministic
aggregate of the exact tensor P1B minimised its loss against. Scoring P1B's
predicted contact against `K1` measures training fit, not mechanism
observability. Registered rule:

> **T-RULE.** Any channel that is a measurable function of
> `(contact, distance_bin)` alone is `TAUTOLOGICAL_WITH_P1B_TRAINING_TARGET`.
> It is reported as a reference ceiling and **may not** satisfy the feasibility
> criterion.

`K1` is hereby moved to `TAUTOLOGICAL_REFERENCE`. `K2` survives, because apolar
contact burial is *not* a function of geometry alone: it requires the chemical
identity of the residues lining the pocket, which no geometry tensor carries.

## 2. The registered channel — pocket-chemistry enrichment `e`

All quantities below are deterministic, continuous, and computed with **zero
trainable parameters**.

**Slot map (unchanged, frozen).** For canonical sequence index `i in 0..L-1`,
`sigma(i) = min(127, i*128 // L)`. This is bit-identical to the geometry slot
map and the ESM slot map (finding M-4); no re-indexing occurs.

**Slot composition (deployable, sequence-only).**
`C[s,t] = (1/n_s) * #{i : sigma(i)=s and aa(i)=t}`, `t` over the 20 standard
types, `n_s = #{i : sigma(i)=s}`.

**Pocket weight.**

```text
oracle       w*(s)   = sum_a atom_mask[a] * contact[a,s]         (true, from coordinates)
deployable   w^(s)   = sum_a atom_mask[a] * p_contact[a,s]       (frozen P1B, predicted)
```

**Pocket composition** `q[t] = sum_s w(s) C[s,t] / sum_s w(s)`.
**Background** `b[t] = sum_s n_s C[s,t] / sum_s n_s` (whole-sequence composition).

**Registered mechanism coordinate**

```text
e[t] = q[t] - b[t]          t = 1..20
```

### 2.1 Mathematical admissibility (requirement 1)

| Property | Statement |
|---|---|
| Boundedness | `q, b` are probability vectors, so `e in [-1,1]^20` unconditionally. No clipping, no learned scale. |
| Gauge | `sum_t e[t] = 0` exactly. `e` is a tangent vector to the 20-simplex; the "uniform composition shift" gauge is quotiented out by construction, not by a penalty. |
| Rank | The admissible coordinate space has rank `<= 19`. Named projections reduce it further to a `<= 6`-dimensional interpretable basis (§2.2). |
| Invariance | Invariant to rotation, translation, atom order, residue order, sequence length, and to the protein's overall amino-acid usage bias (background-subtracted). |
| Support-identifiable sections | `e` is a fixed finite-dimensional per-pair statistic, so a `k`-shot support set identifies at most `rank(support design) <= k` directions of any downstream mechanism-coefficient map. The adaptive dimension is capped at `min(k, dim(named basis))`. |
| Operator | `K(B(z)F(z))` is **unchanged**. `e` is a candidate *coordinate of* `z`; admission is not claimed and not authorised by this document. |
| Abstention | A query whose pocket weight is concentrated on slots outside the support row space is abstained on, with conditioning and coverage reported. |

### 2.2 Named projections

Frozen residue sets, standard biochemistry, fixed before scoring:

```text
APOLAR    A V L I M F W C
AROMATIC  F W Y H
DONOR     S T N Q Y W K R H
ACCEPTOR  S T N Q Y D E H
POS       K R H
NEG       D E
```

`E_x = <e, 1_x>` for each set `x`.

**CORE channel (exactly one):** `E_APOLAR`. It is the slot-resolved,
background-subtracted form of `K2`, the only channel surviving Amendment 1 and
T-RULE. Registering a single core channel removes multiplicity fishing.

**SECONDARY diagnostics, reported, never decisive:** `E_AROMATIC`, `E_DONOR`,
`E_ACCEPTOR`, `E_POS`, `E_NEG`, and the full 20-vector `e`.

**TAUTOLOGICAL_REFERENCE, excluded from the criterion:** `K1` pocket coverage.

**NOT_EVALUABLE, printed with the flag:** `K5` directional hydrogen bond and
`K6` aromatic orientation remain `NOT_REPRESENTABLE` (finding M-7: the frozen
contract carries no angular information at any stage). `E_AROMATIC` is a
composition enrichment and is **not** a restatement of `K6`; it needs no angle.

## 3. Splits, units, exposure

* Evaluation is on P1B's own **test** split of `pilot20k_homology_split_v2`
  (1,490 records), which the checkpoint never trained on. Any arm requiring a
  fit is fitted on the **train** split (11,926) only.
* Inference and bootstrap units are **protein homology groups**
  (MMseqs2 40 % id / 80 % cov) and, separately, **Bemis-Murcko scaffolds**.
  Atom-residue pairs and complexes are never treated as IID. The reported
  interval is the **wider** of the two unit systems.
* The 1,118-complex S4 set is development-exposed and is not used here.
* No affinity value is read. Counters `recipient_label_reads` and
  `davis_label_reads` remain 0.

## 4. Observability ladder

All arms share identical rows, splits, units and metric.

| Arm | Inputs | Role |
|---|---|---|
| `A0` | train mean of `e` | null |
| `A1` | ligand-only (CCD atom-composition + pooled frozen GINE state) | ligand shortcut |
| `A2` | background composition `b` only | **protein without geometry** |
| `A2e` | mean-pooled frozen ESM only | protein without geometry, learned |
| `A3` | `A1 + A2` | chemistry without geometry |
| `A5` | **`w^` from frozen P1B x deployable `C`, zero parameters** | the deployable claim |
| `A5e` | `w^` x frozen ESM slot states, low-rank probe | mean-ESM variant of `A5` (tests H-DILUTION) |
| `AO` | `w*` from true coordinates x `C` | oracle ceiling (`e` by definition) |
| `AR` | capacity-matched random features | realisation control |
| `AD` | `A5` with a score-blind wrong protein, `<40 %` identity, different homology group, nearest sequence length | **partner specificity** |
| `AG` | `A5` with `w^` shuffled across occupied slots within the complex | **geometry necessity** |
| `AS` | `A5` with `C` shuffled across occupied slots within the complex | **chemistry-alignment necessity** |
| `AL` | `A5` with the **correct protein** and a score-blind **wrong ligand** (different CCD hash, exact heavy-atom count — the P1B gate's ligand policy) | **pair specificity vs protein-only** |

`AL` is registered as a **declared diagnostic, not a sixth condition**. Its role
is to separate two claims that the four inherited conditions conflate:

* *partner specificity* — the correct **protein** is required (`AD`);
* *pair specificity* — the particular **ligand** is required (`AL`).

`A5 ≈ AL` would mean the readout is a protein-only pocket-chemistry property
that does not depend on which ligand is bound. That is still a real
protein-specific structural statistic, but it is **not** a pair-local
interaction statistic, and it cannot by itself carry an affinity increment,
which is a property of the pair. Because `AL` can only weaken the reading of a
PASS and never strengthen it, adding it before scoring is a tightening.

`AD` is never called a biological non-binder. Its map is frozen before scoring
and its identities and hash are recorded. `AD` follows the P1B gate's own
control policy verbatim: *different registered homology group, exact
residue-slot count, nearest sequence length*.

### 4.1 Calibration rule (fixed before scoring)

`A5`, `AD`, `AG`, `AS` and `AO` emit `e` on the target's own scale with **zero
fitted parameters**. A diffuse contact posterior shrinks `e` toward zero, which
is a scale property, not an information property. Registered rule:

> Every zero-parameter arm is scored **twice**: `raw` (no fit at all) and
> `affine` (one slope and one intercept, least squares, **fitted on the train
> split only**, applied identically to every zero-parameter arm).

The **primary** figure is `affine`, because the criterion is about information
content and the identical two-parameter map is applied to the deployable arm
and to all of its destructive controls alike, so no arm gains an advantage.
The `raw` figure is reported alongside. If `raw` fails only where `affine`
passes, the verdict is `OBSERVABLE_BUT_UNCALIBRATED`, which is **not** a PASS
and authorises nothing.

## 5. Feasibility criterion — five conditions, all required

On the test split, component bootstrap, for the CORE channel `E_APOLAR`:

```text
(1) R2(A5 vs A0)        >= 0.02,  95% LCB > 0
(2) R2(A5) - R2(A1)     >= 0.02,  95% LCB > 0      ligand shortcut excluded
(3) R2(A5) - R2(AD)     >= 0.02,  95% LCB > 0      partner specific
(4) R2(A5) - R2(AG)     >= 0.02,  95% LCB > 0      geometry necessary
(5) R2(A5) - R2(A2)     >= 0.02,  95% LCB > 0      NEW: pair-local geometry adds
                                                   over protein background alone
```

Condition (5) is **added** by this amendment. It is a tightening: without it a
channel predictable from bulk amino-acid composition would score as pair-local
mechanism. The four inherited thresholds are unchanged at `0.02` with
`LCB > 0`.

Both the per-slot reconstruction and the complex-level scalar must have the
same favourable direction, as required by base §9.

## 6. Terminal verdicts

Unchanged set, plus the tautology outcome:

```text
S5_DATA_OR_MAPPING_CONTRACT_FAIL_CLOSED
S5_TEACHER_OR_SLOT_CONTRACT_DEFECT
S5_HEAD_OR_OPTIMIZATION_NOT_IDENTIFIED
P1B_PAIR_LOCAL_MECHANISM_NOT_OBSERVABLE
P1B_PAIR_LOCAL_STRUCTURAL_MECHANISM_OBSERVED
S5_CHANNEL_TAUTOLOGICAL_WITH_TRAINING_TARGET      (new)
```

## 7. What a PASS does and does not authorise

A PASS establishes **structural observability and partner specificity of a
named pocket-chemistry coordinate**. It does **not** establish affinity
energetics, does not admit `e` into production `z`, does not authorise DAVIS,
ChEMBL/BindingDB affinity training, PLIP, pose-aware data, or any change to the
frozen operator. It authorises exactly one thing: a **separately preregistered**
source-affinity increment experiment, which must still show closure-OOF
`correct - ligand >= 0.03` and `correct - deranged >= 0.03`, both LCB > 0,
before a sealed transfer Gate is even discussed.

Stage order is strict and a PASS advances exactly one step:

```text
structural observability -> partner specificity -> affinity increment
  -> k-shot section identifiability -> biological z admission
```

## 8. Prohibited responses to a FAIL

If any condition fails, the registered response is to localise the failure and
stop. The following are **not** authorised repairs: enlarging ESM, fine-tuning
ESM, deepening the GNN, adding cross-attention, adding a knowledge graph,
adding modalities, lowering any Gate, or re-drawing the split.
