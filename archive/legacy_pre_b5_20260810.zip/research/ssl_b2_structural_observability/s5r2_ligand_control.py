"""S5R-2 arm AL — correct protein, score-blind wrong ligand.

Separates *partner specificity* (the correct protein is needed, arm AD) from
*pair specificity* (the particular ligand is needed, arm AL). Registered as a
declared diagnostic in PREREG_S5R2_POCKET_CHEMISTRY_ENRICHMENT.md §4.

Ligand policy is the P1B gate's own: different CCD hash, exact heavy-atom count.
Nothing is fitted. No affinity value is opened.
"""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

import numpy as np
import torch

ROOT = Path(r"D:\MetaSieve")
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "research" / "ssl_b2_structural_observability"))

from contracts.ligand_graph import ATOM_FEAT_DIM, BOND_FEAT_DIM, MAX_ATOMS  # noqa: E402
from s5r2_build import (CACHE, LIGAND_BANK, OUT, PROTEIN_BANK, RECORDS, S,  # noqa: E402
                        SUPERVISION, ShardCache, build_model, enrichment,
                        read_jsonl, slot_composition)


def build_ligand_derangement(records, seed=20260809):
    """Different CCD hash, exact heavy-atom count, within split."""
    rng = np.random.default_rng(seed)
    n = len(records)
    heavy = np.array([r["ligand_heavy_atoms"] for r in records])
    cch = np.array([r["ccd_sha256"] for r in records])
    splits = np.array([r["source_split"] for r in records])
    partner = np.full(n, -1, dtype=np.int64)
    misses = 0
    for sp in sorted(set(splits.tolist())):
        pool = np.where(splits == sp)[0]
        by_heavy = {}
        for j in pool:
            by_heavy.setdefault(int(heavy[j]), []).append(j)
        for i in pool:
            cands = [j for j in by_heavy.get(int(heavy[i]), []) if cch[j] != cch[i]]
            if not cands:
                misses += 1
                continue
            partner[i] = int(cands[rng.integers(0, len(cands))])
    return partner, misses


def main():
    records = read_jsonl(RECORDS)
    feats = np.load(CACHE / "s5r2_features.npz", allow_pickle=True)
    valid = feats["valid"]
    n = len(records)

    partner, misses = build_ligand_derangement(records)
    rows = [{"i": int(i), "partner": int(partner[i])} for i in range(n)]
    map_sha = hashlib.sha256(json.dumps(rows, separators=(",", ":")).encode()).hexdigest()
    print(f"ligand derangement coverage={(partner >= 0).mean():.4f} "
          f"misses={misses} sha={map_sha[:16]}", flush=True)

    pairs = {r["source_entry_id"]: r for r in read_jsonl(SUPERVISION / "pairs.jsonl")}
    man = json.loads((PROTEIN_BANK / "manifest.json").read_text(encoding="utf-8"))
    protein_dim = int(man["hidden_dim"])
    lookup = {}
    for shard in man["shards"]:
        with np.load(PROTEIN_BANK / shard["path"], allow_pickle=False) as z:
            for row, key in enumerate(z["keys"]):
                lookup[str(key)] = (shard["path"], row)
    ligands = torch.load(LIGAND_BANK, map_location="cpu", weights_only=False)
    device = "cuda" if torch.cuda.is_available() else "cpu"
    model = build_model(protein_dim, device)

    e_lig = np.zeros((n, 20), np.float64)
    ok = np.zeros(n, bool)
    geo, esm = ShardCache(2), ShardCache(4)
    batch = 16
    for start in range(0, n, batch):
        idx = list(range(start, min(start + batch, n)))
        X = torch.zeros(len(idx), MAX_ATOMS, ATOM_FEAT_DIM)
        A = torch.zeros(len(idx), MAX_ATOMS, MAX_ATOMS, BOND_FEAT_DIM)
        am = torch.zeros(len(idx), MAX_ATOMS)
        pooled = np.zeros((len(idx), protein_dim), np.float32)
        resid = np.zeros((len(idx), S, protein_dim), np.float32)
        rm = np.zeros((len(idx), S), np.float32)
        use = []
        for b, i in enumerate(idx):
            rec = records[i]
            pr = pairs[rec["source_entry_id"]]
            g = geo.get(SUPERVISION / pr["shard"], ("residue_mask",))
            rm[b] = g["residue_mask"][pr["shard_index"]].astype(np.float32)
            sp, row = lookup[rec["sequence_sha256"]]
            z = esm.get(PROTEIN_BANK / sp, ("pooled", "residues"))
            pooled[b] = z["pooled"][row].astype(np.float32)
            resid[b] = z["residues"][row].astype(np.float32)
            j = int(partner[i])
            src = records[j] if (j >= 0 and valid[i]) else rec
            gr = ligands[src["ccd_sha256"]]
            X[b] = gr["X"]
            am[b] = gr["mask"]
            e = gr["edge_index"].long()
            A[b, e[0], e[1]] = gr["edge_attr"]
            if j >= 0 and valid[i]:
                use.append(b)

        with torch.inference_mode():
            _, atoms = model.ligand(X.to(device), A.to(device), am.to(device))
            _, residues = model.protein(torch.from_numpy(pooled).to(device),
                                        torch.from_numpy(resid).to(device))
            pred = model.bridge(atoms, am.to(device), residues,
                                torch.from_numpy(rm).to(device))
            pc = pred.contact_prob.float().cpu().numpy()

        for b, i in enumerate(idx):
            if b not in use:
                continue
            occupied = rm[b].astype(bool)
            amb = am[b].numpy().astype(bool)
            C, n_std, _ = slot_composition(records[i]["sequence"])
            w = (pc[b] * amb[:, None]).sum(0).astype(np.float64) * occupied
            r = enrichment(w, C, n_std, occupied)
            if r is None:
                continue
            e_lig[i] = r[0]
            ok[i] = True
        if (start // batch) % 100 == 0:
            print(f"  {min(start + batch, n)}/{n}", flush=True)

    np.savez_compressed(CACHE / "s5r2_ligand_control.npz",
                        e_ligand_deranged=e_lig, lig_valid=ok, partner=partner)
    meta = {"schema": "MetaSieve.S5R2LigandControl.v1",
            "policy": "different CCD hash, exact heavy-atom count, within split",
            "seed": 20260809, "map_sha256": map_sha,
            "coverage": float((partner >= 0).mean()), "valid": int(ok.sum())}
    (OUT / "S5R2_LIGAND_CONTROL_MAP.json").write_text(json.dumps(meta, indent=2),
                                                      encoding="utf-8")
    print(json.dumps(meta, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
