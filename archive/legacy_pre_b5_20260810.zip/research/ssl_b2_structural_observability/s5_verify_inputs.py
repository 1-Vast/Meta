"""S5 Stage 0R — verify every declared SHA-256 in the frozen P1B input chain.

Read-only. Writes report/ssl_s5/S5_INPUT_HASH_VERIFICATION.json.
No affinity value, DAVIS record or recipient label is opened.
"""
from __future__ import annotations

import hashlib
import json
import os
import sys

ROOT = r"D:\MetaSieve"
OPEN = os.path.join(ROOT, "dataset", "processed", "open_structures")
OUT = os.path.join(ROOT, "report", "ssl_s5")


def sha256(path, chunk=1 << 20):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while True:
            b = f.read(chunk)
            if not b:
                break
            h.update(b)
    return h.hexdigest()


def verify_shard_bank(bank_dir, label, results):
    man_path = os.path.join(bank_dir, "manifest.json")
    man = json.load(open(man_path))
    ok = bad = missing = 0
    bad_names = []
    for s in man["shards"]:
        p = os.path.join(bank_dir, s["path"])
        if not os.path.exists(p):
            missing += 1
            bad_names.append(s["path"] + ":MISSING")
            continue
        if sha256(p) == s["sha256"]:
            ok += 1
        else:
            bad += 1
            bad_names.append(s["path"] + ":MISMATCH")
    results[label] = {
        "manifest": os.path.relpath(man_path, ROOT),
        "shards_declared": len(man["shards"]),
        "shards_ok": ok,
        "shards_mismatch": bad,
        "shards_missing": missing,
        "failures": bad_names[:20],
        "verdict": "PASS" if bad == 0 and missing == 0 else "FAIL",
    }
    print(f"{label:34s} {results[label]['verdict']}  ok={ok} bad={bad} missing={missing}")
    return results[label]["verdict"] == "PASS"


def verify_file(path, declared, label, results):
    exists = os.path.exists(path)
    got = sha256(path) if exists else None
    v = "PASS" if got == declared else ("MISSING" if not exists else "FAIL")
    results[label] = {
        "path": os.path.relpath(path, ROOT) if exists else path,
        "declared_sha256": declared,
        "actual_sha256": got,
        "verdict": v,
    }
    print(f"{label:34s} {v}")
    return v == "PASS"


def main():
    os.makedirs(OUT, exist_ok=True)
    results = {}
    allok = True

    allok &= verify_file(
        os.path.join(ROOT, "report", "mechanism_refactor",
                     "p1b_pilot20k_seed17_v1", "best.pt"),
        "90b0010b81fa2758a2dbdd1a8dbe06adae2e05acbbc267ccb62ceee6ff6c4f37",
        "p1b_checkpoint", results)

    allok &= verify_file(
        os.path.join(OPEN, "pilot20k_mechanism_ligands_v1.pt"),
        "823815c2e436d28403b14bc79fa5e86b99b511fdfda50b104995ad64abbe7012",
        "ligand_bank", results)

    # The bank versions below are the ones the P1B checkpoint actually declares.
    # Resolved from bytes in S5_PROVENANCE_CHAIN_RESOLUTION.json; the earlier
    # Stage 0 audit pinned the _v1 banks from prose and was wrong.
    allok &= verify_file(
        os.path.join(OPEN, "pilot20k_homology_split_v2", "complexes.jsonl"),
        "45907b45b590c6ec27242fc07028444133a5f562f79eff9ba5951cb0b09fae1a",
        "p1b_records_homology_split_v2", results)

    allok &= verify_shard_bank(
        os.path.join(OPEN, "pilot20k_structure_supervision_v2"),
        "structure_supervision_shards_v2", results)

    allok &= verify_shard_bank(
        os.path.join(OPEN, "pilot20k_esm2_t30_slots128_v1"),
        "esm2_t30_slot_shards", results)

    # Manifest-level hashes quoted by the P1B run manifest.
    sup_man = os.path.join(OPEN, "pilot20k_structure_supervision_v2", "manifest.json")
    prot_man = os.path.join(OPEN, "pilot20k_esm2_t30_slots128_v1", "manifest.json")
    allok &= verify_file(sup_man,
                         "ad0e4803165cc8be0eacff1a833df4a67861ba231ac1048e42a066d280588fea",
                         "supervision_manifest_v2", results)
    allok &= verify_file(
        os.path.join(OPEN, "pilot20k_holo_governed_v2", "complexes.jsonl"),
        "29d95d8ecc65286f90023a323757bea02ee3a54ed2e2a4a477ad53988920b3fd",
        "governed_complexes_v2", results)
    allok &= verify_file(
        os.path.join(OPEN, "pilot20k_governance_v2", "manifest.json"),
        "d4a1508e288b1c3be8296abf59c3b17c41c63ece916a13c30f9da2e0276dff85",
        "governance_manifest_v2", results)
    allok &= verify_file(prot_man,
                         "dc087bda9679951a4593776a598f006621a686e6cf6204e5c6645851eff72f43",
                         "protein_manifest", results)

    results["overall"] = "PASS" if allok else "FAIL"
    results["schema"] = "MetaSieve.S5InputHashVerification.v1"
    out = os.path.join(OUT, "S5_INPUT_HASH_VERIFICATION.json")
    json.dump(results, open(out, "w"), indent=2)
    print(f"\noverall: {results['overall']}\nwrote {out}")
    return 0 if allok else 1


if __name__ == "__main__":
    sys.exit(main())
