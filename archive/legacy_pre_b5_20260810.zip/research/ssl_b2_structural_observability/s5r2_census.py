"""S5R-2 Stage 1 — mapping, slot-multiplicity and information-ceiling census.

Discharges the `blocked_measurements` list of report/ssl_s5/S5_RESULT.json that
did not require a teacher: sequence-length distribution, realised slot
multiplicity, mixed-residue-class slots, non-standard residue incidence,
mapping-coverage distribution, and the exact-residue -> 128-slot information
loss for the registered coordinate `e`.

The slot-aggregation ceiling is measured on a deterministic sample of complexes
re-parsed from the frozen mmCIF with gemmi, heavy atoms only (Amendment D-1).

Read-only with respect to every frozen surface. No affinity value is opened.
"""
from __future__ import annotations

import gzip
import json
import sys
from pathlib import Path

import numpy as np

ROOT = Path(r"D:\MetaSieve")
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "research" / "ssl_b2_structural_observability"))

from s5r2_build import (AA20, CACHE, OUT, RECORDS, S, SUPERVISION,  # noqa: E402
                        enrichment, read_jsonl, slot_composition)
from s5r2_ladder import SETS, indicator  # noqa: E402

CLASS_OF = {}
for cls, letters in (("apolar", "AVLIMC"), ("aromatic", "FWY"), ("polar", "STNQ"),
                     ("pos", "KRH"), ("neg", "DE"), ("special", "GP")):
    for ch in letters:
        CLASS_OF[ch] = cls


def pct(a, qs=(0, 5, 25, 50, 75, 95, 100)):
    return {f"p{q}": float(np.percentile(a, q)) for q in qs}


def exact_residue_enrichment(record, threshold=6.0):
    """Pocket-chemistry enrichment at EXACT residue resolution, heavy atoms only.

    Returns (e_exact[20], n_pocket_residues) or None. This is the ceiling the
    128-slot representation is compressed from.
    """
    import gemmi
    path = record["structure_path"]
    with gzip.open(path, "rt", encoding="utf-8", errors="ignore") as fh:
        doc = gemmi.cif.read_string(fh.read())
    st = gemmi.make_structure_from_block(doc.sole_block())
    st.setup_entities()
    st.remove_hydrogens()
    st.remove_alternative_conformations()
    model = st[0]

    lig, prot = [], []
    for ch in model:
        for res in ch:
            info = gemmi.find_tabulated_residue(res.name)
            is_aa = info is not None and info.is_amino_acid()
            # gemmi 0.7.x exposes subchain and one_letter_code as properties.
            subchain = getattr(res, "subchain", "")
            in_target_chain = (subchain == record["protein_asym_id"] or
                               ch.name == record["protein_auth_asym_id"])
            if is_aa and in_target_chain:
                one = str(info.one_letter_code).upper()
                coords = np.array([[a.pos.x, a.pos.y, a.pos.z] for a in res
                                   if a.element.name.upper() != "H"], float)
                if len(coords):
                    prot.append((one, coords))
            elif res.name.upper() == record["ligand_comp_id"].upper():
                for a in res:
                    if a.element.name.upper() != "H":
                        lig.append([a.pos.x, a.pos.y, a.pos.z])
    if not lig or len(prot) < 10:
        return None
    L = np.asarray(lig, float)

    counts_q = np.zeros(20)
    counts_b = np.zeros(20)
    n_pocket = 0
    for one, coords in prot:
        j = AA20.find(one) if one in AA20 else -1
        if j < 0:
            continue
        counts_b[j] += 1.0
        d = np.sqrt(((L[:, None, :] - coords[None, :, :]) ** 2).sum(-1)).min()
        if d <= threshold:
            counts_q[j] += 1.0
            n_pocket += 1
    if counts_q.sum() == 0 or counts_b.sum() == 0:
        return None
    return counts_q / counts_q.sum() - counts_b / counts_b.sum(), n_pocket


def main():
    records = read_jsonl(RECORDS)
    f = np.load(CACHE / "s5r2_features.npz", allow_pickle=True)
    valid = f["valid"]
    seq = [r["sequence"] for r in records]
    L = np.array([len(s) for s in seq])
    occ = f["occ"]
    n_std = f["n_std"]

    n_all = np.array([np.bincount(np.minimum(S - 1, np.arange(len(s)) * S // len(s)),
                                  minlength=S) for s in seq])
    mult = n_all.astype(float)
    occupied = occ.astype(bool)

    nonstd = np.array([sum(1 for ch in s if ch not in AA20) for s in seq])
    mixed = 0
    total_occ = 0
    for i, s in enumerate(seq):
        idx = np.minimum(S - 1, np.arange(len(s)) * S // len(s))
        classes = [set() for _ in range(S)]
        for pos, ch in enumerate(s):
            c = CLASS_OF.get(ch)
            if c:
                classes[idx[pos]].add(c)
        for sl in range(S):
            if occupied[i, sl]:
                total_occ += 1
                if len(classes[sl]) >= 2:
                    mixed += 1

    split = f["split"]
    census = {
        "schema": "MetaSieve.S5R2Census.v1",
        "records": len(records),
        "valid_for_e": int(valid.sum()),
        "splits": {s: int((split == s).sum()) for s in ("train", "val", "test")},
        "homology_groups_total": len({r["homology_group_id"] for r in records}),
        "sequence_length": pct(L) | {"mean": float(L.mean()),
                                     "frac_gt_128": float((L > 128).mean()),
                                     "frac_le_128_injective_slots": float((L <= 128).mean())},
        "slot_multiplicity_residues_per_occupied_slot":
            pct(mult[occupied]) | {"mean": float(mult[occupied].mean())},
        "occupied_slots_per_complex": pct(occupied.sum(1).astype(float)),
        "slots_with_zero_standard_residues_total": int(((n_std == 0) & occupied).sum()),
        "mixed_residue_class_occupied_slots": {
            "count": int(mixed), "total_occupied": int(total_occ),
            "fraction": float(mixed / max(total_occ, 1))},
        "nonstandard_residues": {
            "complexes_with_any": int((nonstd > 0).sum()),
            "fraction_of_residues": float(nonstd.sum() / L.sum())},
        "protein_mapping_coverage": pct(np.array(
            [r["protein_mapping_coverage"] for r in records])),
        "ligand_mapping_coverage": pct(np.array(
            [r["ligand_mapping_coverage"] for r in records])),
        "ligand_heavy_atoms": pct(np.array(
            [r["ligand_heavy_atoms"] for r in records], float)),
        "contact_positive_pairs": pct(f["contact_pos"].astype(float)),
        "single_chain_by_construction": (
            "_protein_residue_atoms selects rows with label_asym_id == "
            "protein_asym_id only; the frozen supervision therefore never "
            "contains a second protein chain. Oligomer-interface pockets appear "
            "as unlined pockets and are a label-noise source, not a stratum."),
        "lemma_nonident_applicable_fraction": float((L > 128).mean()),
    }

    # ---- exact-residue vs 128-slot information ceiling, deterministic sample ----
    rng = np.random.default_rng(20260809)
    test_idx = np.where(valid & (split == "test"))[0]
    sample = rng.choice(test_idx, size=min(300, len(test_idx)), replace=False)
    ex, sl, npock = [], [], []
    failures = 0
    failure_reasons = {}
    for i in sample:
        try:
            r = exact_residue_enrichment(records[i])
            if r is None:
                failure_reasons["no_ligand_or_too_few_residues"] = \
                    failure_reasons.get("no_ligand_or_too_few_residues", 0) + 1
        except Exception as exc:
            failure_reasons[type(exc).__name__] = \
                failure_reasons.get(type(exc).__name__, 0) + 1
            r = None
        if r is None:
            failures += 1
            continue
        ex.append(r[0])
        npock.append(r[1])
        sl.append(f["e_true"][i])
    ex, sl = np.asarray(ex), np.asarray(sl)
    ceiling = {"sampled": int(len(sample)), "usable": int(len(ex)),
               "parse_failures": int(failures), "failure_reasons": failure_reasons}
    if len(ex) > 10:
        for name in SETS:
            u = indicator(SETS[name])
            a, b = ex @ u, sl @ u
            ss_res = float(((a - b) ** 2).sum())
            ss_tot = float(((a - a.mean()) ** 2).sum())
            ceiling[name] = {
                "r2_slot_vs_exact": float(1.0 - ss_res / max(ss_tot, 1e-12)),
                "pearson": float(np.corrcoef(a, b)[0, 1]),
                "exact_sd": float(a.std()), "slot_sd": float(b.std()),
            }
        ceiling["pocket_residues"] = pct(np.array(npock, float))
    census["exact_residue_to_slot_ceiling"] = ceiling

    (OUT / "S5R2_CENSUS.json").write_text(json.dumps(census, indent=2), encoding="utf-8")
    print(json.dumps(census, indent=2))
    print(f"\nwrote {OUT / 'S5R2_CENSUS.json'}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
