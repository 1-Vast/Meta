# S7 — exact-residue local mechanism observability on a score-blind panel

> ## ⚠ STAGE-NAMING RECONCILIATION — 2026-08-09
>
> A later instruction designates a single stage,
> `S7_L2B_EXACT_RESIDUE_PLM_LOCALIZER`, and forbids parallel S7 and L2B
> protocols. **This document is therefore placed on hold as
> `SUPERSEDED_BY_STAGE_NAMING`.** It is not deleted; its SHA-256
> (`497ffda5da37c3376f7cffba481f656b9d18e57afa2bf48df045e9950977fb90`) is
> preserved in `project_state.json`.
>
> The two protocols are **different experiments**, not duplicates:
> this one measures exact-residue **pocket composition enrichment** from RCSB
> coordinates on a new score-blind panel; `S7_L2B` measures **residue-atom
> interaction localization AP** against PLIP-derived edge labels.
>
> `S7_L2B` is currently **fail-closed at R0**
> (`FIVE_ARTIFACTS_NOT_MATERIALIZED`) — see
> `report/s7_l2b_exact_residue_plm_localizer/S7L2B_R0_FAIL_CLOSED_REPORT.md`.
> Its corpus, its incumbent `B4` and its PLM weights are all absent.
>
> **If the MONN acquisition is not authorized, this document is the only
> structural stage this repository can actually run**, because its data — the
> 13,885 never-downloaded, never-scored RCSB candidates — is already present and
> already governed. Reactivating it requires an explicit instruction.

Status: **PREREGISTRATION ONLY. NOT AUTHORIZED TO EXECUTE. ON HOLD.**
Registered: 2026-08-09. Supersedes nothing; S5R-2 is closed as
`S5_DATA_OR_PREREGISTRATION_CONTRACT_FAIL_CLOSED`.

Real affinity values, DAVIS/recipient labels, PLIP, pose-aware data, production
`z`, CSMO, Band, positive ridge, simplex, fixed mesh, `K(B(z)F(z))`,
`theory/FINAL_FROZEN_THEORY/`, `model/`, `contracts/` and production `scripts/`
remain frozen and unmodified. S7 is label-free with respect to affinity.

## 0. Chronology contract — binding, and the first lesson of S5R-2

S5R-2's preregistration was never committed, so its chronology was prose rather
than proof, and the whole result is `DEVELOPMENT_EVIDENCE_ONLY` for that reason
alone.

**S7 may not be executed until this file is committed and its SHA-256 recorded
in `project_state.json`.** Any later amendment must be a *new commit*, never an
in-place edit. If a score is produced before that commit exists, the result is
development evidence by construction and must be labelled so.

## 1. The question

> Can an **exact-residue, atom-local** mechanism statistic, computed from
> deployment-observable inputs, recover a correct-protein **and correct-ligand**
> structural signal beyond ligand-only, protein-only, and pocket-composition
> controls?

The estimand is the **exact-residue** quantity. The 128-slot readout is demoted
from target to control arm. This is the direct consequence of the S5R-2 census:
the slot map retains only R² ≈ 0.52 (APOLAR) down to 0.18 (POS) of the
exact-residue quantity, because occupied slots hold 2.46 residues on average and
69.1 % of them are chemically mixed.

## 2. Panel — new, score-blind, disjoint from every prior registry

| Property | Specification |
|---|---|
| Source | RCSB PDB, CC0-1.0, via the existing `s1b_acquire_independent.py` |
| Draw pool | the **13,885** S1b candidate IDs that were never downloaded and never scored |
| Excluded | all 10,468 pilot20k-exposed IDs; all 1,118 S4-scored IDs; the 358 downloaded-but-rejected quarantine |
| Selection | deterministic: sort candidate IDs, seed fixed **in this file before acquisition**, draw without replacement |
| Sealing | PDB IDs, exclusions, protein clusters, scaffolds, file hashes and the split hash are frozen and hashed **before any S7 prediction is scored** |
| Target size | 2,500 acquired, expecting ≈ 1,800 usable after the frozen QC rules |

**Registered seed: `20260810`. Registered draw size: 2,500.**

Acquisition and QC may run before scoring; **scoring may not begin until the
panel manifest hash is committed.**

## 3. Inference units — the second lesson of S5R-2

S5R-2 bootstrapped homology groups and scaffolds *separately* and reported the
wider interval. That is **not** the registered "closure component", and under the
true closure component the result reversed.

**S7 registers, in advance, both of the following, and reports both always:**

1. **Primary — union closure components.** Connected components of the graph
   joining complexes that share a protein homology group (MMseqs2 40 % id /
   80 % cov) **or** a Bemis-Murcko scaffold. This is the conservative unit.
2. **Secondary — two-way (multiway) cluster-robust** intervals over protein
   homology and scaffold simultaneously, in the Cameron-Gelbach-Miller sense.

**Registered feasibility precondition, checked before scoring.** If the largest
union component exceeds **25 %** of the panel, or the panel yields fewer than
**60** union components, the panel is `UNDERPOWERED_BY_CLOSURE_TOPOLOGY` and S7
**fails closed** — the panel is enlarged or re-drawn under a new registered seed,
and no arm is scored on the deficient panel.

This precondition exists precisely because the S5R-2 test split had 54
components with an 89.1 % giant. Reporting a favourable unit after seeing the
topology is forbidden.

Atom-residue pairs, complexes and cells are **never** treated as IID.

## 4. Target — exact-residue, no slot proxy

For each complex, over **exact resolved residues** `r` (heavy atoms only,
Amendment D-1 convention) and ligand heavy atoms `a`:

```text
pocket weight    W(r) = sum_a 1[ d(a,r) <= 6 A ]        (true coordinates)
pocket comp      Q[t] = sum_r W(r) 1[aa(r)=t] / sum_r W(r)
background       B[t] = sum_r 1[aa(r)=t] / sum_r 1
E[t] = Q[t] - B[t]                                       t = 1..20
```

`E` is the exact-residue analogue of S5R-2's `e`, with **no slot map anywhere**.
Its admissibility is identical and is re-verified numerically before scoring:
`sum_t E[t] = 0` exactly (simplex tangent), `E in [-1,1]^20`, rank ≤ 19,
invariant to rotation, translation, atom and residue order, and to sequence
length.

**Registered CORE channel: `E_APOLAR`** over `{A,V,L,I,M,F,W,C}`, fixed here,
before any S7 number exists. Secondary diagnostics: `AROMATIC, DONOR, ACCEPTOR,
POS, NEG` and the full 20-vector. `DONOR` and `NEG` performed better than
`APOLAR` in S5R-2's post-hoc de-proxying; **they are explicitly NOT promoted** —
that was exploratory, and promoting them here would be selection on an observed
score. They remain secondary.

## 5. Arms — full registered ladder

| Arm | Inputs | Role |
|---|---|---|
| `B0` | train mean of `E` | constant / null |
| `B1` | ligand-only (CCD atom composition + frozen pooled GINE) | ligand shortcut |
| `B2` | protein composition only (background `B`) | protein without geometry |
| `B2e` | mean-pooled frozen ESM only | protein without geometry, learned |
| `B3` | historical **128-slot** zero-parameter readout | continuity with S5R-2, now a control |
| `B4` | **exact-residue zero-parameter readout** | the baseline the learner must beat |
| `B5` | **exact-residue localised field** (the learned candidate) | the claim |
| `BD` | deranged protein | partner specificity |
| `BL` | wrong ligand, **matched beyond atom count** (§5.1) | pair specificity |
| `BM` | residue/motif shuffle within complex | chemistry-alignment necessity |
| `BG` | pair/geometry shuffle within complex | geometry necessity |
| `BR` | capacity-matched random features | realisation control |
| `BS` | synthetic trainability control | optimisation control |

### 5.1 Control policies — tightened over S5R-2

**Wrong protein `BD`.** Different registered homology group; **pairwise identity
verified `< 40 %` by explicit alignment**, not inferred from cluster membership;
exact residue count matched; nearest sequence length; within split; **no partner
reused more than 5 times**; map frozen and hashed before scoring; coverage
≥ 0.99 required.

**Wrong ligand `BL`.** Different CCD identity **and** different Bemis-Murcko
scaffold — S5R-2's policy allowed scaffold-identical "wrong" ligands in 15.6 % of
pairs, which is a materially weak control. Additionally: heavy-atom count matched
within ±2, **no partner reused more than 5 times**, map frozen and hashed,
coverage ≥ 0.99.

**Row masking.** Every arm is evaluated on the **intersection** of all arm
validity masks. S5R-2 failed to intersect the ligand-control mask and admitted 67
zero vectors into an arm. The intersected row set and its hash are recorded
before scoring.

### 5.2 Persistence contract

Before any metric is reported, the following are written to disk and hashed:
per-complex per-arm predictions; per-unit SSE; the exact-residue target vectors;
the sampled row indices; the union-component assignment. S5R-2's exact-residue
result is not reproducible from retained artifacts, and that must not recur.

## 6. Feasibility criterion — all six required, CORE channel

On the sealed panel, union-closure-component bootstrap, `E_APOLAR`:

```text
(1) R2(B5 vs B0)        >= 0.02,  95% LCB > 0
(2) R2(B5) - R2(B1)     >= 0.02,  95% LCB > 0     ligand shortcut excluded
(3) R2(B5) - R2(B2)     >= 0.02,  95% LCB > 0     beyond bulk composition
(4) R2(B5) - R2(BD)     >= 0.02,  95% LCB > 0     partner specific
(5) R2(B5) - R2(BL)     >= 0.02,  95% LCB > 0     PAIR specific  [NEW, decisive]
(6) R2(B5) - R2(B4)     >= 0.02,  95% LCB > 0     the learner earns its parameters
```

Conditions (5) and (6) are new and are the point of S7. S5R-2 could not claim
pair specificity as a *condition*, and never required a learned module to beat
the zero-parameter estimator. Thresholds are unchanged at 0.02 with LCB > 0;
nothing is relaxed.

`BM`, `BG`, `BR` must all collapse toward zero; any of them exceeding
`R2 = 0.02` is `S7_CONTROL_CONTAMINATION_FAIL_CLOSED`.

## 7. Self-supervised channel requirements

A named channel may enter S7 only with **all** of:

1. a deterministic or externally governed structural teacher;
2. an explicit atom/residue chemistry mask;
3. a written mathematical definition;
4. permutation invariance (verified to 1e-9);
5. boundedness (stated and verified);
6. a deployment-observability statement;
7. correct-protein **and** correct-ligand controls;
8. a destructive channel-specific control.

**Registered limitation, stated up front.** Deployment inputs carry **no
orientation, no protonation, no solvent and no pose**. Therefore directional
hydrogen bonding and aromatic orientation remain `NOT_REPRESENTABLE` (finding
M-7) and may not be core channels. Every quantity S7 computes is a **geometric
and chemical compatibility score**. It is **not** a physical energy and must
never be described as one.

## 8. The learned localiser — burden of proof

`B5` must beat `B4` (condition 6), and must additionally beat `B1`, `B2`, `BD`,
`BL` and `BM`. Receiving gradients is not evidence. Required report, per branch:
gradient norms, parameter movement, activation variance, branch ablation,
gradient blocking, shuffle damage, train/held-out gap, and **incremental
held-out value over `B4`**.

**A module that participates in training but adds no held-out value over `B4` is
rejected and removed.** S5R-2's head satisfied participation and added nothing;
that must be a rejection, not a footnote.

Every head run is executed at the **registered scale only**. Smoke tests must
write to a `_SMOKE` filename and may never overwrite a registered artifact —
this is the direct fix for the S5R-2 smoke-test contamination.

## 9. LSMF — evaluated as a hypothesis, not adopted

`s_cij = u_c(h_i)^T v_c(e_j) + q_c(h_i, e_j)` with sparse local aggregation may
be tested **as one candidate for `B5`**, subject to §7 and §8, and only after a
simpler local statistic has been tried first. Registered watch-list, each
reported: channel rotation / label swapping; protein-family motif shortcuts;
sequence-length effects; ligand-only recovery; log-sum-exp collapsing onto common
motifs; support rank below channel dimension; assay or context leakage; giant
component pseudoreplication.

**The number of channels may not be chosen to equal `k`.** It must be justified
by observed structural rank and support-design rank. The external four-channel
LSMF proposal is `HYPOTHESIS_ONLY`; the U0-U3 result said to motivate it is
`NOT_REPRODUCED` and may not be cited as motivation.

## 10. Mathematical compatibility with the frozen theory

| Requirement | How S7 satisfies it |
|---|---|
| Biological statistic `z` | `E` is a candidate **coordinate of** `z`. S7 does not admit it. |
| Boundedness | `E in [-1,1]^20` unconditionally; no clipping, no learned scale |
| Gauge invariance | `sum_t E[t] = 0` exactly; `E` is a tangent vector to the 20-simplex, so the uniform-composition gauge is quotiented by construction, not penalised |
| Rank constraint | admissible space has rank ≤ 19; named projections give a ≤ 6-dim interpretable basis |
| Support-identifiable sections | any later adaptation is confined to the centred support-design row space with `rank(adaptation) <= rank(centred support design) <= k - 1` |
| Abstention | queries outside the retained row space are abstained on, with rank, singular values, conditioning and coverage reported |
| Operator | `K(B(z)F(z))` is **unchanged**. S7 touches no operator, no CSMO, no Band, no mesh, no ridge, no simplex |

S7 makes **no** claim that the frozen point-valued regression theorem certifies
structural reconstruction or affinity ranking.

## 11. Terminal verdicts

```text
S7_PANEL_OR_CLOSURE_TOPOLOGY_FAIL_CLOSED
S7_DATA_OR_MAPPING_CONTRACT_FAIL_CLOSED
S7_CONTROL_CONTAMINATION_FAIL_CLOSED
S7_HEAD_OR_OPTIMIZATION_NOT_IDENTIFIED
EXACT_RESIDUE_LOCAL_MECHANISM_NOT_OBSERVABLE
EXACT_RESIDUE_PAIR_MECHANISM_OBSERVED
```

Only the last authorises anything, and it authorises exactly one thing: a
**separately preregistered** source-affinity Gate, which must still show
closure-OOF `correct − ligand ≥ 0.03` and `correct − deranged ≥ 0.03` with
positive lower bounds, on endpoint-specific Ki/Kd semantics, with
homology/document/ligand closure and component-balanced inference, before a
sealed transfer Gate is discussed. **Deranged proteins are never trained on as
negative binders.** If the population Gate fails, work stops; meta-learning does
not open.

## 12. Forbidden responses to an S7 failure

Enlarging ESM; fine-tuning ESM; deepening the GNN; generic cross-attention;
knowledge graphs; multimodal fusion; lowering any Gate; re-drawing the panel
after seeing scores; promoting a secondary channel post hoc; reporting a
favourable inference unit after inspecting the closure topology.
