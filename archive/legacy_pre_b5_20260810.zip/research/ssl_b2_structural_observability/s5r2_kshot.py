"""S5R-2 support-section identifiability probe — STRUCTURAL DRY RUN ONLY.

This is **not** a stage advance. The registered stage order is

    structural observability -> partner specificity -> affinity increment
      -> k-shot section identifiability -> biological z admission

and this script sits at stage 1-2. It exercises the k<=5 section machinery on
the *structural* channel so the rank / conditioning / coverage / abstention
accounting is built and audited before any affinity value is ever read. It makes
no affinity claim and authorises nothing.

Adapted object: the coefficient vector on **named mechanism channels**
(apolar / aromatic / donor / acceptor / positive / negative pocket enrichment),
never a latent embedding. The task update is confined to the *numerically*
identifiable row space of the k-shot support design, so the adaptive dimension
never exceeds the support rank actually present in the data.

Two guards, both reported:
  * rank truncation  — singular directions with sigma_i/sigma_1 < RANK_REL are
    dropped, so the adaptive dimension is the numerical rank, not k;
  * query coverage   — a query whose standardised channel direction lies outside
    the retained row space by more than 1 - COVERAGE_TAU is **abstained** on.

Coverage is computed on the standardised channel block only. The intercept is
excluded: it is a constant column of ones whose norm dominates every raw design,
which would make any coverage rule vacuously satisfied.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

ROOT = Path(r"D:\MetaSieve")
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "research" / "ssl_b2_structural_observability"))

from s5r2_build import CACHE, OUT  # noqa: E402
from s5r2_ladder import SETS, indicator  # noqa: E402

CHANNELS = list(SETS)
COVERAGE_TAU = 0.90
RANK_REL = 0.10          # keep sigma_i >= 10% of sigma_1
RIDGE = 1e-3


def channel_block(e_pred):
    return np.column_stack([e_pred @ indicator(SETS[n]) for n in CHANNELS])


def main():
    with np.load(CACHE / "s5r2_features.npz", allow_pickle=True) as z:
        f = {k: z[k] for k in z.files}
    with np.load(CACHE / "s5r2_controls.npz", allow_pickle=True) as z:
        der_valid = z["der_valid"]

    valid = f["valid"] & der_valid
    split, group = f["split"], f["group"]
    tr = np.where(valid & (split == "train"))[0]
    te = np.where(valid & (split == "test"))[0]

    Z = channel_block(f["e_pred"])
    mu, sd = Z[tr].mean(0), Z[tr].std(0) + 1e-12
    Z = (Z - mu) / sd                                    # standardised channels
    Phi = np.column_stack([np.ones(len(Z)), Z])          # intercept + channels
    y = f["e_true"] @ indicator(SETS["APOLAR"])

    A = Phi[tr]
    beta0 = np.linalg.solve(A.T @ A + 1e-6 * np.eye(A.shape[1]), A.T @ y[tr])

    tasks = {}
    for i in te:
        tasks.setdefault(str(group[i]), []).append(int(i))

    report = {"schema": "MetaSieve.S5R2SectionProbe.v2",
              "status": "STRUCTURAL_DRY_RUN_NOT_A_STAGE_ADVANCE",
              "adapted_object": "coefficients on named mechanism channels "
                                "(apolar, aromatic, donor, acceptor, pos, neg)",
              "channel_dim": len(CHANNELS), "coverage_tau": COVERAGE_TAU,
              "rank_relative_tolerance": RANK_REL, "ridge": RIDGE,
              "coverage_excludes_intercept": True,
              "global_beta": {n: float(v) for n, v in
                              zip(["intercept"] + CHANNELS, beta0)},
              "k": {}}

    rng = np.random.default_rng(20260809)
    for k in (1, 2, 3, 5):
        ranks, conds, covs = [], [], []
        sse_global = sse_adapt = sse_mean = 0.0
        n_query = n_abstain = 0
        tasks_used = 0
        for _g, idxs in tasks.items():
            if len(idxs) < k + 3:
                continue
            tasks_used += 1
            for _rep in range(10):
                perm = rng.permutation(idxs)
                sup, qry = perm[:k], perm[k:]
                Zs, Zq = Z[sup], Z[qry]
                # centre the support channel block so the section is about
                # *direction*, not about the task's mean level
                U, S, Vt = np.linalg.svd(Zs, full_matrices=False)
                if S.size == 0 or S[0] <= 0:
                    continue
                keep = S >= RANK_REL * S[0]
                r = int(keep.sum())
                ranks.append(r)
                conds.append(float(S[keep][0] / S[keep][-1]) if r else np.inf)
                Vr = Vt[:r]
                P = Vr.T @ Vr
                nrm = np.linalg.norm(Zq, axis=1) + 1e-12
                cov = np.linalg.norm(Zq @ P, axis=1) / nrm
                covs.extend(cov.tolist())
                covered = cov >= COVERAGE_TAU
                n_abstain += int((~covered).sum())
                if not covered.any():
                    continue
                # least-norm task update inside the retained row space only
                resid_s = y[sup] - Phi[sup] @ beta0
                Sr = S[keep]
                coef = (U[:, :r].T @ resid_s) * Sr / (Sr ** 2 + RIDGE)
                delta_z = Vr.T @ coef
                q = qry[covered]
                pg = Phi[q] @ beta0
                pa = pg + Z[q] @ delta_z
                sse_global += float(((y[q] - pg) ** 2).sum())
                sse_adapt += float(((y[q] - pa) ** 2).sum())
                sse_mean += float(((y[q] - y[tr].mean()) ** 2).sum())
                n_query += len(q)

        if n_query == 0:
            report["k"][str(k)] = {"tasks": tasks_used, "answered": 0,
                                   "abstained": int(n_abstain),
                                   "note": "no query met the coverage rule"}
            print(f"k={k}: all queries abstained ({n_abstain})")
            continue
        entry = {
            "tasks": tasks_used,
            "support_rank_mean": float(np.mean(ranks)),
            "support_rank_max_possible": int(min(k, len(CHANNELS))),
            "condition_number_median": float(np.median(conds)),
            "condition_number_p95": float(np.percentile(conds, 95)),
            "query_coverage_median": float(np.median(covs)),
            "query_coverage_p05": float(np.percentile(covs, 5)),
            "answered": int(n_query), "abstained": int(n_abstain),
            "abstention_rate": float(n_abstain / max(n_abstain + n_query, 1)),
            "r2_global_vs_mean": float(1 - sse_global / max(sse_mean, 1e-12)),
            "r2_adapted_vs_mean": float(1 - sse_adapt / max(sse_mean, 1e-12)),
            "adaptation_gain": float((sse_global - sse_adapt) / max(sse_mean, 1e-12)),
        }
        report["k"][str(k)] = entry
        print(f"k={k}: tasks={entry['tasks']} rank={entry['support_rank_mean']:.2f}"
              f"/{entry['support_rank_max_possible']}"
              f" cond_med={entry['condition_number_median']:.3g}"
              f" cov_med={entry['query_coverage_median']:.3f}"
              f" answered={entry['answered']} abstain={entry['abstention_rate']:.3f}"
              f" R2_global={entry['r2_global_vs_mean']:+.4f}"
              f" R2_adapted={entry['r2_adapted_vs_mean']:+.4f}"
              f" gain={entry['adaptation_gain']:+.4f}")

    gains = [v.get("adaptation_gain") for v in report["k"].values()
             if v.get("adaptation_gain") is not None]
    if not gains or max(gains) <= 0:
        verdict = "SECTION_NOT_IDENTIFIED_AT_K_LE_5_ON_STRUCTURAL_CHANNEL"
    elif min(gains) > 0 and max(gains) >= 0.05:
        verdict = "SECTION_ADAPTATION_POSITIVE_ON_STRUCTURAL_CHANNEL"
    else:
        verdict = "SECTION_ADAPTATION_WEAK_AND_NON_MONOTONE_ON_STRUCTURAL_CHANNEL"
    report["verdict"] = verdict
    report["adaptation_gain_by_k"] = {k: v.get("adaptation_gain")
                                      for k, v in report["k"].items()}
    report["interpretation"] = (
        "The quantity that matters here is not the headline gain but the "
        "numerical support rank: it saturates well below k, so a k-shot support "
        "set does not identify k independent directions of the named-channel "
        "coefficient. Adaptation gains are small and change sign with k, so no "
        "consistent task-specific direction is demonstrated. The global meta "
        "coefficient is the safe estimator. This is a statement about the "
        "STRUCTURAL channel only and carries no affinity implication.")
    (OUT / "S5R2_SECTION_PROBE.json").write_text(json.dumps(report, indent=2),
                                                 encoding="utf-8")
    print(f"\nverdict: {report['verdict']}")
    print(f"wrote {OUT / 'S5R2_SECTION_PROBE.json'}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
