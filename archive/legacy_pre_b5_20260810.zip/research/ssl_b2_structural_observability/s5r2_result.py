"""S5R-2 — assemble the consolidated machine-readable result."""
from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(r"D:\MetaSieve")
OUT = ROOT / "report" / "ssl_s5"


def load(name):
    p = OUT / name
    return json.loads(p.read_text(encoding="utf-8")) if p.is_file() else None


def main():
    ladder = load("S5R2_LADDER.json")
    exact = load("S5R2_EXACT_RESIDUE_EVAL.json")
    census = load("S5R2_CENSUS.json")
    probe = load("S5R2_SECTION_PROBE.json")
    hs, hsn = load("S5R2_HEAD_SYNTHETIC.json"), load("S5R2_HEAD_SYNTHETIC_NORM.json")
    hr, hrn = load("S5R2_HEAD_REAL.json"), load("S5R2_HEAD_REAL_NORM.json")
    hashes = load("S5R2_INPUT_HASH_VERIFICATION.json") or load(
        "S5_INPUT_HASH_VERIFICATION.json")
    chain = load("S5_PROVENANCE_CHAIN_RESOLUTION.json")
    ctrl, ligctrl = load("S5R2_CONTROL_MAP.json"), load("S5R2_LIGAND_CONTROL_MAP.json")
    build = load("S5R2_BUILD_MANIFEST.json")

    core = ladder["channels"][ladder["core_channel"]]
    res = {
        "schema": "MetaSieve.S5R2Result.v1",
        "created_utc": "2026-08-09",
        "stage": "P1R2B-S5R2_POCKET_CHEMISTRY_ENRICHMENT",
        "preregistration": "research/ssl_b2_structural_observability/"
                           "PREREG_S5R2_POCKET_CHEMISTRY_ENRICHMENT.md",

        "terminal_verdict": "P1B_PAIR_LOCAL_STRUCTURAL_MECHANISM_OBSERVED",
        "terminal_verdict_qualifications": [
            "condition 2 (margin over ligand-only) passes on the registered "
            "128-slot target and does NOT survive de-proxying to exact residues: "
            "+0.078 [-0.003, +0.152]",
            "per-slot localisation is weak: +0.085 [-0.004, +0.174]",
            "pair specificity (wrong-ligand control) is real but small: "
            "+0.114 [+0.064, +0.165] on the exact-residue target",
        ],
        "stage_ladder_state": {
            "structural_observability": "ESTABLISHED",
            "partner_specificity_protein": "ESTABLISHED",
            "pair_specificity_ligand": "WEAK_NON_ZERO",
            "affinity_increment": "NOT_TESTED_FROZEN",
            "k_shot_section_identifiability": "NOT_IDENTIFIED_STRUCTURAL_DRY_RUN",
            "biological_z_admission": "NOT_AUTHORISED",
        },

        "stage0": {
            "environment": "conda drug; python 3.11.15; torch 2.6.0+cu124; "
                           "CUDA 12.4; RTX 4060 Laptop 8GB",
            "artifact_recovery": "s2_teacher.py and s3s4_observability.py restored "
                                 "from 608decf and verified BYTECODE_IDENTICAL to "
                                 "the surviving __pycache__ (not decompiled)",
            "s4_exposure_registry_recovered": True,
            "regression_suite": "75 passed",
            "hash_verification": hashes,
            "provenance_chain": chain,
            "prior_audit_correction": "the P1B checkpoint's declared inputs resolve "
                                      "to the _v2 supervision/split banks, not _v1",
        },

        "preconditions": {
            "contact_equals_bin_le_1_pairs_checked":
                build["contact_precondition_pairs_checked"] if build else None,
            "contact_precondition_violations":
                build["contact_precondition_violations"] if build else None,
            "gauge_max_abs_sum_e": 1.769e-16,
            "bound_max_abs_e": 0.5656,
            "effective_rank_of_e": 19,
        },

        "census": census,
        "ladder": ladder,
        "exact_residue_evaluation": exact,
        "section_probe": probe,
        "control_maps": {"protein_derangement": ctrl, "ligand_derangement": ligctrl},

        "module_participation": {
            "stage4_synthetic_unnormalised": {
                "loss": [hs["loss_untrained"], hs["loss_trained"]] if hs else None,
                "module_verdict": hs["module_verdict"] if hs else None},
            "stage4_synthetic_normalised": {
                "loss": [hsn["loss_untrained"], hsn["loss_trained"]] if hsn else None,
                "module_verdict": hsn["module_verdict"] if hsn else None},
            "stage5_real_unnormalised": {
                "loss": [hr["loss_untrained"], hr["loss_trained"]] if hr else None,
                "module_verdict": hr["module_verdict"] if hr else None},
            "stage5_real_normalised": {
                "loss": [hrn["loss_untrained"], hrn["loss_trained"]] if hrn else None,
                "module_verdict": hrn["module_verdict"] if hrn else None},
            "trained_head_vs_zero_parameter":
                hrn["aggregate_vs_zero_parameter"] if hrn else None,
            "conclusion": "the 1.73M-parameter learned pair map is worse than the "
                          "zero-parameter deterministic readout on every channel "
                          "at the justified budget; minimum complexity wins",
        },

        "registered_hypotheses": {
            "H-DILUTION": {
                "status": "REFUTED",
                "measurement": "A5 - A5e = -0.0075 [-0.0452, +0.0408]",
                "consequence": "the ESM slot mean is not the binding constraint; "
                               "larger ESM / fine-tuning / deeper GNN / "
                               "cross-attention remain unauthorised, now with a "
                               "measured reason",
            },
            "T-RULE": {
                "status": "APPLIED_AND_LOAD_BEARING",
                "measurement": "K1 pocket coverage R2 = +0.3903, excluded as "
                               "TAUTOLOGICAL_WITH_P1B_TRAINING_TARGET",
            },
        },

        "feasibility_criterion": ladder["feasibility_criterion"],
        "core_channel_pass": ladder["core_channel_pass"],

        "label_audit": {
            "recipient_label_reads": 0, "davis_label_reads": 0,
            "chembl_affinity_value_reads": 0, "bindingdb_affinity_value_reads": 0,
            "plip_label_reads": 0, "pose_aware_data_reads": 0,
            "label_firewall": "INTACT",
        },
        "frozen_surfaces_unmodified": {
            "theory_final_frozen_theory": True, "model_directory": True,
            "contracts": True, "production_scripts": True, "csmo": True,
            "band": True, "positive_ridge": True, "simplex": True,
            "fixed_mesh": True, "K_of_B_z_F_z": True, "production_z": True,
        },
        "authorises": [
            "exactly one separately preregistered source-affinity increment "
            "experiment, whose estimand should be the exact-residue quantity and "
            "whose primary reported number should be the increment over "
            "ligand-only",
        ],
        "does_not_authorise": [
            "admission of e into production z", "DAVIS or recipient labels",
            "ChEMBL/BindingDB affinity training", "PLIP or pose-aware data",
            "any change to K(B(z)F(z)), CSMO, Band, ridge, simplex or mesh",
            "P2-P4", "larger ESM, ESM fine-tuning, deeper GNN, cross-attention, "
            "knowledge graph, multimodal fusion", "relaxing any Gate threshold",
        ],
    }
    dest = OUT / "S5R2_RESULT.json"
    dest.write_text(json.dumps(res, indent=2), encoding="utf-8")
    print(f"wrote {dest} ({dest.stat().st_size} bytes)")


if __name__ == "__main__":
    main()
