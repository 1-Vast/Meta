"""S5R-2 Stage 3 — the zero-training observability ladder for the pocket
chemistry enrichment coordinate `e`.

Registered by PREREG_S5R2_POCKET_CHEMISTRY_ENRICHMENT.md §4-§5.
Fitted arms are fitted on the P1B *train* split only; every number reported is
computed on the P1B *test* split, which the checkpoint never trained on.
Inference units are protein homology groups and Bemis-Murcko scaffolds; the
reported interval is the wider of the two.

Each fitted arm is fitted once against the whole 20-vector `e`; because ridge is
linear, the named channel projections <e,u> are then exact and share one
group-safe lambda, which removes per-channel hyperparameter freedom.

No affinity value, DAVIS record, recipient label or pose-aware datum is opened.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

ROOT = Path(r"D:\MetaSieve")
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "research" / "ssl_b2_structural_observability"))
sys.path.insert(0, str(ROOT / "research" / "crossed_panel_deployability"))

from s5r2_build import CACHE, OUT, enrichment  # noqa: E402
from xp2_core import r2_vs_base, ridge_cv, widest  # noqa: E402

AA20 = "ACDEFGHIKLMNPQRSTVWY"
SETS = {
    "APOLAR": "AVLIMFWC",
    "AROMATIC": "FWYH",
    "DONOR": "STNQYWKRH",
    "ACCEPTOR": "STNQYDEH",
    "POS": "KRH",
    "NEG": "DE",
}
CORE = "APOLAR"
N_BOOT = 5000


def indicator(letters):
    v = np.zeros(20)
    for ch in letters:
        v[AA20.index(ch)] = 1.0
    return v


def unit_sse(err2, units):
    out = {}
    for u in np.unique(units):
        m = units == u
        out[str(u)] = (float(err2[m].sum()), int(m.sum()))
    return out


def r2_gap(a_units, b_units, base_units, n_boot=N_BOOT, seed=0):
    """(SSE_b - SSE_a) / SSE_base — the R2 advantage of arm a over arm b."""
    u = sorted(set(a_units) & set(b_units) & set(base_units))
    sa = np.array([a_units[k][0] for k in u])
    sb = np.array([b_units[k][0] for k in u])
    s0 = np.array([base_units[k][0] for k in u])
    rng = np.random.default_rng(seed)
    idx = rng.integers(0, len(u), (n_boot, len(u)))
    bs = (sb[idx].sum(1) - sa[idx].sum(1)) / np.maximum(s0[idx].sum(1), 1e-12)
    return {"point": float((sb.sum() - sa.sum()) / max(s0.sum(), 1e-12)),
            "ci95": [float(np.percentile(bs, 2.5)), float(np.percentile(bs, 97.5))],
            "units": len(u)}


def shuffle_enrichment(w, comp, n_std, occ, seed, what):
    """Within-complex destructive controls AG (geometry) and AS (chemistry)."""
    rng = np.random.default_rng(seed)
    n = len(w)
    e = np.zeros((n, 20))
    ok = np.zeros(n, bool)
    for i in range(n):
        occupied = occ[i].astype(bool)
        where = np.where(occupied)[0]
        if len(where) < 2:
            continue
        perm = rng.permutation(where)
        wi = w[i].astype(np.float64).copy()
        Ci = comp[i].astype(np.float64).copy()
        if what == "geometry":
            wi[where] = wi[perm]
        elif what == "chemistry":
            Ci[where] = Ci[perm]
        else:
            raise ValueError(what)
        r = enrichment(wi, Ci, n_std[i].astype(np.float64), occupied)
        if r is None:
            continue
        e[i], ok[i] = r[0], True
    return e, ok


def affine(pred_tr, y_tr, pred_te):
    A = np.column_stack([pred_tr, np.ones_like(pred_tr)])
    coef, *_ = np.linalg.lstsq(A, y_tr, rcond=None)
    return pred_te * coef[0] + coef[1], {"slope": float(coef[0]),
                                         "intercept": float(coef[1])}


def per_slot_reconstruction(occ, comp, w_true, e_source_w, te, group):
    """Pair-local check: apolar burial density per occupied slot.

    a(s) = w(s) * <C[s], u_APOLAR>, normalised within complex. Baseline is the
    within-complex mean, so any arm must explain *where* the apolar burial sits.
    """
    u = indicator(SETS["APOLAR"])
    out = {}
    for name, W in e_source_w.items():
        num = den = 0.0
        per_unit = {}
        for i in te:
            occupied = occ[i].astype(bool)
            if occupied.sum() < 3:
                continue
            C = comp[i].astype(np.float64)[occupied] @ u
            at = w_true[i].astype(np.float64)[occupied] * C
            ap = W[i].astype(np.float64)[occupied] * C
            if at.std() < 1e-12:
                continue
            at = (at - at.mean()) / (at.std() + 1e-12)
            ap = (ap - ap.mean()) / (ap.std() + 1e-12)
            sse = float(((at - ap) ** 2).sum())
            sst = float((at ** 2).sum())
            num += sse
            den += sst
            g = str(group[i])
            s, t = per_unit.get(g, (0.0, 0.0))
            per_unit[g] = (s + sse, t + sst)
        keys = sorted(per_unit)
        sa = np.array([per_unit[k][0] for k in keys])
        sb = np.array([per_unit[k][1] for k in keys])
        rng = np.random.default_rng(7)
        idx = rng.integers(0, len(keys), (2000, len(keys)))
        bs = 1.0 - sa[idx].sum(1) / np.maximum(sb[idx].sum(1), 1e-12)
        out[name] = {"r2_within_complex": float(1.0 - num / max(den, 1e-12)),
                     "ci95": [float(np.percentile(bs, 2.5)),
                              float(np.percentile(bs, 97.5))],
                     "units": len(keys)}
    return out


def main():
    # NpzFile decompresses on every key access; materialise once.
    with np.load(CACHE / "s5r2_features.npz", allow_pickle=True) as z:
        f = {k: z[k] for k in z.files}
    with np.load(CACHE / "s5r2_controls.npz", allow_pickle=True) as z:
        c = {k: z[k] for k in z.files}

    valid = f["valid"] & c["der_valid"]
    split = f["split"]
    tr = np.where(valid & (split == "train"))[0]
    te = np.where(valid & (split == "test"))[0]
    group, scaf = f["group"], f["scaffold"]
    print(f"train={len(tr)}  test={len(te)}  "
          f"test homology groups={len(set(group[te].tolist()))}  "
          f"test scaffolds={len(set(scaf[te].tolist()))}", flush=True)

    print("building destructive shuffles ...", flush=True)
    e_gshuf, _ = shuffle_enrichment(f["w_pred"], f["comp"], f["n_std"], f["occ"],
                                    11, "geometry")
    e_cshuf, _ = shuffle_enrichment(f["w_pred"], f["comp"], f["n_std"], f["occ"],
                                    12, "chemistry")
    w_gshuf = np.zeros_like(f["w_pred"])
    rng_g = np.random.default_rng(11)
    for i in range(len(w_gshuf)):
        occupied = f["occ"][i].astype(bool)
        where = np.where(occupied)[0]
        w_gshuf[i] = f["w_pred"][i]
        if len(where) >= 2:
            w_gshuf[i, where] = f["w_pred"][i][rng_g.permutation(where)]

    LIG = np.hstack([f["lig_pooled"], f["lig_elem"]])
    BG = f["bg"]
    E = f["e_true"]
    rng = np.random.default_rng(20260809)
    FEATURES = {
        "A1": LIG,
        "A2": BG,
        "A2e": f["esm_mean"],
        "A3": np.hstack([LIG, BG]),
        "A5e": c["esm_pocket"],
    }
    FEATURES["AR"] = rng.normal(size=FEATURES["A3"].shape)

    print("fitting arms (one fit per arm against the full 20-vector) ...", flush=True)
    E_hat, lam_used = {}, {}
    for arm, X in FEATURES.items():
        pred, lam = ridge_cv(X[tr], E[tr], X[te], group[tr])
        E_hat[arm] = pred
        lam_used[arm] = float(lam)
        print(f"  {arm:5s} lambda={lam:g}", flush=True)

    ZERO = {"A5": f["e_pred"], "AO": f["e_true"], "AD": c["e_deranged"],
            "AG": e_gshuf, "AS": e_cshuf}
    lig_path = CACHE / "s5r2_ligand_control.npz"
    if lig_path.exists():
        with np.load(lig_path, allow_pickle=True) as z:
            ZERO["AL"] = z["e_ligand_deranged"]
            print(f"arm AL (wrong ligand, correct protein) present: "
                  f"{int(z['lig_valid'].sum())} valid")

    results = {"schema": "MetaSieve.S5R2Ladder.v1", "n_boot": N_BOOT,
               "train_records": int(len(tr)), "test_records": int(len(te)),
               "test_homology_groups": len(set(group[te].tolist())),
               "test_scaffolds": len(set(scaf[te].tolist())),
               "core_channel": CORE, "lambda": lam_used, "channels": {}}

    for name, letters in SETS.items():
        u = indicator(letters)
        y = E @ u
        preds = {"A0": np.full(len(te), y[tr].mean())}
        for arm in FEATURES:
            preds[arm] = E_hat[arm] @ u
        calib = {}
        for arm, vec in ZERO.items():
            v = vec @ u
            preds[arm + "_raw"] = v[te]
            preds[arm], calib[arm] = affine(v[tr], y[tr], v[te])

        sse_g = {a: unit_sse((y[te] - p) ** 2, group[te]) for a, p in preds.items()}
        sse_s = {a: unit_sse((y[te] - p) ** 2, scaf[te]) for a, p in preds.items()}

        ch = {"target_sd_test": float(y[te].std()), "affine": calib,
              "r2_vs_mean": {}, "gaps": {}}
        for a in preds:
            if a == "A0":
                continue
            ch["r2_vs_mean"][a] = widest(
                r2_vs_base(sse_g[a], sse_g["A0"], N_BOOT, 101),
                r2_vs_base(sse_s[a], sse_s["A0"], N_BOOT, 102))
        for label, other in (("vs_ligand_only_A1", "A1"),
                             ("vs_deranged_AD", "AD"),
                             ("vs_geometry_shuffle_AG", "AG"),
                             ("vs_background_A2", "A2"),
                             ("vs_chemistry_shuffle_AS", "AS"),
                             ("vs_random_AR", "AR"),
                             ("vs_esm_mean_A2e", "A2e"),
                             ("vs_pocket_esm_A5e", "A5e"),
                             ("vs_ligand_deranged_AL", "AL")):
            if other not in preds:
                continue
            ch["gaps"][label] = widest(
                r2_gap(sse_g["A5"], sse_g[other], sse_g["A0"], N_BOOT, 201),
                r2_gap(sse_s["A5"], sse_s[other], sse_s["A0"], N_BOOT, 202))
        results["channels"][name] = ch

        print(f"\n=== {name}{'  [CORE]' if name == CORE else ''} "
              f"(target sd={y[te].std():.4f}) ===")
        for a in ("A1", "A2", "A2e", "A3", "A5e", "AR",
                  "A5", "A5_raw", "AD", "AL", "AG", "AS", "AO"):
            if a not in ch["r2_vs_mean"]:
                continue
            r = ch["r2_vs_mean"][a]
            print(f"  R2 {a:8s} {r['point']:+.4f} [{r['ci95'][0]:+.4f},{r['ci95'][1]:+.4f}]")
        for label, g in ch["gaps"].items():
            print(f"  gap A5 {label:26s} {g['point']:+.4f} "
                  f"[{g['ci95'][0]:+.4f},{g['ci95'][1]:+.4f}]")

    # ---- tautological reference K1: total pocket coverage ----
    yk = np.log1p(f["w_true"].sum(1))
    pk = np.log1p(f["w_pred"].sum(1))
    pk_cal, _ = affine(pk[tr], yk[tr], pk[te])
    s0 = unit_sse((yk[te] - yk[tr].mean()) ** 2, group[te])
    sk = unit_sse((yk[te] - pk_cal) ** 2, group[te])
    results["tautological_reference_K1"] = {
        "r2_A5_vs_mean": r2_vs_base(sk, s0, N_BOOT, 301),
        "note": "excluded from the criterion by T-RULE: contact is exactly the "
                "tensor P1B minimised its loss against.",
    }
    print(f"\nK1 pocket coverage [TAUTOLOGICAL_REFERENCE] R2="
          f"{results['tautological_reference_K1']['r2_A5_vs_mean']['point']:+.4f}")

    # ---- pair-local (per-slot) reconstruction, required by base prereg §9 ----
    print("\nper-slot apolar burial reconstruction (within-complex):")
    ps = per_slot_reconstruction(
        f["occ"], f["comp"], f["w_true"],
        {"A5": f["w_pred"], "AG": w_gshuf, "AO": f["w_true"]}, te, group)
    for k, v in ps.items():
        print(f"  {k:4s} R2={v['r2_within_complex']:+.4f} "
              f"[{v['ci95'][0]:+.4f},{v['ci95'][1]:+.4f}] units={v['units']}")
    results["per_slot_reconstruction"] = ps

    # ---- registered five-condition feasibility criterion, CORE channel ----
    core = results["channels"][CORE]
    conds = {
        "1_A5_vs_mean": core["r2_vs_mean"]["A5"],
        "2_A5_minus_ligand_only": core["gaps"]["vs_ligand_only_A1"],
        "3_A5_minus_deranged": core["gaps"]["vs_deranged_AD"],
        "4_A5_minus_geometry_shuffle": core["gaps"]["vs_geometry_shuffle_AG"],
        "5_A5_minus_background": core["gaps"]["vs_background_A2"],
    }
    verdict = {}
    for k, v in conds.items():
        verdict[k] = {"point": v["point"], "lcb95": v["ci95"][0],
                      "meets_threshold": bool(v["point"] >= 0.02),
                      "lcb_above_zero": bool(v["ci95"][0] > 0),
                      "pass": bool(v["point"] >= 0.02 and v["ci95"][0] > 0)}
    allpass = all(x["pass"] for x in verdict.values())
    results["feasibility_criterion"] = verdict
    results["core_channel_pass"] = bool(allpass)

    print(f"\n=== registered feasibility criterion (CORE = {CORE}) ===")
    for k, v in verdict.items():
        print(f"  {k:32s} point={v['point']:+.4f} lcb={v['lcb95']:+.4f} "
              f"{'PASS' if v['pass'] else 'FAIL'}")
    print(f"\nCORE CHANNEL: {'PASS' if allpass else 'FAIL'}")

    (OUT / "S5R2_LADDER.json").write_text(json.dumps(results, indent=2), encoding="utf-8")
    print(f"wrote {OUT / 'S5R2_LADDER.json'}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
