"""S5R-2 build — derive the pocket-chemistry enrichment coordinate `e` for every
governed complex, from the frozen v2 chain and the frozen P1B checkpoint.

Registered by PREREG_S5R2_POCKET_CHEMISTRY_ENRICHMENT.md.

Frozen and untouched: model/, contracts/, production scripts/, theory/, CSMO,
Band, mesh, K. This script only *reads* them. No affinity value, DAVIS record,
recipient label, PLIP annotation or pose-aware datum is opened.

Streaming: shards are loaded one at a time; nothing larger than a shard is held.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
from collections import OrderedDict
from pathlib import Path

import numpy as np
import torch

ROOT = Path(r"D:\MetaSieve")
sys.path.insert(0, str(ROOT))

from contracts.ligand_graph import ATOM_FEAT_DIM, BOND_FEAT_DIM, MAX_ATOMS  # noqa: E402
from contracts.mechanism import MECHANISM_RESIDUE_SLOTS  # noqa: E402
from model.encoders import LigandEncoder, ProteinEncoder  # noqa: E402
from model.mechanism import MechanisticInteractionBridge  # noqa: E402

OPEN = ROOT / "dataset" / "processed" / "open_structures"
RECORDS = OPEN / "pilot20k_homology_split_v2" / "complexes.jsonl"
SUPERVISION = OPEN / "pilot20k_structure_supervision_v2"
PROTEIN_BANK = OPEN / "pilot20k_esm2_t30_slots128_v1"
LIGAND_BANK = OPEN / "pilot20k_mechanism_ligands_v1.pt"
CHECKPOINT = ROOT / "report" / "mechanism_refactor" / "p1b_pilot20k_seed17_v1" / "best.pt"
OUT = ROOT / "report" / "ssl_s5"
CACHE = ROOT / "dataset" / "processed" / "ssl_s5"

AA20 = "ACDEFGHIKLMNPQRSTVWY"
AA_INDEX = {c: i for i, c in enumerate(AA20)}
S = MECHANISM_RESIDUE_SLOTS


def read_jsonl(path):
    with open(path, encoding="utf-8") as f:
        return [json.loads(line) for line in f if line.strip()]


def slot_composition(sequence: str):
    """C[S,20] row-stochastic over standard residues, and n_std[S] weights.

    Slot map sigma(i) = min(127, i*128 // L) — bit-identical to the frozen
    geometry and ESM slot maps (finding M-4).
    """
    L = len(sequence)
    counts = np.zeros((S, 20), dtype=np.float64)
    n_std = np.zeros(S, dtype=np.float64)
    n_all = np.zeros(S, dtype=np.float64)
    for i, ch in enumerate(sequence):
        s = min(S - 1, i * S // L)
        n_all[s] += 1.0
        j = AA_INDEX.get(ch)
        if j is not None:
            counts[s, j] += 1.0
            n_std[s] += 1.0
    C = np.zeros_like(counts)
    nz = n_std > 0
    C[nz] = counts[nz] / n_std[nz, None]
    return C, n_std, n_all


def enrichment(w, C, n_std, occupied):
    """e = q - b, both restricted to slots that are occupied AND have standard
    residues. Returns (e[20], q[20], b[20], usable_slots)."""
    use = occupied & (n_std > 0)
    if not use.any():
        return None
    ww = w * use
    tot = ww.sum()
    if tot <= 0:
        return None
    q = (ww[:, None] * C).sum(0) / tot
    nb = n_std * use
    b = (nb[:, None] * C).sum(0) / nb.sum()
    return q - b, q, b, int(use.sum())


class ShardCache:
    """Tiny LRU over .npz shards so streaming stays near-sequential."""

    def __init__(self, size=3):
        self.size = size
        self.store = OrderedDict()

    def get(self, path, keys):
        key = str(path)
        if key in self.store:
            self.store.move_to_end(key)
            return self.store[key]
        with np.load(path, allow_pickle=False) as z:
            arrays = {k: z[k] for k in keys}
        self.store[key] = arrays
        self.store.move_to_end(key)
        while len(self.store) > self.size:
            self.store.popitem(last=False)
        return arrays


def build_model(protein_dim, device):
    class P1B(torch.nn.Module):
        def __init__(self):
            super().__init__()
            self.protein = ProteinEncoder(protein_dim, 128, dtype=torch.float32)
            self.ligand = LigandEncoder(128, n_layers=3, dtype=torch.float32)
            self.bridge = MechanisticInteractionBridge(128, 128, rank=32,
                                                       dtype=torch.float32)

    model = P1B()
    state = torch.load(CHECKPOINT, map_location="cpu", weights_only=False)
    if isinstance(state, dict) and not any(k.startswith(("protein.", "ligand.", "bridge."))
                                           for k in state):
        for cand in ("model_state", "model", "state_dict", "model_state_dict"):
            if cand in state:
                ckpt_meta = {k: v for k, v in state.items() if k != cand}
                state = state[cand]
                break
        else:
            raise SystemExit("P1B checkpoint has no recognisable state dict")
    else:
        ckpt_meta = {}
    if ckpt_meta.get("protein_dim") not in (None, protein_dim):
        raise SystemExit(f"checkpoint protein_dim {ckpt_meta['protein_dim']} "
                         f"differs from bank {protein_dim}")
    model.load_state_dict(state, strict=True)
    model.eval().to(device)
    print(f"checkpoint meta: { {k: v for k, v in ckpt_meta.items() if k != 'config'} }")
    return model


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--batch", type=int, default=8)
    ap.add_argument("--limit", type=int, default=0)
    ap.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    args = ap.parse_args()

    OUT.mkdir(parents=True, exist_ok=True)
    CACHE.mkdir(parents=True, exist_ok=True)

    records = read_jsonl(RECORDS)
    pairs = {r["source_entry_id"]: r for r in read_jsonl(SUPERVISION / "pairs.jsonl")}
    if set(pairs) != {r["source_entry_id"] for r in records}:
        raise SystemExit("S5_DATA_OR_MAPPING_CONTRACT_FAIL_CLOSED: "
                         "split records and geometry pairs differ")

    prot_manifest = json.loads((PROTEIN_BANK / "manifest.json").read_text(encoding="utf-8"))
    protein_dim = int(prot_manifest["hidden_dim"])
    prot_lookup = {}
    for shard in prot_manifest["shards"]:
        with np.load(PROTEIN_BANK / shard["path"], allow_pickle=False) as z:
            for row, key in enumerate(z["keys"]):
                prot_lookup[str(key)] = (shard["path"], row)

    ligands = torch.load(LIGAND_BANK, map_location="cpu", weights_only=False)
    model = build_model(protein_dim, args.device)
    print(f"loaded P1B checkpoint; protein_dim={protein_dim}; device={args.device}")

    n = len(records) if args.limit == 0 else min(args.limit, len(records))
    geo_cache, esm_cache = ShardCache(2), ShardCache(3)

    e_true = np.zeros((n, 20), np.float64)
    e_pred = np.zeros((n, 20), np.float64)
    bg = np.zeros((n, 20), np.float64)
    q_true = np.zeros((n, 20), np.float64)
    q_pred = np.zeros((n, 20), np.float64)
    w_true = np.zeros((n, S), np.float32)
    w_pred = np.zeros((n, S), np.float32)
    n_std_all = np.zeros((n, S), np.float32)
    occ = np.zeros((n, S), np.uint8)
    comp = np.zeros((n, S, 20), np.float16)
    lig_pooled = np.zeros((n, 128), np.float32)
    esm_mean = np.zeros((n, protein_dim), np.float32)
    lig_elem = np.zeros((n, ATOM_FEAT_DIM), np.float32)
    seq_len = np.zeros(n, np.int32)
    n_atoms = np.zeros(n, np.int32)
    contact_pos = np.zeros(n, np.int64)
    valid = np.zeros(n, bool)
    precond_violations = 0
    precond_checked = 0

    order = list(range(n))
    for start in range(0, n, args.batch):
        idx = order[start:start + args.batch]
        X = torch.zeros(len(idx), MAX_ATOMS, ATOM_FEAT_DIM)
        A = torch.zeros(len(idx), MAX_ATOMS, MAX_ATOMS, BOND_FEAT_DIM)
        amask = torch.zeros(len(idx), MAX_ATOMS)
        pooled = np.zeros((len(idx), protein_dim), np.float32)
        resid = np.zeros((len(idx), S, protein_dim), np.float32)
        rmask = np.zeros((len(idx), S), np.float32)
        geo_contact = []
        for b, i in enumerate(idx):
            rec = records[i]
            pair = pairs[rec["source_entry_id"]]
            g = geo_cache.get(SUPERVISION / pair["shard"],
                              ("contact", "distance_bin", "atom_mask", "residue_mask"))
            k = pair["shard_index"]
            contact = g["contact"][k]
            dbin = g["distance_bin"][k]
            am = g["atom_mask"][k]
            rm = g["residue_mask"][k]
            pm = (am[:, None].astype(bool) & rm[None, :].astype(bool))
            # Amendment 3 precondition: contact == (distance_bin <= 1) on support.
            precond_checked += int(pm.sum())
            precond_violations += int(((contact.astype(bool) != (dbin <= 1))[pm]).sum())
            geo_contact.append((contact, am, rm))

            graph = ligands[rec["ccd_sha256"]]
            X[b] = graph["X"]
            amask[b] = graph["mask"]
            edge = graph["edge_index"].long()
            A[b, edge[0], edge[1]] = graph["edge_attr"]

            sp, row = prot_lookup[rec["sequence_sha256"]]
            e = esm_cache.get(PROTEIN_BANK / sp, ("pooled", "residues", "mask"))
            pooled[b] = e["pooled"][row].astype(np.float32)
            resid[b] = e["residues"][row].astype(np.float32)
            rmask[b] = rm.astype(np.float32)

        if not torch.equal(amask.to(torch.uint8),
                           torch.from_numpy(np.stack([g[1] for g in geo_contact]))):
            raise SystemExit("S5_DATA_OR_MAPPING_CONTRACT_FAIL_CLOSED: "
                             "CCD graph atom mask differs from geometry atom mask")

        with torch.inference_mode():
            lig_pool, atoms = model.ligand(X.to(args.device), A.to(args.device),
                                           amask.to(args.device))
            _, residues = model.protein(torch.from_numpy(pooled).to(args.device),
                                        torch.from_numpy(resid).to(args.device))
            pred = model.bridge(atoms, amask.to(args.device), residues,
                                torch.from_numpy(rmask).to(args.device))
            pc = pred.contact_prob.float().cpu().numpy()      # [B,128,128]

        for b, i in enumerate(idx):
            rec = records[i]
            contact, am, rm = geo_contact[b]
            occupied = rm.astype(bool)
            amb = am.astype(bool)
            C, n_std, _n_all = slot_composition(rec["sequence"])
            wt = (contact * amb[:, None]).sum(0).astype(np.float64)
            wp = (pc[b] * amb[:, None]).sum(0).astype(np.float64)
            wp = wp * occupied

            rt = enrichment(wt, C, n_std, occupied)
            rp = enrichment(wp, C, n_std, occupied)
            if rt is None or rp is None:
                continue
            e_true[i], q_true[i], bg[i], _ = rt
            e_pred[i], q_pred[i], _, _ = rp
            w_true[i] = wt
            w_pred[i] = wp
            n_std_all[i] = n_std
            occ[i] = occupied.astype(np.uint8)
            comp[i] = C.astype(np.float16)
            lig_pooled[i] = lig_pool[b].float().cpu().numpy()
            esm_mean[i] = pooled[b]
            lig_elem[i] = (X[b].numpy() * amask[b].numpy()[:, None]).sum(0)
            seq_len[i] = len(rec["sequence"])
            n_atoms[i] = int(amb.sum())
            contact_pos[i] = int((contact * amb[:, None] * occupied[None, :]).sum())
            valid[i] = True

        if (start // args.batch) % 100 == 0:
            print(f"  {start + len(idx)}/{n} complexes", flush=True)

    meta = {
        "schema": "MetaSieve.S5R2Build.v1",
        "records": int(n),
        "valid": int(valid.sum()),
        "invalid": int(n - valid.sum()),
        "checkpoint_sha256": hashlib.sha256(CHECKPOINT.read_bytes()).hexdigest(),
        "records_path": str(RECORDS.relative_to(ROOT)),
        "supervision": str(SUPERVISION.relative_to(ROOT)),
        "protein_bank": str(PROTEIN_BANK.relative_to(ROOT)),
        "ligand_bank": str(LIGAND_BANK.relative_to(ROOT)),
        "slot_map": "min(127, i*128//L)",
        "contact_precondition_pairs_checked": int(precond_checked),
        "contact_precondition_violations": int(precond_violations),
        "contact_precondition_verdict":
            "PASS" if precond_violations == 0 else "S5_TEACHER_OR_SLOT_CONTRACT_DEFECT",
        "affinity_labels_read": 0,
        "davis_label_reads": 0,
        "recipient_label_reads": 0,
    }
    print(json.dumps(meta, indent=2))

    np.savez_compressed(
        CACHE / "s5r2_features.npz",
        e_true=e_true, e_pred=e_pred, bg=bg, q_true=q_true, q_pred=q_pred,
        w_true=w_true, w_pred=w_pred, n_std=n_std_all, occ=occ, comp=comp,
        lig_pooled=lig_pooled, esm_mean=esm_mean, lig_elem=lig_elem,
        seq_len=seq_len, n_atoms=n_atoms, contact_pos=contact_pos, valid=valid,
        split=np.array([r["source_split"] for r in records[:n]]),
        group=np.array([r["homology_group_id"] for r in records[:n]]),
        scaffold=np.array([r["murcko_scaffold"] for r in records[:n]]),
        pdb=np.array([r["pdb_id"] for r in records[:n]]),
        comp_id=np.array([r["ligand_comp_id"] for r in records[:n]]),
        entry=np.array([r["source_entry_id"] for r in records[:n]]),
    )
    (OUT / "S5R2_BUILD_MANIFEST.json").write_text(json.dumps(meta, indent=2),
                                                  encoding="utf-8")
    print(f"wrote {CACHE / 's5r2_features.npz'}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
