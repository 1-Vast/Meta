"""Build the S5R-2 superseded-artifact registry.

Marks stale artifacts as superseded while PRESERVING their bytes, hashes and
provenance. Nothing is deleted, edited or moved. Read-only over the artifacts;
writes only report/ssl_s5/S5R2_SUPERSEDED_ARTIFACTS.json.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

ROOT = Path(r"D:\MetaSieve")
OUT = ROOT / "report" / "ssl_s5"

SUPERSEDED = {
    "report/ssl_s5/S5R2_HEAD_SYNTHETIC_NORM.json": {
        "reason": "produced by a normalisation repair applied in response to a "
                  "false diagnosis (audit D-2); the un-normalised registered run "
                  "already passed module participation and fits better",
        "superseded_by": "report/ssl_s5/S5R2_HEAD_SYNTHETIC.json",
        "status": "SUPERSEDED_DIAGNOSTIC_RETAINED",
    },
    "report/ssl_s5/S5R2_HEAD_REAL_NORM.json": {
        "reason": "same false-diagnosis repair; additionally its "
                  "NOT_CAUSALLY_USED ligand verdict is an artefact of the 1e-3 "
                  "standard-deviation floor amplifying near-constant one-hot "
                  "atom features by up to 1000x",
        "superseded_by": "report/ssl_s5/S5R2_HEAD_REAL.json for module "
                         "participation; NOTHING supersedes it for the "
                         "head-vs-A5 aggregate comparison, which exists only "
                         "here and is therefore withdrawn, not replaced",
        "status": "SUPERSEDED_DIAGNOSTIC_RETAINED",
    },
    "report/ssl_s5/S5R2_RESULT.json": {
        "reason": "embeds the 32-complex smoke-test synthetic numbers via its "
                  "module_participation block, and carries the withdrawn "
                  "terminal verdict and single-unit bootstrap",
        "superseded_by": "report/ssl_s5/S5R2_RESULT_CORRECTED.json",
        "status": "SUPERSEDED_RETAINED",
    },
    "report/ssl_s5/S5_RESULT.json": {
        "reason": "asserts the _v1 bank chain and BLOCKED_NO_COMPUTE; both were "
                  "corrected by the provenance resolution and the S5R-2 run",
        "superseded_by": "report/ssl_s5/S5_PROVENANCE_CHAIN_RESOLUTION.json and "
                         "report/ssl_s5/S5_INPUT_HASH_VERIFICATION.json",
        "status": "SUPERSEDED_HISTORICAL_RETAINED",
    },
    "report/ssl_s5/S5_STAGE0_REPOSITORY_AND_EVIDENCE_AUDIT.md": {
        "reason": "pinned the _v1 supervision and split banks from prose; the "
                  "P1B checkpoint declares _v2",
        "superseded_by": "report/ssl_s5/S5_PROVENANCE_CHAIN_RESOLUTION.json",
        "status": "SUPERSEDED_HISTORICAL_RETAINED",
    },
}

WITHDRAWN_CLAIMS = [
    {
        "claim": "un-normalised synthetic run gave loss 0.0760 -> 0.0383 with "
                 "protein and geometry branches NOT_CAUSALLY_USED",
        "status": "WITHDRAWN_FALSE",
        "correct_value": "loss 0.077279 -> 0.002167, all three branches "
                         "CAUSALLY_USED (train=1200, test=400, 3 epochs)",
        "source_of_error": "a 32-train/16-test/1-epoch smoke test whose JSON was "
                           "read before the registered run overwrote the same "
                           "filename at 12:06:58",
        "appeared_in": ["S5R2_FINAL_REPORT.md", "history.md F-96",
                        "report/CURRENT_RESEARCH_STATUS.md",
                        "report/EXPERIMENTAL_EVIDENCE_LEDGER.md",
                        "S5R2_RESULT.json"],
    },
    {
        "claim": "a normalisation defect was diagnosed and the registered repair "
                 "fixed it",
        "status": "WITHDRAWN_INVERTED",
        "correct_value": "no defect existed at the registered scale; the repair "
                         "degraded synthetic (0.00373 vs 0.00217) and real "
                         "(0.00590 vs 0.00301) and created the only "
                         "NOT_CAUSALLY_USED verdict in the record",
    },
    {
        "claim": "the trained 1.73M head is much worse than the zero-parameter "
                 "readout, therefore learning buys nothing",
        "status": "WITHDRAWN_SCOPE",
        "correct_value": "measured only for the superseded normalised head, on a "
                         "complex-level aggregate it never optimised, with "
                         "calibration fitted on TEST while the ladder fitted on "
                         "TRAIN; the better un-normalised head was never compared",
    },
    {
        "claim": "A5 - AL = +0.1337 [+0.0750, +0.2164]",
        "status": "WITHDRAWN_NUMERIC",
        "correct_value": "+0.1383 [+0.0827, +0.2037] on 1,382 correctly masked "
                         "rows; 67 test rows had entered arm AL as exact zero "
                         "vectors because lig_valid was never intersected",
    },
    {
        "claim": "all five registered conditions PASS",
        "status": "WITHDRAWN_UNIT_DEPENDENT",
        "correct_value": "true under homology-only, scaffold-only and "
                         "homology x scaffold cell bootstraps; FALSE under the "
                         "registered closure-component unit (54 components, "
                         "largest holds 89.1% of the test split), where every "
                         "lower bound crosses zero",
    },
    {
        "claim": "P1B_PAIR_LOCAL_STRUCTURAL_MECHANISM_OBSERVED",
        "status": "WITHDRAWN_TERMINAL_VERDICT",
        "correct_value": "see S5R2_RESULT_CORRECTED.json corrected_verdict",
    },
    {
        "claim": "the restored sources are proved to be the registered "
                 "implementations",
        "status": "WITHDRAWN_WORDING",
        "correct_value": "executable-semantic equivalence under CPython 3.11; "
                         "source identity is guaranteed by git checkout 608decf, "
                         "and the bytecode check is corroboration, not proof of "
                         "byte-identity",
    },
    {
        "claim": "a new score-blind RCSB block is required only for external "
                 "confirmation, not for the internal result (experiment.md)",
        "status": "WITHDRAWN_OVERSTATEMENT",
        "correct_value": "the evaluation split is the split on which the P1B "
                         "Gate was decided; it is development-exposed, so no "
                         "S5R-2 number is confirmatory and base preregistration "
                         "3.3 remains unmet",
    },
]


def sha256(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    reg = {"schema": "MetaSieve.S5R2SupersededArtifacts.v1",
           "created_utc": "2026-08-09",
           "policy": "stale artifacts are marked superseded and RETAINED with "
                     "their bytes and hashes; nothing is deleted or edited",
           "artifacts": {}, "withdrawn_claims": WITHDRAWN_CLAIMS}
    for rel, meta in SUPERSEDED.items():
        p = ROOT / rel
        if not p.is_file():
            reg["artifacts"][rel] = meta | {"present": False}
            continue
        reg["artifacts"][rel] = meta | {
            "present": True,
            "sha256": sha256(p),
            "bytes": p.stat().st_size,
            "mtime_utc_local": __import__("datetime").datetime.fromtimestamp(
                p.stat().st_mtime).isoformat(timespec="seconds"),
        }
    dest = OUT / "S5R2_SUPERSEDED_ARTIFACTS.json"
    dest.write_text(json.dumps(reg, indent=2), encoding="utf-8")
    print(f"registered {len(reg['artifacts'])} superseded artifacts, "
          f"{len(WITHDRAWN_CLAIMS)} withdrawn claims")
    print(f"wrote {dest}")


if __name__ == "__main__":
    main()
