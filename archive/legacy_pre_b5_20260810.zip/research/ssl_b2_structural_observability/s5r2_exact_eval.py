"""S5R-2 — evaluate every arm against the EXACT-RESIDUE pocket enrichment.

The ladder scores arms against the 128-slot target `e_true`. That target is
itself a compressed proxy: the census measured that the slot representation
retains only R2 = 0.48 (APOLAR) of the exact-residue quantity. This script asks
the biologically honest question directly:

    how much of the *exact-residue* pocket-chemistry enrichment does the
    deployable, zero-parameter arm A5 explain?

Exact-residue enrichment is recomputed from the frozen mmCIF with gemmi, heavy
atoms only (Amendment D-1), on a deterministic sample of the test split.
Bootstrap units are protein homology groups. No affinity value is opened.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

ROOT = Path(r"D:\MetaSieve")
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "research" / "ssl_b2_structural_observability"))
sys.path.insert(0, str(ROOT / "research" / "crossed_panel_deployability"))

from s5r2_build import CACHE, OUT, RECORDS, read_jsonl  # noqa: E402
from s5r2_census import exact_residue_enrichment  # noqa: E402
from s5r2_ladder import SETS, affine, indicator, r2_gap, unit_sse  # noqa: E402
from xp2_core import r2_vs_base, ridge_cv  # noqa: E402

N_SAMPLE = 700
N_BOOT = 5000


def main():
    records = read_jsonl(RECORDS)
    with np.load(CACHE / "s5r2_features.npz", allow_pickle=True) as z:
        f = {k: z[k] for k in z.files}
    with np.load(CACHE / "s5r2_controls.npz", allow_pickle=True) as z:
        c = {k: z[k] for k in z.files}
    with np.load(CACHE / "s5r2_ligand_control.npz", allow_pickle=True) as z:
        lc = {k: z[k] for k in z.files}

    valid = f["valid"] & c["der_valid"]
    split, group = f["split"], f["group"]
    tr = np.where(valid & (split == "train"))[0]
    te_all = np.where(valid & (split == "test"))[0]
    rng = np.random.default_rng(20260809)
    sample = rng.choice(te_all, size=min(N_SAMPLE, len(te_all)), replace=False)

    print(f"re-parsing {len(sample)} test complexes for exact-residue enrichment ...",
          flush=True)
    ok_idx, e_exact = [], []
    for n, i in enumerate(sample):
        try:
            r = exact_residue_enrichment(records[i])
        except Exception:
            r = None
        if r is not None:
            ok_idx.append(int(i))
            e_exact.append(r[0])
        if (n + 1) % 100 == 0:
            print(f"   {n + 1}/{len(sample)} parsed, {len(ok_idx)} usable", flush=True)
    ok_idx = np.array(ok_idx)
    e_exact = np.asarray(e_exact)
    print(f"usable: {len(ok_idx)}  homology groups: {len(set(group[ok_idx].tolist()))}")

    # train-fitted arms, evaluated on the sampled subset
    LIG = np.hstack([f["lig_pooled"], f["lig_elem"]])
    fitted = {"A1": LIG, "A2": f["bg"], "A5e": c["esm_pocket"]}
    E_hat = {}
    for arm, X in fitted.items():
        pred, _lam = ridge_cv(X[tr], f["e_true"][tr], X[ok_idx], group[tr])
        E_hat[arm] = pred

    ZERO = {"A5": f["e_pred"], "AD": c["e_deranged"], "AL": lc["e_ligand_deranged"],
            "SLOT_TRUE": f["e_true"]}

    out = {"schema": "MetaSieve.S5R2ExactResidueEval.v1",
           "sampled": int(len(sample)), "usable": int(len(ok_idx)),
           "homology_groups": len(set(group[ok_idx].tolist())),
           "note": "target is the EXACT-RESIDUE pocket enrichment from raw "
                   "coordinates, heavy atoms only; not the 128-slot proxy",
           "channels": {}}

    for name, letters in SETS.items():
        u = indicator(letters)
        y = e_exact @ u
        ytr_slot = f["e_true"][tr] @ u
        preds = {"A0": np.full(len(ok_idx), ytr_slot.mean())}
        for arm in fitted:
            preds[arm] = E_hat[arm] @ u
        for arm, vec in ZERO.items():
            preds[arm], _ = affine(vec[tr] @ u, ytr_slot, vec[ok_idx] @ u)
        sse = {a: unit_sse((y - p) ** 2, group[ok_idx]) for a, p in preds.items()}
        ch = {"target_sd": float(y.std()), "r2_vs_mean": {}}
        for a in preds:
            if a == "A0":
                continue
            ch["r2_vs_mean"][a] = r2_vs_base(sse[a], sse["A0"], N_BOOT, 401)
        ch["gap_A5_minus_A1"] = r2_gap(sse["A5"], sse["A1"], sse["A0"], N_BOOT, 402)
        ch["gap_A5_minus_AL"] = r2_gap(sse["A5"], sse["AL"], sse["A0"], N_BOOT, 403)
        ch["gap_A5_minus_AD"] = r2_gap(sse["A5"], sse["AD"], sse["A0"], N_BOOT, 404)
        out["channels"][name] = ch

        print(f"\n=== {name} vs EXACT-RESIDUE target (sd={y.std():.4f}) ===")
        for a in ("A1", "A2", "A5e", "A5", "AD", "AL", "SLOT_TRUE"):
            r = ch["r2_vs_mean"][a]
            tag = "  <- 128-slot ceiling" if a == "SLOT_TRUE" else ""
            print(f"  R2 {a:10s} {r['point']:+.4f} "
                  f"[{r['ci95'][0]:+.4f},{r['ci95'][1]:+.4f}]{tag}")
        for k in ("gap_A5_minus_A1", "gap_A5_minus_AL", "gap_A5_minus_AD"):
            g = ch[k]
            print(f"  {k:20s} {g['point']:+.4f} "
                  f"[{g['ci95'][0]:+.4f},{g['ci95'][1]:+.4f}]")

    (OUT / "S5R2_EXACT_RESIDUE_EVAL.json").write_text(json.dumps(out, indent=2),
                                                      encoding="utf-8")
    print(f"\nwrote {OUT / 'S5R2_EXACT_RESIDUE_EVAL.json'}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
